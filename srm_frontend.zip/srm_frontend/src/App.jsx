import { Routes, Route } from 'react-router-dom';
import SupplierRiskDashboard from './pages/srmdashboard';
import SupplierRiskManagement from './pages/SrmLanding';
function App() {
  return (
    <Routes>
      <Route path="/" element={<SupplierRiskManagement />} />
      <Route path="/srmdashboard" element={<SupplierRiskDashboard />} />
    </Routes>
  );
}

export default App