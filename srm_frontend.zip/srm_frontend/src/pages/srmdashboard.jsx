import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000').replace(/\/+$/, '');

// Ensure every endpoint path has the /api prefix
const apiPath = (endpoint) =>
  endpoint.startsWith('/api/')
    ? endpoint
    : `/api${endpoint.startsWith('/') ? endpoint : '/' + endpoint}`;

// Add this helper function near the top of your component (after the API_BASE_URL)
const capitalizeFirstLetters = (str) => {
  if (!str) return '';
  return str
    .split(' ')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
};


const apiClient = {
  get: async (endpoint) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`API Error (GET ${endpoint}):`, error);
      return null;
    }
  },
  post: async (endpoint, data) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`API Error (POST ${endpoint}):`, error);
      return null;
    }
  }
};

const RiskTrendChart = ({ data, kpi, supplierName, riskType }) => {
  if (!data || data.length === 0) {
    return (
      <div className="bg-gray-50 p-8 rounded-lg text-center">
        <p className="text-gray-500">No trend data available for {supplierName}</p>
      </div>
    );
  }

  // Add this mapping for risk score KPIs
  const riskScoreMapping = {
    financial: 'financial_risk_score',
    performance: 'performance_risk_score', 
    geopolitical: 'geopolitical_risk_score',
    overall: 'overall_risk_score'
  };

  // Check if kpi is a risk score
  const isRiskScore = Object.values(riskScoreMapping).includes(kpi);
  
  const chartData = data.map(item => ({
    date: item.update_date,
    value: item[kpi] || 0
  }));

  // Format the title based on whether it's a risk score or regular KPI
  const getChartTitle = () => {
    if (isRiskScore) {
      const riskTypeName = Object.keys(riskScoreMapping).find(key => riskScoreMapping[key] === kpi);
      return `${supplierName} - ${riskTypeName.charAt(0).toUpperCase() + riskTypeName.slice(1)} Risk Score Trend`;
    }
    return `${supplierName} - ${kpi.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())} Trend`;
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">
        {getChartTitle()}
      </h3>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="date" stroke="#4b5563" />
          <YAxis domain={['dataMin - 10', 'dataMax + 10']} stroke="#4b5563" 
            tickFormatter={(value) => {
              return parseFloat(Number(value).toFixed(1)).toString();
            }}/>
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: '6px'
            }}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#2563eb"
            strokeWidth={2}
            activeDot={{ r: 8, fill: '#2563eb' }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

const ComprehensiveRiskTable = ({ data, supplierName }) => {
  if (!data || data.length === 0) {
    return (
      <div className="bg-gray-50 p-8 rounded-lg text-center">
        <p className="text-gray-500">No historical data available for {supplierName}</p>
      </div>
    );
  }

  const columns = [
    'update_date',
    'financial_risk_score', 'financial_risk_level',
    'geopolitical_risk_score', 'geopolitical_risk_level',
    'performance_risk_score', 'performance_risk_level',
    'overall_risk_score', 'overall_risk_level'
  ];

  const headers = [
    'Update Date',
    'Financial Risk Score', 'Financial Risk Level',
    'Geopolitical Risk Score', 'Geopolitical Risk Level',
    'Performance Risk Score', 'Performance Risk Level',
    'Overall Risk Score', 'Overall Risk Level'
  ];

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 overflow-x-auto">
      {/* <h3 className="text-lg font-semibold text-gray-800 mb-4">
        {supplierName} - Comprehensive Risk Analysis
      </h3> */}
      <div className="mb-2 text-sm text-gray-600">
        Displaying: {headers.length} columns and {data.length} records from overall risk data
      </div>
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            {headers.map((header, index) => (
              <th
                key={index}
                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.map((item, index) => (
            <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
              {columns.map((column, colIndex) => (
                <td key={colIndex} className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                  {column.includes('risk_level') ? (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      item[column] === 'CRITICAL' ? 'bg-red-100 text-red-800' :
                      item[column] === 'HIGH' ? 'bg-orange-100 text-orange-800' :
                      item[column] === 'MEDIUM' ? 'bg-yellow-100 text-yellow-800' :
                      item[column] === 'LOW' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {item[column] || 'N/A'}
                    </span>
                  ) : typeof item[column] === 'number' ? (
                    item[column].toFixed(2)
                  ) : (
                    item[column] || 'N/A'
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const DetailedRiskTable = ({ data, riskType, supplierName }) => {
  if (!data || data.length === 0) {
    return (
      <div className="bg-gray-50 p-8 rounded-lg text-center">
        <p className="text-gray-500">No detailed data available for {supplierName}</p>
      </div>
    );
  }

  // Get all columns from the first data item, excluding internal fields
  const getAllColumns = () => {
    const firstItem = data[0];
    const excludedColumns = ['_id', 'supplier_id', 'supplier_name'];
   
    return Object.keys(firstItem)
      .filter(key => !excludedColumns.includes(key))
      .sort((a, b) => {
        // Put update_date first
        if (a === 'update_date') return -1;
        if (b === 'update_date') return 1;
        return a.localeCompare(b);
      });
  };

  const columns = getAllColumns();
  const headers = columns.map(col =>
    col.replace(/_/g, ' ')
       .split(' ')
       .map(word => word.charAt(0).toUpperCase() + word.slice(1))
       .join(' ')
  );

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 overflow-x-auto">
      {/* <h3 className="text-lg font-semibold text-gray-800 mb-4">
        {supplierName} - Complete {riskType.charAt(0).toUpperCase() + riskType.slice(1)} Risk Analysis
      </h3> */}
      <div className="mb-2 text-sm text-gray-600">
        Displaying: {headers.length} columns and {data.length} records from {riskType} risk data
      </div>
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            {headers.map((header, index) => (
              <th
                key={index}
                className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {data.map((item, index) => (
            <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
              {columns.map((column, colIndex) => (
                <td key={colIndex} className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                  {column.includes('risk_level') ? (
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      item[column] === 'CRITICAL' ? 'bg-red-100 text-red-800' :
                      item[column] === 'HIGH' ? 'bg-orange-100 text-orange-800' :
                      item[column] === 'MEDIUM' ? 'bg-yellow-100 text-yellow-800' :
                      item[column] === 'LOW' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {item[column] || 'N/A'}
                    </span>
                  ) : typeof item[column] === 'number' ? (
                    item[column].toFixed(2)
                  ) : (
                    item[column] || 'N/A'
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const RiskProfileTab = ({ supplier, onBack }) => {
  const [riskProfileData, setRiskProfileData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchRiskProfile = async () => {
    if (!supplier) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await apiClient.post('/api/dashboard/risk-profile', {
        supplier_name: supplier.supplier_name,
        user_id: 'dashboard_user'
      });
      
      if (data && data.success) {
        setRiskProfileData(data);
      } else {
        setError(data?.error || 'Failed to fetch risk profile');
      }
    } catch (err) {
      setError('Error connecting to server');
      console.error('Error fetching risk profile:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRiskProfile();
  }, [supplier]);

  const formatRiskProfileText = (text) => {
  if (!text) return null;

  return text.split('\n').map((line, index) => {
    // Clean line first and capture bold using regex
    const cleanLine = line.trim().replace(/\*\*/g, '');

    if (line.startsWith('**') && line.endsWith('**')) {
      // Handle lines that are completely bold
      return (
        <p key={index} className="font-bold text-gray-900 mb-2">
          {line.replace(/\*\*/g, '')}
        </p>
      );
    } else if (cleanLine.startsWith('## ')) {
      // Handle level 2 headings
      return (
        <h2
          key={index}
          className="text-2xl font-bold mt-6 mb-4 text-blue-800"
        >
          {cleanLine.substring(3)}
        </h2>
      );
    } else if (cleanLine.startsWith('### ')) {
      // Handle level 3 headings
      return (
        <h3
          key={index}
          className="text-xl font-semibold mt-5 mb-3 text-blue-700"
        >
          {cleanLine.substring(4)}
        </h3>
      );
    } else if (cleanLine.match(/^\d+\.\s+[A-Za-z]/)) {
      // Handle numbered headings like "1. Financial Health"
      return (
        <h3
          key={index}
          className="text-lg font-bold mt-4 mb-2 text-gray-800"
        >
          {cleanLine}
        </h3>
      );
    } else if (
      cleanLine.match(/^[A-Z][A-Za-z\s]+:$/) || // Single word + colon
      cleanLine.match(/^[A-Z][a-z]+ [A-Z][a-z]+:$/) || // Two words + colon
      cleanLine.match(/^[A-Z][a-z]+ [A-Z][a-z]+ [A-Z][a-z]+:$/) || // Three words + colon
      [
        'Overall Assessment:',
        'External Intelligence Alerts:',
        'Strategic Recommendations:',
        'Potential Business Impact:',
        'Immediate Action Required:',
      ].includes(cleanLine)
    ) {
      // Handle other colon-ending headings
      return (
        <h3
          key={index}
          className="text-lg font-bold mt-4 mb-2 text-gray-800"
        >
          {cleanLine}
        </h3>
      );
    } else if (cleanLine.startsWith('- ')) {
      // Handle bullet points with potential key-value pairs
      if (cleanLine.includes(':')) {
        const parts = cleanLine.split(':');
        return (
          <div key={index} className="flex mb-1">
            <span className="font-semibold w-1/3">
              {parts[0].replace(/^-/, '').trim()}:
            </span>
            <span className="w-2/3">{parts.slice(1).join(':').trim()}</span>
          </div>
        );
      } else {
        return (
          <p key={index} className="mb-2 ml-4">
            {cleanLine.substring(2)}
          </p>
        );
      }
    } else if (cleanLine.trim() === '---') {
      // Handle horizontal rule
      return <hr key={index} className="my-4 border-gray-300" />;
    } else if (cleanLine.trim() === '') {
      // Handle empty lines
      return <br key={index} />;
    } else {
      // Default: normal paragraph text
      return (
        <p key={index} className="mb-2 text-gray-700">
          {cleanLine}
        </p>
      );
    }
  });
};

  if (!supplier) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <p className="text-gray-600">No supplier selected for risk profile</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800">
            ⚠️ Risk Profile: {supplier.supplier_name}
          </h2>
          <p className="text-gray-600">AI-powered comprehensive risk assessment and intelligence</p>
        </div>
        <button
          onClick={onBack}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
        >
          ← Back to Overview
        </button>
      </div>

      {isLoading && (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          <span className="ml-3 text-gray-600">Generating comprehensive risk profile...</span>
        </div>
      )}

      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p>Error: {error}</p>
          <button 
            onClick={fetchRiskProfile}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
          >
            Retry
          </button>
        </div>
      )}

      {riskProfileData && (
        <div className="border border-gray-200 rounded-lg p-6 bg-white">
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-sm text-blue-600">Analysis Confidence</p>
              <p className="text-lg font-semibold">{riskProfileData.confidence?.toUpperCase() || 'MEDIUM'}</p>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-sm text-blue-600">Data Sources</p>
              <p className="text-lg font-semibold">{riskProfileData.sources?.length || 0}</p>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-sm text-blue-600">Generated</p>
              <p className="text-lg font-semibold">
                {riskProfileData.generated_at ? new Date(riskProfileData.generated_at).toLocaleDateString() : 'N/A'}
              </p>
            </div>
          </div>

          <div className="prose max-w-none text-gray-700">
            {formatRiskProfileText(riskProfileData.risk_profile)}
          </div>


          {(riskProfileData.sources || riskProfileData.reasoning_chain) && (
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              {riskProfileData.sources && riskProfileData.sources.length > 0 && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">Analysis Sources</h3>
                  <ul className="list-disc pl-5">
                    {riskProfileData.sources.map((source, index) => (
                      <li key={index} className="mb-1">{source}</li>
                    ))}
                  </ul>
                </div>
              )}

              {riskProfileData.reasoning_chain && riskProfileData.reasoning_chain.length > 0 && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">Analysis Reasoning</h3>
                  <ol className="list-decimal pl-5">
                    {riskProfileData.reasoning_chain.map((step, index) => (
                      <li key={index} className="mb-1">{step}</li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const SupplierRiskDashboard = () => {
  const [activeView, setActiveView] = useState('dashboard');
  const [filterOptions, setFilterOptions] = useState({
    risk_types: [],
    materials: [],
    countries: [],
    months: []
  });
  const [filters, setFilters] = useState({
    risk_type: 'overall',
    material: null,
    country: null,
    month: null
  });
  const [overviewStats, setOverviewStats] = useState(null);
  const [suppliers, setSuppliers] = useState([]);
  const [selectedSupplier, setSelectedSupplier] = useState(null);
  const [selectedRiskTable, setSelectedRiskTable] = useState(null);
  const [recentAlerts, setRecentAlerts] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [supplierDetails, setSupplierDetails] = useState(null);
  const [riskData, setRiskData] = useState(null);
  const [trendFilters, setTrendFilters] = useState({
    risk_type: 'overall'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [historicalData, setHistoricalData] = useState(null);
  const [overallHistoricalData, setOverallHistoricalData] = useState(null);
  const [selectedKpi, setSelectedKpi] = useState('');
  const [availableKpis, setAvailableKpis] = useState([]);
  const [activeMainTab, setActiveMainTab] = useState(0);
  const [selectedSupplierForRiskProfile, setSelectedSupplierForRiskProfile] = useState(null);

  // Chatbot state
  const [chatMessages, setChatMessages] = useState([]);
  const [userInput, setUserInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isChatMaximized, setIsChatMaximized] = useState(false);
  const chatContainerRef = useRef(null);

  useEffect(() => {
    fetchFilterOptions();
    fetchOverviewStats();
    fetchSuppliers();
    fetchRecentAlerts();
  }, []);

  useEffect(() => {
    fetchOverviewStats();
    fetchSuppliers();
  }, [filters]);

  useEffect(() => {
    if (selectedSupplier) {
      fetchHistoricalData(selectedSupplier.supplier_name, trendFilters.risk_type, setHistoricalData);
      fetchHistoricalData(selectedSupplier.supplier_name, 'overall', setOverallHistoricalData);
    }
  }, [selectedSupplier, trendFilters.risk_type]);

  useEffect(() => {
  if (riskData && riskData.length > 0) {
    const numericColumns = Object.keys(riskData[0]).filter(key => {
      return typeof riskData[0][key] === 'number' &&
             !key.includes('_id') &&
             !key.includes('score') &&
             !key.includes('level');
    });
    
    setAvailableKpis(numericColumns);
    
    // Set default to risk score for the selected risk type
    const riskScoreKpi = `${selectedRiskTable}_risk_score`;
    if (riskData[0][riskScoreKpi] !== undefined) {
      setSelectedKpi(riskScoreKpi);
    } else if (numericColumns.length > 0) {
      setSelectedKpi(numericColumns[0]);
    }
  }
}, [riskData]);


  useEffect(() => {
    // Scroll to bottom when new messages are added
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const fetchFilterOptions = async () => {
    const data = await apiClient.get('/api/dashboard/filter-options');
    if (data) setFilterOptions(data);
  };

  const fetchOverviewStats = async () => {
    const params = new URLSearchParams({ risk_type: filters.risk_type });
    if (filters.material) params.append('material', filters.material);
    if (filters.country) params.append('country', filters.country);
    if (filters.month) params.append('month', filters.month);
   
    const data = await apiClient.get(`/api/dashboard/overview-stats?${params}`);
    if (data) setOverviewStats(data);
  };

  const fetchSuppliers = async () => {
    const params = new URLSearchParams({ risk_type: filters.risk_type });
    if (filters.material) params.append('material', filters.material);
    if (filters.country) params.append('country', filters.country);
    if (filters.month) params.append('month', filters.month);
   
    const data = await apiClient.get(`/api/dashboard/suppliers?${params}`);
    if (data) setSuppliers(data);
  };

  const fetchHistoricalData = async (supplierName, riskType, setDataFunction) => {
    const data = await apiClient.get(`/api/dashboard/risk-data/${riskType}/${supplierName}`);
    if (data) setDataFunction(data);
  };

  const fetchRecentAlerts = async () => {
    const data = await apiClient.get('/api/dashboard/recent-dashboard-alerts');
    if (data) {
      if (Array.isArray(data)) {
        setRecentAlerts(data);
      } else {
        setRecentAlerts(data.alerts || []);
        setLastUpdated(data.last_updated);
      }
    }
  };

  const refreshAlerts = async () => {
    setIsLoading(true);
    const data = await apiClient.post('/api/dashboard/refresh-dashboard-alerts', {});
    if (data && data.success) {
      fetchRecentAlerts();
    }
    setIsLoading(false);
  };

  const fetchSupplierDetails = async (supplierName) => {
    const data = await apiClient.get(`/api/dashboard/supplier/${supplierName}`);
    if (data) setSupplierDetails(data);
  };

  const fetchRiskData = async (riskType, supplierName) => {
    const data = await apiClient.get(`/api/dashboard/risk-data/${riskType}/${supplierName}`);
    if (data) {
      setRiskData(data);
     
      // Set default KPI based on risk type
      if (riskType === 'financial') {
        setSelectedKpi('liquidity_ratio');
      } else if (riskType === 'performance') {
        setSelectedKpi('on_time_delivery');
      } else if (riskType === 'geopolitical') {
        setSelectedKpi('political_stability');
      }
    }
  };

  const createAlert = async (supplierName) => {
    const data = await apiClient.post('/api/dashboard/alert', {
      supplier_name: supplierName,
      risk_type: 'overall',
      severity: 'HIGH'
    });
   
    if (data && data.success) {
      alert(`Alert created for ${supplierName}`);
    } else {
      alert(`Failed to create alert for ${supplierName}`);
    }
  };

  // Chatbot functions
  const sendChatMessage = async () => {
    if (!userInput.trim() || isChatLoading) return;
   
    const newMessage = {
      role: 'user',
      content: userInput.trim(),
      timestamp: new Date().toISOString()
    };
   
    // Add user message to chat
    setChatMessages(prev => [...prev, newMessage]);
    setUserInput('');
    setIsChatLoading(true);
   
    try {
      // Get or create user ID from localStorage
      let userId = localStorage.getItem('chat_user_id');
      if (!userId) {
        userId = Math.random().toString(36).substring(2, 15);
        localStorage.setItem('chat_user_id', userId);
      }
     
      // Get conversation ID from localStorage or create new
      let conversationId = localStorage.getItem('chat_conversation_id');
      if (!conversationId) {
        conversationId = Math.random().toString(36).substring(2, 15);
        localStorage.setItem('chat_conversation_id', conversationId);
      }
     
      // Prepare request data
      const requestData = {
        user_id: userId,
        query: userInput.trim(),
        conversation_id: conversationId,
        context: {
          supplier_name: selectedSupplier?.supplier_name || null,
          risk_type: filters.risk_type
        }
      };
     
      // Send message to chatbot API
      const response = await apiClient.post('/api/chat', requestData);
     
      if (response && !response.error) {
        // Add bot response to chat
        const botMessage = {
          role: 'assistant',
          content: response.response,
          timestamp: new Date().toISOString(),
          sources: response.sources,
          confidence: response.confidence
        };
       
        setChatMessages(prev => [...prev, botMessage]);
      } else {
        throw new Error(response?.error || 'Failed to get response from chatbot');
      }
    } catch (error) {
      console.error('Chat error:', error);
     
      // Add error message
      const errorMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        timestamp: new Date().toISOString(),
        isError: true
      };
     
      setChatMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  };

  const clearChat = () => {
    setChatMessages([]);
    localStorage.removeItem('chat_conversation_id');
  };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
    if (!isChatOpen) {
      setIsChatMaximized(false);
    }
  };

  const toggleChatMaximize = () => {
    setIsChatMaximized(!isChatMaximized);
  };

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value === 'All' ? null : value
    }));
  };

  const handleSupplierSelect = (supplier) => {
    setSelectedSupplier(supplier);
    setSelectedRiskTable(null);
    setActiveMainTab(1); // Switch to Supplier Details tab
    fetchSupplierDetails(supplier.supplier_name);
  };

  const handleRiskTableSelect = (riskType) => {
    setSelectedRiskTable(riskType);
    setActiveMainTab(2); // Switch to Risk Deep Dive tab
    if (selectedSupplier) {
      fetchRiskData(riskType, selectedSupplier.supplier_name);
    }
  };

  const handleRiskProfileClick = (supplier) => {
    setSelectedSupplierForRiskProfile(supplier);
    setActiveMainTab(3); // Switch to Risk Profile tab
  };

  const handleTrendFilterChange = (filterName, value) => {
    setTrendFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };

  const handleKpiChange = (kpi) => {
    setSelectedKpi(kpi);
  };

  const clearFilters = () => {
    setFilters({
      risk_type: 'overall',
      material: null,
      country: null,
      month: null
    });
  };

  const renderHeader = () => (
    <div className="bg-gradient-to-r from-blue-800 to-blue-600 shadow-sm py-6 px-6">
      <h1 className="text-3xl font-bold text-white">Supplier Risk Management</h1>
      <p className="text-blue-100 mt-2">AI-Powered Risk Assessment & Real-time Monitoring Platform</p>
    </div>
  );

  const renderFilters = () => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Overview</h2>
     
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Risk Type</label>
          <select
            value={filters.risk_type}
            onChange={(e) => handleFilterChange('risk_type', e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            {filterOptions.risk_types?.map((type) => (
              <option key={type} value={type}>{capitalizeFirstLetters(type)}</option>
            ))}
          </select>
        </div>
       
        <div className="md:col-span-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">Material</label>
          <select
            value={filters.material || 'All'}
            onChange={(e) => handleFilterChange('material', e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="All">All</option>
            {filterOptions.materials?.map((material) => (
              <option key={material} value={material}>{material}</option>
            ))}
          </select>
        </div>
       
        <div className="md:col-span-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
          <select
            value={filters.country || 'All'}
            onChange={(e) => handleFilterChange('country', e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="All">All</option>
            {filterOptions.countries?.map((country) => (
              <option key={country} value={country}>{country}</option>
            ))}
          </select>
        </div>
       
        <div className="md:col-span-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">Month</label>
          <select
            value={filters.month || 'All'}
            onChange={(e) => handleFilterChange('month', e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="All">All</option>
            {filterOptions.months?.map((month) => (
              <option key={month} value={month}>{month}</option>
            ))}
          </select>
        </div>
       
        <div className="md:col-span-1 flex items-end">
          <button
            onClick={clearFilters}
            className="w-full py-2 px-4 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
          >
            Clear All
          </button>
        </div>
      </div>
    </div>
  );

  const renderOverviewMetrics = () => {
    if (!overviewStats) return <div>Loading statistics...</div>;
   
    const activeFilters = [];
    if (filters.material) activeFilters.push(`Material: ${filters.material}`);
    if (filters.country) activeFilters.push(`Country: ${filters.country}`);
    if (filters.month) activeFilters.push(`Month: ${filters.month}`);
   
    return (
      <div className="mb-6">
        {activeFilters.length > 0 && (
          <div className="text-sm text-gray-600 mb-4">
            Active Filters: {activeFilters.join(' • ')} | {overviewStats.total_suppliers || 0} suppliers found
          </div>
        )}
       
        {(overviewStats.CRITICAL > 0 || overviewStats.HIGH > 0) && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 text-center font-bold">
  <p>Risk Alert: {(overviewStats.CRITICAL || 0) + (overviewStats.HIGH || 0)} supplier require immediate attention</p>
</div>

        )}
       
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-sm border-t-4 border-red-500 border border-gray-200">
            <h3 className="text-lg font-semibold text-red-600">CRITICAL</h3>
            <p className="text-3xl font-bold">{overviewStats.CRITICAL || 0}</p>
          </div>
         
          <div className="bg-white p-4 rounded-lg shadow-sm border-t-4 border-orange-500 border border-gray-200">
            <h3 className="text-lg font-semibold text-orange-600">HIGH RISK</h3>
            <p className="text-3xl font-bold">{overviewStats.HIGH || 0}</p>
          </div>
         
          <div className="bg-white p-4 rounded-lg shadow-sm border-t-4 border-yellow-500 border border-gray-200">
            <h3 className="text-lg font-semibold text-yellow-600">MEDIUM</h3>
            <p className="text-3xl font-bold">{overviewStats.MEDIUM || 0}</p>
          </div>
         
          <div className="bg-white p-4 rounded-lg shadow-sm border-t-4 border-green-500 border border-gray-200">
            <h3 className="text-lg font-semibold text-green-600">LOW RISK</h3>
            <p className="text-3xl font-bold">{overviewStats.LOW || 0}</p>
          </div>
        </div>
      </div>
    );
  };

  const renderRecentAlerts = () => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
      <div className="flex flex-col mb-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">Recent Alerts</h2>
          <div className="flex space-x-2">
            <button
              onClick={async () => {
                const data = await apiClient.get('/api/dashboard/recent-dashboard-alerts');
                let updatedDate = null;

                if (data && data.last_updated) {
                  // Backend returns {alerts: [...], last_updated: "..."}
                  updatedDate = data.last_updated;
                } else if (Array.isArray(data) && data.length > 0) {
                  // Backend returns plain array — use the latest alert's date
                  const latestAlert = data.reduce((latest, alert) =>
                    new Date(alert.date) > new Date(latest.date) ? alert : latest, data[0]);
                  updatedDate = latestAlert.date;
                }

                if (updatedDate) {
                  const dateStr = new Date(updatedDate).toLocaleString();
                  alert("Alerts Last Updated: " + dateStr + " UTC");
                  setLastUpdated(updatedDate);
                } else {
                  alert("No update date available. Please click 'Refresh Alerts' first to fetch new data.");
                }
              }}
              className="px-4 py-2 bg-gray-100 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-200 transition-colors"
            >
              Check Last Updated
            </button>
            <button
              onClick={refreshAlerts}
              disabled={isLoading}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {isLoading ? 'Refreshing...' : 'Refresh Alerts'}
            </button>
          </div>
        </div>
        {lastUpdated && (
          <div className="text-sm text-gray-500 mt-2 text-right">
            Last Fetch Date: {new Date(lastUpdated).toLocaleString()}
          </div>
        )}
      </div>
     
      {recentAlerts.length > 0 ? (
        <div className="space-y-4">
          {recentAlerts.map((alert, index) => (
            <div key={index} className="border-l-4 border-red-500 pl-4 py-2">
              <h3 className="font-semibold">{alert.title || 'Alert'}</h3>
              <p className="text-gray-600">{alert.summary || 'No description available'}</p>
              {alert.date && (
                <p className="text-xs text-gray-400 mt-1">
                  📅 {new Date(alert.date).toLocaleString()}
                </p>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-600">No recent alerts available. Click refresh to gather latest intelligence.</p>
      )}
    </div>
  );

  const renderSupplierOverview = () => (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">
        Supplier {capitalizeFirstLetters(filters.risk_type)} Risk Overview
      </h2>
     
      {selectedSupplier ? (
        <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4">
          <p>{selectedSupplier.supplier_name} selected! View the detailed analysis in the Supplier Details tab.</p>
        </div>
      ) : (
        <p className="text-gray-600 mb-4">
          Tip: Click on any supplier name, then switch to the 'Supplier Details' tab to view detailed analysis
        </p>
      )}
     
      {suppliers.length > 0 ? (
        <div className="space-y-4">
          {suppliers.map((supplier, index) => (
            <div key={index} className="border-b border-gray-200 pb-4 last:border-b-0">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                <div className="md:col-span-2">
                  <button
                    onClick={() => handleSupplierSelect(supplier)}
                    className={`text-blue-600 hover:text-blue-800 font-medium ${selectedSupplier?.supplier_name === supplier.supplier_name ? 'underline' : ''}`}
                  >
                    {supplier.supplier_name} {selectedSupplier?.supplier_name === supplier.supplier_name && '(Selected)'}
                  </button>
                </div>
               
                <div>
                  <span className="text-gray-600">Score: </span>
                  <span>{supplier.risk_score?.toFixed(1) || 'N/A'}</span>
                </div>
               
                <div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    supplier.risk_level === 'CRITICAL' ? 'bg-red-100 text-red-800' :
                    supplier.risk_level === 'HIGH' ? 'bg-orange-100 text-orange-800' :
                    supplier.risk_level === 'MEDIUM' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {supplier.risk_level}
                  </span>
                </div>
               
                <div className="flex space-x-2">
                  <button
                    onClick={() => createAlert(supplier.supplier_name)}
                    className="px-3 py-1 bg-red-100 text-red-700 rounded-md text-sm hover:bg-red-200"
                  >
                    Alert
                  </button>
                  <button
                    onClick={() => handleRiskProfileClick(supplier)}
                    className="px-3 py-1 bg-blue-100 text-blue-700 rounded-md text-sm hover:bg-blue-200"
                  >
                    Risk Profile
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-600">No suppliers found matching the current filters.</p>
      )}
    </div>
  );

  const renderSupplierDetails = () => {
    if (!selectedSupplier) {
      return (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
          <p className="text-gray-600">Select a supplier from the Overview tab to view detailed analysis</p>
        </div>
      );
    }
   
    if (!supplierDetails) {
      return (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
          <p className="text-gray-600">Loading supplier details...</p>
        </div>
      );
    }
   
    const riskLevel = supplierDetails.risk_level || supplierDetails.overall_risk_level || 'UNKNOWN';
   
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-800">
              {selectedSupplier.supplier_name} - Risk Analysis Dashboard
            </h2>
            <p className="text-gray-600">Comprehensive supplier risk assessment and breakdown</p>
          </div>
          <button
            onClick={() => {
              setSelectedSupplier(null);
              setActiveMainTab(0);
            }}
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
          >
            Back to Overview
          </button>
        </div>
       
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <p className="text-sm text-gray-600">Overall Risk Score</p>
            <p className="text-2xl font-bold">{supplierDetails.overall_risk_score?.toFixed(1) || 'N/A'}</p>
          </div>
         
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <p className="text-sm text-gray-600">Risk Level</p>
            <p className="text-2xl font-bold">{riskLevel}</p>
          </div>
         
          <div className="bg-gray-50 p-4 rounded-lg md:col-span-2 border border-gray-200">
            <p className="text-sm text-gray-600">Last Updated</p>
            <p className="text-2xl font-bold">{supplierDetails.update_date || 'N/A'}</p>
          </div>
         
          <div className="md:col-span-2 flex items-center justify-end">
            <button
              onClick={() => createAlert(selectedSupplier.supplier_name)}
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
            >
              Create Alert
            </button>
          </div>
        </div>
       
        <div className="border-t border-gray-200 pt-6 mb-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Risk Breakdown Analysis</h3>
          <p className="text-gray-600 mb-4">
            Click on any risk score below to view detailed analysis in the Deep Dive tab
          </p>
         
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => handleRiskTableSelect('financial')}
              className="p-4 bg-blue-50 rounded-lg text-left hover:bg-blue-100 transition-colors border border-gray-200"
            >
              <h4 className="font-semibold text-blue-800">Financial Risk</h4>
              <p className="text-2xl font-bold">
                Score: {supplierDetails.financial_details?.financial_risk_score?.toFixed(1) || 'N/A'}
              </p>
            </button>
           
            <button
              onClick={() => handleRiskTableSelect('performance')}
              className="p-4 bg-purple-50 rounded-lg text-left hover:bg-purple-100 transition-colors border border-gray-200"
            >
              <h4 className="font-semibold text-purple-800">Performance Risk</h4>
              <p className="text-2xl font-bold">
                Score: {supplierDetails.performance_details?.performance_risk_score?.toFixed(1) || 'N/A'}
              </p>
            </button>
           
            <button
              onClick={() => handleRiskTableSelect('geopolitical')}
              className="p-4 bg-green-50 rounded-lg text-left hover:bg-green-100 transition-colors border border-gray-200"
            >
              <h4 className="font-semibold text-green-800">Geopolitical Risk</h4>
              <p className="text-2xl font-bold">
                Score: {supplierDetails.geopolitical_details?.geopolitical_risk_score?.toFixed(1) || 'N/A'}
              </p>
            </button>
          </div>
        </div>
       
        <div className="border-t border-gray-200 pt-6 mb-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Risk Score Trends</h3>
         
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Risk Type</label>
            <select
              value={trendFilters.risk_type}
              onChange={(e) => handleTrendFilterChange('risk_type', e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="overall">Overall</option>
              <option value="financial">Financial</option>
              <option value="performance">Performance</option>
              <option value="geopolitical">Geopolitical</option>
            </select>
          </div>
         
          <RiskTrendChart
            data={historicalData}
            kpi={trendFilters.risk_type === 'overall' ? 'overall_risk_score' : `${trendFilters.risk_type}_risk_score`}
            supplierName={selectedSupplier.supplier_name}
            riskType={trendFilters.risk_type}
          />
        </div>
       
        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">
            {selectedSupplier.supplier_name} - Comprehensive Risk Summary
          </h3>
          <ComprehensiveRiskTable
            data={overallHistoricalData}
            supplierName={selectedSupplier.supplier_name}
          />
        </div>
      </div>
    );
  };

  const renderRiskDeepDive = () => {
  if (!selectedRiskTable || !selectedSupplier) {
    return (
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
        <p className="text-gray-600">Select a specific risk type from the Supplier Details tab to view deep analysis</p>
      </div>
    );
  }

  const riskIcons = {
    financial: '💰',
    performance: '⚡', 
    geopolitical: '🌍'
  };

  const icon = riskIcons[selectedRiskTable] || '📊';
  
  // Add risk score to available KPIs
  const riskScoreKpi = `${selectedRiskTable}_risk_score`;
  const allAvailableKpis = [riskScoreKpi, ...availableKpis];

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-800">
            {icon} {selectedSupplier.supplier_name} - {capitalizeFirstLetters(selectedRiskTable)} Risk Deep Dive
          </h2>
          <p className="text-gray-600">Detailed KPI trends, historical data, and comprehensive analysis</p>
        </div>
        <button
          onClick={() => {
            setSelectedRiskTable(null);
            setActiveMainTab(1);
          }}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
        >
          Back to Details
        </button>
      </div>

      <div className="mb-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          {capitalizeFirstLetters(selectedRiskTable)} Risk KPI Analysis
        </h3>
        
        {allAvailableKpis.length > 0 && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Select KPI</label>
            <select
              value={selectedKpi}
              onChange={(e) => handleKpiChange(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            >
              {allAvailableKpis.map((kpi) => (
                <option key={kpi} value={kpi}>
                  {kpi === riskScoreKpi 
                    ? `${capitalizeFirstLetters(selectedRiskTable)} Risk Score`
                    : kpi.replace(/_/g, ' ')
                         .split(' ')
                         .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                         .join(' ')}
                </option>
              ))}
            </select>
          </div>
        )}
        
        <RiskTrendChart
          data={riskData}
          kpi={selectedKpi}
          supplierName={selectedSupplier.supplier_name}
          riskType={selectedRiskTable}
        />
      </div>

      <div className="border-t border-gray-200 pt-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">
          {selectedSupplier.supplier_name} - Complete {selectedRiskTable.charAt(0).toUpperCase() + selectedRiskTable.slice(1)} Risk Analysis
        </h3>
        <DetailedRiskTable
          data={riskData}
          riskType={selectedRiskTable}
          supplierName={selectedSupplier.supplier_name}
        />
      </div>
    </div>
  );
};

  const renderRiskProfileTab = () => {
    return (
      <RiskProfileTab 
        supplier={selectedSupplierForRiskProfile} 
        onBack={() => {
          setSelectedSupplierForRiskProfile(null);
          setActiveMainTab(0);
        }}
      />
    );
  };

  const renderChatbot = () => (
    <div className={`bg-white shadow-xl border border-gray-200 ${isChatMaximized ? 'fixed inset-10 z-50 rounded-lg' : 'h-96 w-80 rounded-lg'}`}>
      <div className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
        <h2 className="font-semibold text-lg">Risk Management Assistant</h2>
        <div className="flex space-x-2">
          <button
            onClick={toggleChatMaximize}
            className="text-white hover:text-blue-200 transition-colors"
            title={isChatMaximized ? 'Minimize' : 'Maximize'}
          >
            {isChatMaximized ? '⊖' : '⊕'}
          </button>
          <button
            onClick={toggleChat}
            className="text-white hover:text-blue-200 transition-colors"
            title="Close"
          >
            ✕
          </button>
        </div>
      </div>
     
      <div
        ref={chatContainerRef}
        className={`p-4 overflow-y-auto ${isChatMaximized ? 'h-[calc(100%-8rem)]' : 'h-72'}`}
      >
        {chatMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-gray-500">
            <div className="text-4xl mb-2">🤖</div>
            <p className="text-center text-sm">Hi! I'm your risk management assistant.<br />Ask me about supplier risks, analysis, or recommendations.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {chatMessages.map((message, index) => {
              // Remove markdown formatting from messages
              const cleanContent = message.content.replace(/\*\*/g, '');

                // Function to highlight risk levels with colors
  const highlightRiskLevels = (text) => {
    // Define risk level patterns and their corresponding colors
    const riskLevels = {
      'CRITICAL': 'text-red-800 bg-red-100 px-1 rounded',
      'HIGH RISK': 'text-red-800 bg-red-100 px-1 rounded',
      'HIGH': 'text-red-800 bg-red-100 px-1 rounded',
      'MEDIUM': 'text-yellow-800 bg-yellow-100 px-1 rounded',
      'MODERATE': 'text-yellow-800 bg-yellow-100 px-1 rounded',
      'LOW RISK': 'text-green-800 bg-green-100 px-1 rounded',
      'LOW': 'text-green-800 bg-green-100 px-1 rounded'
    };
    
    // Replace risk level words with styled spans
    let formattedText = text;
    Object.keys(riskLevels).forEach(level => {
      const regex = new RegExp(`\\b${level}\\b`, 'gi');
      formattedText = formattedText.replace(
        regex, 
        `<span class="${riskLevels[level]}">${level}</span>`
      );
    });
    
    return formattedText;
  };


             
                return (
    <div
      key={index}
      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
    >
      <div
        className={`max-w-3/4 rounded-lg p-3 ${message.role === 'user'
          ? 'bg-blue-600 text-white ml-10'
          : message.isError
          ? 'bg-red-100 text-red-800 mr-10'
          : 'bg-gray-100 text-gray-800 mr-10'
        }`}
      >
        <div 
          className="whitespace-pre-wrap text-base leading-relaxed"
          dangerouslySetInnerHTML={{ 
            __html: highlightRiskLevels(cleanContent).split('\n').map((line, i) => {
              // Check if line looks like a header
              if (line.match(/^[A-Z][A-Za-z\s]+:/) ||
                  line.match(/^Key Findings:/) ||
                  line.match(/^Strategic Recommendations:/) ||
                  line.match(/^Potential Business Impact:/)) {
                return `<div class="font-semibold text-lg mb-1 mt-2 first:mt-0">${line}</div>`;
              }
              // Check if line looks like a bullet point
              else if (line.trim().startsWith('-')) {
                return `<div class="ml-4">• ${line.substring(1).trim()}</div>`;
              }
              // Regular paragraph
              else {
                return `<div class="mb-2 last:mb-0">${line}</div>`;
              }
            }).join('')
          }}
        />
        {message.sources && message.sources.length > 0 && (
          <div className="mt-2 text-xs opacity-70">
            Sources: {message.sources.join(', ')}
          </div>
        )}
        {message.confidence && (
          <div className="mt-1 text-xs opacity-70">
            Confidence: {message.confidence}
          </div>
        )}
      </div>
    </div>
  );

            })}
            {isChatLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-lg p-3 text-gray-800 mr-10">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{animationDelay: '0.4s'}}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
     
      <div className="p-4 border-t border-gray-200">
        <div className="flex">
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask about supplier risks..."
            className="flex-1 p-3 border border-gray-300 rounded-l-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
            disabled={isChatLoading}
          />
          <button
            onClick={sendChatMessage}
            disabled={isChatLoading || !userInput.trim()}
            className="px-4 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isChatLoading ? '...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );

  const renderMainContent = () => {
    switch (activeMainTab) {
      case 0:
        return renderSupplierOverview();
      case 1:
        return renderSupplierDetails();
      case 2:
        return renderRiskDeepDive();
      case 3:
        return renderRiskProfileTab();
      default:
        return renderSupplierOverview();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {renderHeader()}
     
      <div className="container mx-auto px-4 py-6">
        {renderFilters()}
        {renderOverviewMetrics()}
        {renderRecentAlerts()}
       
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex -mb-px">
              <button
                className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
                  activeMainTab === 0
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => setActiveMainTab(0)}
              >
                Supplier Overview
              </button>
              <button
                className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
                  activeMainTab === 1
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => selectedSupplier && setActiveMainTab(1)}
                disabled={!selectedSupplier}
              >
                Supplier Details
              </button>
              <button
                className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
                  activeMainTab === 2
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => selectedRiskTable && setActiveMainTab(2)}
                disabled={!selectedRiskTable}
              >
                Risk Deep Dive
              </button>
              <button
                className={`py-4 px-6 text-center font-medium text-sm border-b-2 ${
                  activeMainTab === 3
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
                onClick={() => selectedSupplierForRiskProfile && setActiveMainTab(3)}
                disabled={!selectedSupplierForRiskProfile}
              >
                Risk Profile
              </button>
            </nav>
          </div>
         
          <div className="p-6">
            {renderMainContent()}
          </div>
        </div>
      </div>

      {/* Floating Chatbot Button */}
      {!isChatOpen && (
        <button
          onClick={toggleChat}
          className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors z-40"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        </button>
      )}

      {/* Chatbot Window */}
      {isChatOpen && (
        <div className={`fixed z-50 ${isChatMaximized ? 'bottom-6 right-6' : 'bottom-6 right-6'}`}>
          {renderChatbot()}
        </div>
      )}
    </div>
  );
};

export default SupplierRiskDashboard;