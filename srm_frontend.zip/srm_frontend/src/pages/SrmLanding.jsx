import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../assets/logo.png';

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'https://ae-etl-srmdemo-app-01.azurewebsites.net').replace(/\/+$/, '');

// Ensure every endpoint path has the /api prefix
const apiPath = (endpoint) =>
  endpoint.startsWith('/api/')
    ? endpoint
    : `/api${endpoint.startsWith('/') ? endpoint : '/' + endpoint}`;
    
const apiClient = {
  get: async (endpoint) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`API Error (GET ${endpoint}):`, error);
      return null;
    }
  },
  post: async (endpoint, data) => {
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return await response.json();
    } catch (error) {
      console.error(`API Error (POST ${endpoint}):`, error);
      return null;
    }
  }
};

function SupplierRiskManagement() {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Chatbot state (from dashboard)
  const [chatMessages, setChatMessages] = useState([
    { role: 'assistant', content: "Hello! I'm your risk management assistant. How can I help you with supplier risk management today?", timestamp: new Date().toISOString() }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isChatMaximized, setIsChatMaximized] = useState(false);
  const chatContainerRef = useRef(null);
  
  const [currentSlide, setCurrentSlide] = useState(0);

  // Carousel data with supplier risk management images
  const carouselItems = [
    {
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      title: "Real-Time Risk Intelligence",
      description: "Stay ahead of supply chain disruptions with instant alerts and comprehensive risk scoring across financial, operational, and geopolitical dimensions powered by continuous monitoring."
    },
    {
      image: "https://images.unsplash.com/photo-1573164713988-8665fc963095?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1169&q=80",
      title: "Multi-Agent AI Orchestration",
      description: "Comprehensive financial anLeverage a network of specialized AI agents working collaboratively to analyze complex risk patterns and deliver precise, actionable insights from diverse data sources."
    },
    {
      image: "https://images.unsplash.com/photo-1560472355-536de3962603?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      title: "Interactive Decision Dashboards",
      description: "Empower stakeholders with dynamic visualizations, customizable drill-downs, and intuitive filtering capabilities that transform complex risk data into clear business intelligence."
    },
    {
      image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
      title: "Predictive Risk Mitigation",
      description: "Anticipate and prevent supplier disruptions through advanced pattern recognition, trend forecasting, and automated strategic recommendations tailored to your risk profile."
    }
  ];

  // Auto-advance carousel
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev === carouselItems.length - 1 ? 0 : prev + 1));
    }, 5000);
    return () => clearInterval(timer);
  }, [carouselItems.length]);

  useEffect(() => {
    // Scroll to bottom when new messages are added
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  // Chatbot functions (from dashboard)
  const sendChatMessage = async () => {
    if (!userInput.trim() || isChatLoading) return;
   
    const newMessage = {
      role: 'user',
      content: userInput.trim(),
      timestamp: new Date().toISOString()
    };
   
    // Add user message to chat
    setChatMessages(prev => [...prev, newMessage]);
    setUserInput('');
    setIsChatLoading(true);
   
    try {
      // Get or create user ID from localStorage
      let userId = localStorage.getItem('chat_user_id');
      if (!userId) {
        userId = Math.random().toString(36).substring(2, 15);
        localStorage.setItem('chat_user_id', userId);
      }
     
      // Get conversation ID from localStorage or create new
      let conversationId = localStorage.getItem('chat_conversation_id');
      if (!conversationId) {
        conversationId = Math.random().toString(36).substring(2, 15);
        localStorage.setItem('chat_conversation_id', conversationId);
      }
     
      // Prepare request data
      const requestData = {
        user_id: userId,
        query: userInput.trim(),
        conversation_id: conversationId,
        context: {
          // No specific supplier context on landing page
          risk_type: 'general'
        }
      };
     
      // Send message to chatbot API
      const response = await apiClient.post('/api/chat', requestData);
     
      if (response && !response.error) {
        // Add bot response to chat
        const botMessage = {
          role: 'assistant',
          content: response.response,
          timestamp: new Date().toISOString(),
          sources: response.sources,
          confidence: response.confidence
        };
       
        setChatMessages(prev => [...prev, botMessage]);
      } else {
        throw new Error(response?.error || 'Failed to get response from chatbot');
      }
    } catch (error) {
      console.error('Chat error:', error);
     
      // Add error message
      const errorMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        timestamp: new Date().toISOString(),
        isError: true
      };
     
      setChatMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  };

  const clearChat = () => {
    setChatMessages([
      { role: 'assistant', content: "Hello! I'm your risk management assistant. How can I help you with supplier risk management today?", timestamp: new Date().toISOString() }
    ]);
    localStorage.removeItem('chat_conversation_id');
  };

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
    if (!isChatOpen) {
      setIsChatMaximized(false);
    }
  };

  const toggleChatMaximize = () => {
    setIsChatMaximized(!isChatMaximized);
  };

  const nextSlide = () => {
    setCurrentSlide((prevSlide) =>
      prevSlide === carouselItems.length - 1 ? 0 : prevSlide + 1
    );
  };

  const prevSlide = () => {
    setCurrentSlide((prevSlide) =>
      prevSlide === 0 ? carouselItems.length - 1 : prevSlide - 1
    );
  };

  const handleGetDashboard = () => {
    navigate('/srmdashboard');
  };

  // Render chatbot (from dashboard with same styling)
  const renderChatbot = () => (
  <div className={`bg-white shadow-xl border border-gray-200 ${isChatMaximized ? 'fixed inset-10 z-50 rounded-lg' : 'h-96 w-80 rounded-lg'}`}>
    <div className="flex justify-between items-center p-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
      <h2 className="font-semibold text-lg">Risk Management Assistant</h2>
      <div className="flex space-x-2">
        <button
          onClick={toggleChatMaximize}
          className="text-white hover:text-blue-200 transition-colors"
          title={isChatMaximized ? 'Minimize' : 'Maximize'}
        >
          {isChatMaximized ? '⊖' : '⊕'}
        </button>
        <button
          onClick={toggleChat}
          className="text-white hover:text-blue-200 transition-colors"
          title="Close"
        >
          ✕
        </button>
      </div>
    </div>
   
    <div
      ref={chatContainerRef}
      className={`p-4 overflow-y-auto ${isChatMaximized ? 'h-[calc(100%-8rem)]' : 'h-72'}`}
    >
      {chatMessages.length === 0 ? (
        <div className="h-full flex flex-col items-center justify-center text-gray-500">
          <div className="text-4xl mb-2">🤖</div>
          <p className="text-center text-sm">Hi! I'm your risk management assistant.<br />Ask me about supplier risks, analysis, or recommendations.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {chatMessages.map((message, index) => {
            // Remove markdown formatting from messages
            const cleanContent = message.content.replace(/\*\*/g, '');
            

            const highlightRiskLevels = (text) => {
    // Define risk level patterns and their corresponding colors
    const riskLevels = {
      'CRITICAL': 'text-red-800 bg-red-100 px-1 rounded',
      'HIGH RISK': 'text-red-800 bg-red-100 px-1 rounded',
      'HIGH': 'text-red-800 bg-red-100 px-1 rounded',
      'MEDIUM': 'text-yellow-800 bg-yellow-100 px-1 rounded',
      'MODERATE': 'text-yellow-800 bg-yellow-100 px-1 rounded',
      'LOW RISK': 'text-green-800 bg-green-100 px-1 rounded',
      'LOW': 'text-green-800 bg-green-100 px-1 rounded'
    };
    
    // Replace risk level words with styled spans
    let formattedText = text;
    Object.keys(riskLevels).forEach(level => {
      const regex = new RegExp(`\\b${level}\\b`, 'gi');
      formattedText = formattedText.replace(
        regex, 
        `<span class="${riskLevels[level]}">${level}</span>`
      );
    });
    
    return formattedText;
  };

            return (
    <div
      key={index}
      className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
    >
      <div
        className={`max-w-3/4 rounded-lg p-3 ${message.role === 'user'
          ? 'bg-blue-600 text-white ml-10'
          : message.isError
          ? 'bg-red-100 text-red-800 mr-10'
          : 'bg-gray-100 text-gray-800 mr-10'
        }`}
      >
        <div 
          className="whitespace-pre-wrap text-base leading-relaxed"
          dangerouslySetInnerHTML={{ 
            __html: highlightRiskLevels(cleanContent).split('\n').map((line, i) => {
              // Check if line looks like a header
              if (line.match(/^[A-Z][A-Za-z\s]+:/) ||
                  line.match(/^Key Findings:/) ||
                  line.match(/^Strategic Recommendations:/) ||
                  line.match(/^Potential Business Impact:/)) {
                return `<div class="font-semibold text-lg mb-1 mt-2 first:mt-0">${line}</div>`;
              }
              // Check if line looks like a bullet point
              else if (line.trim().startsWith('-')) {
                return `<div class="ml-4">• ${line.substring(1).trim()}</div>`;
              }
              // Regular paragraph
              else {
                return `<div class="mb-2 last:mb-0">${line}</div>`;
              }
            }).join('')
          }}
        />
        {message.sources && message.sources.length > 0 && (
          <div className="mt-2 text-xs opacity-70">
            Sources: {message.sources.join(', ')}
          </div>
        )}
        {message.confidence && (
          <div className="mt-1 text-xs opacity-70">
            Confidence: {message.confidence}
          </div>
        )}
      </div>
    </div>
  );

          })}
          {isChatLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 rounded-lg p-3 text-gray-800 mr-10">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{animationDelay: '0.4s'}}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
   
    <div className="p-4 border-t border-gray-200">
      <div className="flex">
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask about supplier risks..."
          className="flex-1 p-3 border border-gray-300 rounded-l-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
          disabled={isChatLoading}
        />
        <button
          onClick={sendChatMessage}
          disabled={isChatLoading || !userInput.trim()}
          className="px-4 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isChatLoading ? '...' : 'Send'}
        </button>
      </div>
    </div>
  </div>
);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-blue-900 text-white py-4 px-6 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <img src={logo} alt="NTT DATA Logo" className="h-10 w-auto" />
          </div>
         
          {/* Desktop Navigation */}
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              <li className="hover:text-blue-300 transition-colors cursor-pointer">Home</li>
              <li className="hover:text-blue-300 transition-colors cursor-pointer">Solutions</li>
              <li className="hover:text-blue-300 transition-colors cursor-pointer">About</li>
              <li className="hover:text-blue-300 transition-colors cursor-pointer">Contact</li>
            </ul>
          </nav>
         
          {/* Mobile menu button */}
          <button
            className="md:hidden text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? '✕' : '☰'}
          </button>
        </div>
       
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 bg-blue-800 rounded-lg p-4">
            <ul className="flex flex-col space-y-3">
              <li className="hover:text-blue-300 transition-colors cursor-pointer py-2">Home</li>
              <li className="hover:text-blue-300 transition-colors cursor-pointer py-2">Solutions</li>
              <li className="hover:text-blue-300 transition-colors cursor-pointer py-2">About</li>
              <li className="hover:text-blue-300 transition-colors cursor-pointer py-2">Contact</li>
            </ul>
          </nav>
        )}
      </header>

      {/* Hero Section with Wider Carousel */}
      <section className="py-12 px-6 bg-blue-900 text-white">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-2/5 mb-10 md:mb-0">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6">Supplier Risk Management</h2>
              <p className="text-lg md:text-xl mb-8 text-blue-100">
                Transform supply chain resilience with our AI-powered platform that combines multi-agent
                intelligence, real-time external monitoring, and predictive analytics to identify, assess, and mitigate
                supplier risks before they impact your business operations.
              </p>
              <button
                onClick={handleGetDashboard}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg transition-all transform hover:scale-105"
              >
                Get Dashboard
              </button>
            </div>
           
            {/* Wider Carousel Section */}
            <div className="md:w-3/5 md:pl-10">
              <div className="relative w-full bg-white rounded-xl shadow-lg overflow-hidden border border-blue-100">
                <div className="flex flex-col md:flex-row">
                  {/* Image part - wider */}
                  <div className="md:w-3/5 relative">
                    <img
                      src={carouselItems[currentSlide].image}
                      alt={carouselItems[currentSlide].title}
                      className="w-full h-56 object-cover"
                    />
                   
                    {/* Navigation Buttons */}
                    <button
                      onClick={prevSlide}
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white p-2 rounded-full shadow-md hover:bg-blue-700 transition-colors"
                    >
                      ‹
                    </button>
                    <button
                      onClick={nextSlide}
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 text-white p-2 rounded-full shadow-md hover:bg-blue-700 transition-colors"
                    >
                      ›
                    </button>
                   
                    {/* Indicators */}
                    <div className="absolute bottom-2 left-0 right-0 flex justify-center space-x-2">
                      {carouselItems.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentSlide(index)}
                          className={`w-3 h-3 rounded-full ${currentSlide === index ? 'bg-blue-600' : 'bg-gray-300'}`}
                          aria-label={`Go to slide ${index + 1}`}
                        />
                      ))}
                    </div>
                  </div>
                 
                  {/* Content part - narrower */}
                  <div className="md:w-2/5 p-4 flex flex-col justify-center">
                    <h3 className="text-xl font-bold text-blue-900 mb-2">
                      {carouselItems[currentSlide].title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-4">
                      {carouselItems[currentSlide].description}
                    </p>
                    <button className="self-start bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm">
                      Learn More
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section className="py-12 md:py-16 px-6">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-blue-900 mb-12">Our Solutions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-blue-100 transition-transform hover:scale-105">
              <div className="text-blue-600 mb-4 text-3xl">🌍</div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">Intelligent Risk Monitoring</h3>
              <p className="text-gray-600">
                Continuous real-time surveillance of supplier financial health, operational performance, and
                geopolitical stability with multi-dimensional risk scoring and automated alert systems for proactive
                risk identification.
              </p>
            </div>
           
            <div className="bg-white p-6 rounded-xl shadow-lg border border-blue-100 transition-transform hover:scale-105">
              <div className="text-blue-600 mb-4 text-3xl">🔍</div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">AI-Powered Analytics & Insights</h3>
              <p className="text-gray-600">
                Advanced predictive analytics platform leveraging multi-agent AI orchestration to identify risk
                patterns, forecast disruptions, and provide cross-dimensional correlation analysis for strategic
                decision-making.
              </p>
            </div>
           
            <div className="bg-white p-6 rounded-xl shadow-lg border border-blue-100 transition-transform hover:scale-105">
              <div className="text-blue-600 mb-4 text-3xl">📝</div>
              <h3 className="text-xl font-bold text-blue-900 mb-3">Strategic Advisory & Response</h3>
              <p className="text-gray-600">
                Intelligent conversational AI interface providing business impact assessments, prioritized
                mitigation strategies, and executive-level recommendations through natural language interactions
                and automated workflow orchestration.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Minimal Footer */}
      <footer className="bg-blue-900 text-white py-6 px-6 mt-8">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0 text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start">
                <img src={logo} alt="NTT DATA Logo" className="h-10 w-auto" />
              </div>
              <p className="mt-1 text-blue-200 text-sm">Advanced risk management for your supplier network</p>
            </div>
           
            <div className="flex flex-col md:flex-row gap-6 text-sm">
              <div className="flex items-center justify-center">
                <div className="text-blue-300 mr-2">✉️</div>
                <span>info@nttdata.com</span>
              </div>
              <div className="flex items-center justify-center">
                <div className="text-blue-300 mr-2">📞</div>
                <span>+1 (555) 987-6543</span>
              </div>
              <div className="flex items-center justify-center">
                <div className="text-blue-300 mr-2">📍</div>
                <span>456 Supply Chain Ave, Suite 200</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
     
      {/* Enhanced Chatbot */}
      {!isChatOpen && (
        <button
          onClick={toggleChat}
          className="fixed bottom-6 right-6 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors z-40"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        </button>
      )}

      {/* Chatbot Window */}
      {isChatOpen && (
        <div className={`fixed z-50 ${isChatMaximized ? 'bottom-6 right-6' : 'bottom-6 right-6'}`}>
          {renderChatbot()}
        </div>
      )}
    </div>
  );
}

export default SupplierRiskManagement;