import pandas as pd
from config_loader import RiskConfig

class OverallRiskScorer:
    """
    Overall risk scoring combining financial, performance, and geopolitical risks
    Creates composite risk scores for strategic decision making by agents
    """
    
    def __init__(self):
        self.config = RiskConfig()
        
    def calculate_overall_risk(self, financial_df: pd.DataFrame, 
                             performance_df: pd.DataFrame, 
                             geopolitical_df: pd.DataFrame) -> pd.DataFrame:
        """
        Input: Processed risk data from all three dimensions
        Output: Overall risk scores with business context for agents
        """
        
        # Get overall risk configuration
        overall_config = self.config.get_overall_config()
        components = overall_config['components']
        
        # Merge all risk dimensions on supplier and date
        merged_df = self._merge_risk_dimensions(financial_df, performance_df, geopolitical_df)
        
        # Calculate overall risk scores
        merged_df['overall_risk_score'] = self._calculate_composite_score(merged_df, components)
        
        # Assign overall risk levels
        merged_df['overall_risk_level'] = merged_df['overall_risk_score'].apply(
            self.config.calculate_risk_level
        )
        
        return merged_df
    
    def _merge_risk_dimensions(self, financial_df: pd.DataFrame, 
                             performance_df: pd.DataFrame, 
                             geopolitical_df: pd.DataFrame) -> pd.DataFrame:
        """Merge all risk dimensions into single dataset"""

        # Create copies to avoid modifying original dataframes
        fin_df = financial_df.copy()
        perf_df = performance_df.copy()
        geo_df = geopolitical_df.copy()
        
        # Convert all update_date columns to datetime before merging
        fin_df['update_date'] = pd.to_datetime(fin_df['update_date'])
        perf_df['update_date'] = pd.to_datetime(perf_df['update_date'])
        geo_df['update_date'] = pd.to_datetime(geo_df['update_date'])
        
        # Start with financial data as base
        merged = fin_df[['supplier_name', 'update_date', 'financial_risk_score', 
                              'financial_risk_level']].copy()
        
        # Merge performance data
        performance_subset = perf_df[['supplier_name', 'update_date', 
                                           'performance_risk_score', 'performance_risk_level']]
        merged = merged.merge(performance_subset, on=['supplier_name', 'update_date'], how='left')
        
        # Merge geopolitical data  
        geo_subset = geo_df[['supplier_name', 'update_date', 
                                    'geopolitical_risk_score', 'geopolitical_risk_level']]
        merged = merged.merge(geo_subset, on=['supplier_name', 'update_date'], how='left')
        
        # Fill missing values with low scores
        risk_columns = ['financial_risk_score', 'performance_risk_score', 'geopolitical_risk_score']
        level_columns = ['financial_risk_level', 'performance_risk_level', 'geopolitical_risk_level']
        merged[risk_columns] = merged[risk_columns].fillna(20)
        merged[level_columns] = merged[level_columns].fillna('LOW')

        return merged
    
    def _calculate_composite_score(self, df: pd.DataFrame, components: dict) -> pd.Series:
        """Calculate weighted composite risk score using JSON configuration"""
        
        composite_score = (
            df['financial_risk_score'] * components['financial_weight'] +
            df['performance_risk_score'] * components['performance_weight'] +
            df['geopolitical_risk_score'] * components['geopolitical_weight']
        )
        
        return composite_score.round(1)
