import pandas as pd
from config_loader import RiskConfig

class GeopoliticalRiskScorer:
    """
    Geopolitical risk scoring with supplier master join
    Maps suppliers to countries, then applies geopolitical risk scores
    """
    
    def __init__(self):
        self.config = RiskConfig()
        
    def calculate_risk(self, raw_geo_df: pd.DataFrame, supplier_master_df: pd.DataFrame) -> pd.DataFrame:
        """
        Input: Raw dun_bradstreet_geo_data.csv + supplier_master.csv
        Output: Processed data with supplier_name and geopolitical risk scores
        """
        df_geo = raw_geo_df.copy()
        df_sup = supplier_master_df.copy()
        
        # Ensure date formatting
        df_geo['update_date'] = pd.to_datetime(df_geo['update_date'])
        
        # Join supplier_master with geo data on 'country' field
        # This creates supplier-month combinations with geopolitical scores
        merged_df = df_sup.merge(df_geo, on='country', how='left')
        
        # Handle missing geopolitical data (suppliers in countries not in geo data)
        risk_columns = ['political_risk', 'regulatory_risk', 'currency_risk', 'business_continuity']
        for col in risk_columns:
            merged_df[col] = merged_df[col].fillna(0.5)  # Neutral risk if no data
        
        # Calculate risk components using JSON formulas
        merged_df = self._calculate_components(merged_df)
        
        # Calculate weighted geopolitical risk score
        merged_df['geopolitical_risk_score'] = self._calculate_weighted_score(merged_df)
        
        # Assign risk levels using universal thresholds
        merged_df['geopolitical_risk_level'] = merged_df['geopolitical_risk_score'].apply(
            self.config.calculate_risk_level
        )
        
        # Return columns needed by agents for analysis
        return merged_df[['supplier_name', 'country', 'update_date', 'geopolitical_risk_score', 
                         'geopolitical_risk_level', 'political_risk', 'regulatory_risk', 
                         'currency_risk', 'business_continuity']]
    
    def _calculate_components(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate geopolitical risk components (convert 0-1 scale to 0-100 risk scale)"""
        
        df['political_risk_score'] = df['political_risk'] * 100
        df['regulatory_risk_score'] = df['regulatory_risk'] * 100  
        df['currency_risk_score'] = df['currency_risk'] * 100
        df['business_continuity_score'] = df['business_continuity'] * 100
        
        return df
    
    def _calculate_weighted_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate weighted geopolitical risk score using JSON weights"""
        
        geo_config = self.config.get_geopolitical_config()
        components = geo_config['components']
        
        score = (
            df['political_risk_score'] * components['political_risk']['weight'] +
            df['regulatory_risk_score'] * components['regulatory_risk']['weight'] +
            df['currency_risk_score'] * components['currency_risk']['weight'] +
            df['business_continuity_score'] * components['business_continuity']['weight']
        )
        
        return score.round(1)
