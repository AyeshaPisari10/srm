import pandas as pd
from pathlib import Path
from financial_risk_scorer import FinancialRiskScorer
# from backend.risk_scoring.financial_risk_scorer import FinancialRiskScorer
from geopolitical_risk_scorer import GeopoliticalRiskScorer
from performance_risk_scorer import PerformanceRiskScorer
from overall_risk_scorer import OverallRiskScorer

class DataPipeline:
    """
    Main data processing pipeline for agentic AI
    Transforms raw supplier data into agent-ready risk intelligence
    """
    
    def __init__(self):
        project_root = Path(__file__).parent.parent.parent
        self.data_dir = project_root / "backend" / "data"
        self.raw_dir = self.data_dir / "raw"
        self.processed_dir = self.data_dir / "processed"
        
        # Create directories if they don't exist (including parents)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        
    def process_all_data(self):
        """
        Main pipeline orchestrator
        Creates all processed risk data for agents to consume
        """
        print("🔄 Starting supplier risk data processing pipeline...")
        
        # Load raw data
        raw_data = self._load_raw_data()
        
        # Process each risk dimension
        processed_data = {}
        
        print("📊 Processing financial risk data...")
        processed_data['financial'] = self._process_financial_risk(raw_data['finance'])
        
        print("🌍 Processing geopolitical risk data...")
        processed_data['geopolitical'] = self._process_geopolitical_risk(raw_data['geo'], raw_data['supplier_master'])
        
        print("⚡ Processing performance risk data...")
        processed_data['performance'] = self._process_performance_risk(
            raw_data['po'], raw_data['supplier_master']
        )
        
        print("🎯 Creating overall risk data...")
        processed_data['overall'] = self._process_overall_risk(
            processed_data['financial'], 
            processed_data['performance'], 
            processed_data['geopolitical']
        )
        
        # Save all processed data
        self._save_processed_data(processed_data)
        
        print("✅ Data processing pipeline completed!")
        print(f"📁 Processed data saved to: {self.processed_dir}")
        
    def _load_raw_data(self) -> dict:
        """Load all raw datasets"""
        
        raw_data = {
            'finance': pd.read_csv(self.raw_dir / "dun_bradstreet_finance_data.csv"),
            'geo': pd.read_csv(self.raw_dir / "dun_bradstreet_geo_data.csv"),
            'po': pd.read_csv(self.raw_dir / "po_data.csv"),
            'supplier_master': pd.read_csv(self.raw_dir / "supplier_master.csv")
        }
        
        print(f"📋 Loaded {len(raw_data)} raw datasets")
        return raw_data
    
    def _process_financial_risk(self, raw_finance: pd.DataFrame) -> pd.DataFrame:
        """Process financial risk using JSON-driven scorer"""
        financial_scorer = FinancialRiskScorer()
        return financial_scorer.calculate_risk(raw_finance)
    
    def _process_geopolitical_risk(self, raw_geo: pd.DataFrame, supplier_master: pd.DataFrame) -> pd.DataFrame:
        """Process geopolitical risk using JSON-driven scorer with supplier master join"""
        geo_scorer = GeopoliticalRiskScorer()
        return geo_scorer.calculate_risk(raw_geo, supplier_master)
    
    def _process_performance_risk(self, raw_po: pd.DataFrame, 
                                supplier_master: pd.DataFrame) -> pd.DataFrame:
        """Process performance risk using JSON-driven scorer"""
        perf_scorer = PerformanceRiskScorer()
        return perf_scorer.calculate_risk(raw_po, supplier_master)
    
    def _process_overall_risk(self, financial_df: pd.DataFrame,
                            performance_df: pd.DataFrame, 
                            geopolitical_df: pd.DataFrame) -> pd.DataFrame:
        """Create overall risk scores combining all dimensions"""
        overall_scorer = OverallRiskScorer()
        return overall_scorer.calculate_overall_risk(financial_df, performance_df, geopolitical_df)
    
    def _save_processed_data(self, processed_data: dict):
        """Save all processed datasets for agent consumption"""
        
        file_mapping = {
            'financial': 'financial_risk_data.csv',
            'geopolitical': 'geopolitical_risk_data.csv', 
            'performance': 'performance_risk_data.csv',
            'overall': 'overall_risk_data.csv'
        }
        
        for data_type, filename in file_mapping.items():
            processed_data[data_type].to_csv(
                self.processed_dir / filename, 
                index=False
            )
            print(f"💾 Saved: {filename}")

# Usage for POC setup
if __name__ == "__main__":
    pipeline = DataPipeline()
    pipeline.process_all_data()
