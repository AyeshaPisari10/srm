import pandas as pd
from datetime import datetime, timedelta
from config_loader import RiskConfig

class PerformanceRiskScorer:
    """
    Performance risk scoring using JSON-driven formulas
    Calculates monthly performance risk from PO data for agents
    """
    
    def __init__(self):
        self.config = RiskConfig()
        
    def calculate_risk(self, po_df: pd.DataFrame, supplier_master: pd.DataFrame) -> pd.DataFrame:
        """
        Input: Raw po_data.csv + supplier_master.csv
        Output: Monthly performance risk data for each supplier
        """
        # Prepare PO data with date conversion
        po_df = self._prepare_po_data(po_df)
        
        # Get performance config from JSON
        perf_config = self.config.get_performance_config()
        
        # Calculate monthly performance metrics for each supplier
        monthly_performance = self._calculate_monthly_metrics(po_df, perf_config)
        
        return monthly_performance
    
    def _prepare_po_data(self, po_df: pd.DataFrame) -> pd.DataFrame:
        """Prepare PO data with proper date handling"""
        df = po_df.copy()
        
        # Convert date columns
        df['arrival_date'] = pd.to_datetime(df['arrival_date'])
        df['po_due_date'] = pd.to_datetime(df['po_due_date'])
        
        # Calculate delivery delay in days
        df['delivery_delay_days'] = (df['arrival_date'] - df['po_due_date']).dt.days
        
        # Calculate fill rate and rejection rate
        df['fill_rate'] = (df['shipped_quantity'] / df['po_quantity']) * 100
        df['rejection_rate'] = (df['rm_rejected'] / df['shipped_quantity']) * 100
        
        return df
    
    def _calculate_monthly_metrics(self, po_df: pd.DataFrame, perf_config: dict) -> pd.DataFrame:
        """Calculate monthly performance risk for each supplier"""
        
        # Group by supplier and month (based on arrival_date)
        po_df['year_month'] = po_df['arrival_date'].dt.to_period('M')
        
        monthly_data = []
        
        for (supplier, month), group in po_df.groupby(['supplier_name', 'year_month']):
            
            # Calculate performance components
            avg_delivery_delay = group['delivery_delay_days'].mean()
            avg_quality_score = group['quality_score'].mean()
            avg_fill_rate = group['fill_rate'].mean()
            avg_rejection_rate = group['rejection_rate'].mean()
            
            # Apply JSON formulas for risk calculation
            components = perf_config['components']
            
            delivery_risk = min(100, max(0, avg_delivery_delay * 3))
            quality_risk = max(0, 100 - avg_quality_score)
            fill_rate_risk = max(0, 100 - avg_fill_rate)
            rejection_risk = min(100, avg_rejection_rate * 4)
            
            # Calculate weighted performance risk score
            performance_risk_score = (
                delivery_risk * components['delivery_risk']['weight'] +
                quality_risk * components['quality_risk']['weight'] +
                fill_rate_risk * components['fill_rate_risk']['weight'] +
                rejection_risk * components['rejection_risk']['weight']
            )
            
            # Determine risk level
            performance_risk_level = self.config.calculate_risk_level(performance_risk_score)

            # define the update_date as the first day of the next month
            update_date = month.start_time + pd.offsets.MonthBegin(1)
            
            monthly_data.append({
                'supplier_name': supplier,
                'update_date': update_date.strftime('%Y-%m-%d'), 
                'performance_risk_score': round(performance_risk_score, 1),
                'performance_risk_level': performance_risk_level,
                'avg_delivery_delay_days': round(avg_delivery_delay, 1),
                'avg_quality_score': round(avg_quality_score, 1),
                'avg_fill_rate': round(avg_fill_rate, 1),
                'avg_rejection_rate': round(avg_rejection_rate, 1)
            })
        
        return pd.DataFrame(monthly_data)
