import pandas as pd
from config_loader import RiskConfig

class FinancialRiskScorer:
    """
    Financial risk scoring using JSON-driven formulas
    Processes Dun & Bradstreet financial data into risk scores for agents
    """
    
    def __init__(self):
        self.config = RiskConfig()
        
    def calculate_risk(self, raw_df: pd.DataFrame) -> pd.DataFrame:
        """
        Input: Raw dun_bradstreet_finance_data.csv
        Output: Processed data with financial_risk_score and financial_risk_level
        """
        df = raw_df.copy()
        
        # Get financial config from JSON
        financial_config = self.config.get_financial_config()
        components = financial_config['components']
        
        # Map credit ratings to numeric risk
        credit_mapping = components['credit_risk']['mapping']
        df['credit_risk'] = df['credit_rating'].map(credit_mapping).fillna(100)
        
        # Calculate other components based on formulas in JSON
        df['default_risk'] = df['probability_of_default'] * 5
        df['liquidity_risk'] = df['liquidity_ratio'].apply(lambda x: max(0, (1.2 - x) * 83))
        df['debt_risk'] = df['debt_to_equity'] * 25
        df['profitability_risk'] = df['profit_margin'].apply(lambda x: max(0, (8 - x) * 8))
        
        # Calculate weighted financial risk score
        df['financial_risk_score'] = (
            df['credit_risk'] * components['credit_risk']['weight'] +
            df['default_risk'] * components['default_risk']['weight'] +
            df['liquidity_risk'] * components['liquidity_risk']['weight'] +
            df['debt_risk'] * components['debt_risk']['weight'] +
            df['profitability_risk'] * components['profitability_risk']['weight']
        )
        
        # Assign risk levels using universal thresholds
        df['financial_risk_level'] = df['financial_risk_score'].apply(
            self.config.calculate_risk_level
        )
        
        # Return columns needed by agents for analysis
        return df[['supplier_name', 'update_date', 'financial_risk_score', 
                  'financial_risk_level', 'credit_rating', 'probability_of_default', 
                  'liquidity_ratio', 'debt_to_equity', 'profit_margin']]
