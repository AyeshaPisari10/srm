# config_loader.py
import json
from pathlib import Path

project_root = Path(__file__).parent.parent.parent
config_path = project_root / "backend" / "config" / "risk_config.json"

class RiskConfig:
    def __init__(self, config_path=config_path):
        with open(config_path, 'r') as f:
            self.config = json.load(f)['risk_config']
    
    def get_risk_levels(self):
        return self.config['universal_risk_levels']
    
    def get_financial_config(self):
        return self.config['financial_risk']
    
    def get_geopolitical_config(self):
        return self.config['geopolitical_risk']
    
    def get_performance_config(self):
        return self.config['performance_risk']
    
    def get_overall_config(self):
        return self.config['overall_risk']
    
    def calculate_risk_level(self, score):
        levels = self.get_risk_levels()
        for level, bounds in levels.items():
            if bounds['min'] <= score < bounds['max']:
                return level
        return 'CRITICAL'  # fallback for scores >= 75
