import json
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict
from backend.tools.external_intelligence.external_intelligence_executor import external_intelligence_executor
from backend.data.data_loader import data_loader

# Cache directory for alerts
CACHE_DIR = Path(__file__).parent / "cache"
CACHE_DIR.mkdir(exist_ok=True)
ALERTS_CACHE_FILE = CACHE_DIR / "aggregated_alerts.json"

class NewsAlertsOrchestrator:
    """Orchestrator that uses existing external intelligence to generate dashboard alerts"""
    
    def __init__(self):
        self.executor = external_intelligence_executor
        
    def get_supplier_cities(self) -> List[str]:
        """Get supplier cities from supplier_master data"""
        try:
            supplier_master = data_loader.load_supplier_master()
            cities = supplier_master['city'].dropna().unique().tolist()
            print(f"Loaded {len(cities)} supplier cities")
            return cities
        except Exception as e:
            print(f"Error loading supplier cities: {e}")
            return ["New York", "London", "Berlin", "Tokyo", "Sydney"]  # Fallback cities

    def _classify_severity(self, text: str, alert_type: str) -> str:
        """Return neutral severity — no keyword filtering, just show live data"""
        return "info"

    def _extract_intel(self, result):
        """Extract summary and api_date from executor result (handles both dict and str)"""
        if isinstance(result, dict):
            return result.get("summary", str(result)), result.get("api_date", "")
        return str(result), ""

    def gather_alerts_for_city(self, city: str) -> List[Dict]:
        """Call existing external intelligence methods and return ALL live results"""
        alerts = []
        now = datetime.now(timezone.utc).isoformat()
        
        try:
            # Weather Intelligence — always show
            weather_result = self.executor._get_weather_intelligence(city)
            summary, api_date = self._extract_intel(weather_result)
            alerts.append({
                "title": f"🌤️ Weather — {city}",
                "summary": summary,
                "date": api_date or now,
                "source": "Weather Service",
                "city": city,
                "severity": self._classify_severity(summary, "weather")
            })
            
            # Political Intelligence — always show
            political_result = self.executor._get_political_intelligence(city)
            summary, api_date = self._extract_intel(political_result)
            alerts.append({
                "title": f"🏛️ Political — {city}",
                "summary": summary,
                "date": api_date or now,
                "source": "Political News",
                "city": city,
                "severity": self._classify_severity(summary, "political")
            })
            
            # Disaster Intelligence — always show
            disaster_result = self.executor._get_disaster_intelligence(city)
            summary, api_date = self._extract_intel(disaster_result)
            alerts.append({
                "title": f"🌍 Disaster Monitor — {city}",
                "summary": summary,
                "date": api_date or now,
                "source": "USGS",
                "city": city,
                "severity": self._classify_severity(summary, "disaster")
            })
            
            # General News Intelligence — always show
            news_result = self.executor._get_general_news(city)
            summary, api_date = self._extract_intel(news_result)
            alerts.append({
                "title": f"📰 Business News — {city}",
                "summary": summary,
                "date": api_date or now,
                "source": "Business News",
                "city": city,
                "severity": self._classify_severity(summary, "news")
            })
        
        except Exception as e:
            print(f"Error gathering alerts for {city}: {e}")
            alerts.append({
                "title": f"⚠️ Monitoring — {city}",
                "summary": f"Risk monitoring active for {city} suppliers - data fetch encountered an issue",
                "date": now,
                "source": "Risk Monitor",
                "city": city,
                "severity": "info"
            })
        
        return alerts

    def fetch_and_cache_alerts(self) -> List[Dict]:
        """Fetch alerts for all supplier cities and cache results"""
        print("🔄 Fetching alerts using external intelligence...")
        
        cities = self.get_supplier_cities()
        all_alerts = []
        
        # Process first 5 cities to avoid too many API calls
        for city in cities[:5]:
            print(f" 📍 Processing alerts for {city}...")
            city_alerts = self.gather_alerts_for_city(city)
            all_alerts.extend(city_alerts)
        
        # If no real alerts found, add some general monitoring alerts
        if not all_alerts:
            print("No specific alerts found, adding general monitoring alerts...")
            for city in cities[:3]:
                all_alerts.append({
                    "title": "Monitoring Active",
                    "summary": f"All monitoring systems active for {city} suppliers - no major alerts detected",
                    "date": datetime.now(timezone.utc).isoformat(),
                    "source": "Intelligence Monitor",
                    "city": city
                })
        
        # Keep only top 10 alerts
        all_alerts = all_alerts[:10]
        
        # Cache the results
        cache_data = {
            "alerts": all_alerts,
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "cities_processed": len(cities)
        }
        
        try:
            with open(ALERTS_CACHE_FILE, 'w') as f:
                json.dump(cache_data, f, indent=2)
            print(f"✅ Cached {len(all_alerts)} alerts successfully")
        except Exception as e:
            print(f"❌ Error caching alerts: {e}")
        
        return all_alerts

    def get_cached_alerts_data(self, limit: int = 5) -> Dict:
        """Get cached alerts along with metadata like last_updated"""
        try:
            if ALERTS_CACHE_FILE.exists():
                with open(ALERTS_CACHE_FILE, 'r') as f:
                    cache_data = json.load(f)
                alerts = cache_data.get("alerts", [])
                last_updated = cache_data.get("last_updated", "")
                return {"alerts": alerts[:limit], "last_updated": last_updated}
            else:
                return {"alerts": [], "last_updated": ""}
        except Exception as e:
            print(f"❌ Error reading cached alerts: {e}")
            return {"alerts": [], "last_updated": ""}

    def get_cached_alerts(self, limit: int = 5) -> List[Dict]:
        """Get cached alerts"""
        return self.get_cached_alerts_data(limit).get("alerts", [])

# Global instance
news_alerts_orchestrator = NewsAlertsOrchestrator()
