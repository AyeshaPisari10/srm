import pandas as pd
from datetime import datetime
from typing import Dict, Any
from pathlib import Path
from backend.data.data_loader import data_loader
from backend.utils.llm_client import get_llm_for_agents
from backend.utils.llm_utils import extract_llm_content

class AlertExecutor:
    """
    Alert creation and audit logging for dashboard
    """
    
    def __init__(self):
        self.llm = get_llm_for_agents()
        
        # Create audit directory if it doesn't exist
        self.audit_dir = Path("backend/data/audit")
        self.audit_dir.mkdir(parents=True, exist_ok=True)
        self.audit_file = self.audit_dir / "audit_log.csv"
        
        # Check if audit log file exists, if not create it with headers
        if not self.audit_file.exists():
            # Define CSV headers
            headers = [
                'alert_id', 'timestamp', 'alert_type', 'supplier_name', 
                'query', 'risk_scores', 'risk_type', 'severity', 'status', 'created_by'
            ]
            
            # Create empty DataFrame with headers
            headers_df = pd.DataFrame(columns=headers)
            
            # Save to CSV with headers
            headers_df.to_csv(self.audit_file, index=False)
            print("📋 Created audit log file with headers")
        else:
            print("📋 Audit log file already exists")
        
        print("🚨 AlertExecutor initialized")

    def execute(self, user_query: str, data_context: Dict) -> Dict:
        """
        Create alert for supplier monitoring
        """
        print(f"🔔 Creating alert: '{user_query}'")
        
        try:
            # Step 1: Extract supplier name from query or context
            supplier_name = data_context.get('supplier_name') or self._extract_supplier_name(user_query)
            
            # Step 2: Get supplier data using data loader
            supplier_data = self._get_supplier_data(supplier_name)
            
            # Step 3: Create alert structure
            alert_data = self._create_alert_structure(user_query, supplier_name, supplier_data, data_context)
            
            # Step 4: Save to audit log
            alert_id = self._save_alert_to_audit(alert_data)
            
            return {
                'success': True,
                'alert_created': True,
                'alert_id': alert_id,
                'supplier_name': supplier_name,
                'alert_details': alert_data,
                'user_query': user_query,
                'task_type': 'alerting'
            }
            
        except Exception as e:
            print(f"❌ Alert creation failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'user_query': user_query,
                'task_type': 'alerting'
            }

    def _extract_supplier_name(self, user_query: str) -> str:
        """Extract supplier name from query using LLM"""
        prompt = f"""
        Extract the supplier name from this query:
        "{user_query}"
        
        Return ONLY the supplier name, nothing else.
        If no supplier name is found, return "Unknown Supplier".
        """
        
        try:
            response = self.llm.invoke([{"role": "system", "content": prompt}])
            return extract_llm_content(response).strip()
        except:
            return "Unknown Supplier"

    def _get_supplier_data(self, supplier_name: str) -> Dict:
        """Get supplier data using data loader"""
        try:
            # Get comprehensive supplier profile
            supplier_profile = data_loader.get_supplier_risk_profile(supplier_name)
            
            if supplier_profile and supplier_profile.get('overall_risk'):
                return {
                    'success': True,
                    'data': supplier_profile
                }
            else:
                return {
                    'success': False,
                    'supplier_name': supplier_name, 
                    'status': 'not_found'
                }
        except Exception as e:
            return {
                'success': False,
                'supplier_name': supplier_name, 
                'status': 'error',
                'error': str(e)
            }

    def _create_alert_structure(self, user_query: str, supplier_name: str, 
                              supplier_data: Dict, data_context: Dict) -> Dict:
        """Create structured alert data with clean JSON risk scores"""
        
        # Extract risk scores from supplier data
        risk_scores_json = self._extract_risk_scores(supplier_data)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'alert_type': 'manual',
            'supplier_name': supplier_name,
            'query': user_query,
            'risk_scores': risk_scores_json,
            'risk_type': data_context.get('risk_type', 'overall'),
            'severity': data_context.get('severity', 'HIGH'),
            'status': 'active',
            'created_by': 'dashboard'
        }

    def _extract_risk_scores(self, supplier_data: Dict) -> str:
        """Extract risk scores from supplier data with robust handling and rounding"""
        import json
        
        try:
            if supplier_data.get('success') and supplier_data.get('data'):
                profile_data = supplier_data['data']
                risk_scores = {}
                
                # Extract scores from different risk dimensions and round to whole numbers
                if profile_data.get('financial_risk') and 'financial_risk_score' in profile_data['financial_risk']:
                    risk_scores['financial_risk_score'] = round(float(profile_data['financial_risk']['financial_risk_score']))
                
                if profile_data.get('performance_risk') and 'performance_risk_score' in profile_data['performance_risk']:
                    risk_scores['performance_risk_score'] = round(float(profile_data['performance_risk']['performance_risk_score']))
                
                if profile_data.get('geopolitical_risk') and 'geopolitical_risk_score' in profile_data['geopolitical_risk']:
                    risk_scores['geopolitical_risk_score'] = round(float(profile_data['geopolitical_risk']['geopolitical_risk_score']))
                
                if profile_data.get('overall_risk') and 'overall_risk_score' in profile_data['overall_risk']:
                    risk_scores['overall_risk_score'] = round(float(profile_data['overall_risk']['overall_risk_score']))
                
                return json.dumps(risk_scores)
            
            # Fallback
            return "{}"
            
        except Exception as e:
            print(f"Error extracting risk scores: {e}")
            return "{}"

    def _save_alert_to_audit(self, alert_data: Dict) -> str:
        """Save alert to audit log CSV with proper error handling"""
        try:
            # Generate alert ID
            alert_id = f"ALT_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            alert_data['alert_id'] = alert_id
            
            # Convert to DataFrame row
            alert_df = pd.DataFrame([alert_data])
            
            # Check if file exists and has content
            file_exists = self.audit_file.exists()
            
            if file_exists:
                try:
                    # Try to read existing file
                    existing_log = pd.read_csv(self.audit_file)
                    updated_log = pd.concat([existing_log, alert_df], ignore_index=True)
                except (pd.errors.EmptyDataError, pd.errors.ParserError):
                    # File exists but is empty or corrupted - start fresh
                    updated_log = alert_df
            else:
                # File doesn't exist - create new
                updated_log = alert_df
            
            # Save to CSV
            updated_log.to_csv(self.audit_file, index=False)
            print(f" ✅ Alert saved: {alert_id}")
            return alert_id
            
        except Exception as e:
            print(f" ⚠️ Audit save failed: {e}")
            return f"ALT_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

# Global instance
alert_executor = AlertExecutor()
