import re
from typing import Dict, Any, Optional
from datetime import datetime

class RiskProfileRenderer:
    """
    Renders agent-generated risk profile data into structured HTML
    Based on the uploaded HTML reference design
    """
    
    def __init__(self):
        self.html_template = self._get_html_template()
    
    def render_risk_profile_html(self, agent_output: str, supplier_name: str, 
                               additional_data: Dict[str, Any] = None) -> str:
        """
        Main function to convert agent output into formatted HTML
        """
        try:
            # Parse agent output to extract structured data
            parsed_data = self._parse_agent_output(agent_output, supplier_name)
            
            # Merge with any additional data from API
            if additional_data:
                parsed_data.update(additional_data)
            
            # Inject data into HTML template
            rendered_html = self._inject_data_into_template(parsed_data)
            
            return rendered_html
            
        except Exception as e:
            # Fallback to basic HTML with raw agent output
            return self._create_fallback_html(agent_output, supplier_name, str(e))
    
    def _parse_agent_output(self, agent_output: str, supplier_name: str) -> Dict[str, Any]:
        """
        Parse the agent's text output to extract structured data
        """
        data = {
            'supplier_name': supplier_name,
            'updated_date': datetime.now().strftime('%Y-%m-%d'),
            'supplier_id': f"SUP-{hash(supplier_name) % 10000:04d}",
            
            # Default values
            'overall_score': 'N/A',
            'risk_level': 'UNKNOWN',
            'financial_score': 'N/A',
            'performance_score': 'N/A',
            'geopolitical_score': 'N/A',
            
            'contact_person': 'N/A',
            'contact_email': 'N/A', 
            'contact_phone': 'N/A',
            'city': 'N/A',
            'country': 'N/A',
            
            'total_spend': 'N/A',
            'volume_share': 'N/A',
            'dependency_risk': 'N/A',
            
            'findings': [],
            'recommendations': [],
            'external_risk_level': 'N/A',
            'weather_summary': 'N/A',
            'political_summary': 'N/A',
            'disaster_summary': 'N/A',
            'news_summary': 'N/A'
        }
        
        # Extract risk scores using regex patterns
        risk_patterns = {
            'overall_score': r'overall[^:]*:\s*([0-9.]+)',
            'financial_score': r'financial[^:]*:\s*([0-9.]+)',
            'performance_score': r'performance[^:]*:\s*([0-9.]+)',
            'geopolitical_score': r'geopolitical[^:]*:\s*([0-9.]+)'
        }
        
        for key, pattern in risk_patterns.items():
            match = re.search(pattern, agent_output, re.IGNORECASE)
            if match:
                data[key] = float(match.group(1))
        
        # Extract risk level
        risk_level_match = re.search(r'(CRITICAL|HIGH|MEDIUM|LOW)\s+risk', agent_output, re.IGNORECASE)
        if risk_level_match:
            data['risk_level'] = risk_level_match.group(1).upper()
        
        # Extract contact information
        email_match = re.search(r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', agent_output)
        if email_match:
            data['contact_email'] = email_match.group(1)
        
        phone_match = re.search(r'(\+?[0-9-\s()]{10,})', agent_output)
        if phone_match:
            data['contact_phone'] = phone_match.group(1)
        
        # Extract city and country
        location_match = re.search(r'([A-Z][a-z]+),\s*([A-Z][A-Z][A-Z]?)', agent_output)
        if location_match:
            data['city'] = location_match.group(1)
            data['country'] = location_match.group(2)
        
        # Extract spend information
        spend_match = re.search(r'\$([0-9,]+)', agent_output)
        if spend_match:
            data['total_spend'] = f"${spend_match.group(1)}"
        
        # Extract findings (look for bullet points or key findings section)
        findings_section = re.search(r'(key findings|findings)[:\s]*(.*?)(?=recommendations|next steps|$)', 
                                   agent_output, re.IGNORECASE | re.DOTALL)
        if findings_section:
            findings_text = findings_section.group(2)
            # Split by bullet points or line breaks
            findings = [f.strip() for f in re.split(r'[•\-\*]|\n', findings_text) if f.strip()]
            data['findings'] = findings[:3]  # Limit to top 3
        
        # Extract recommendations
        rec_section = re.search(r'(recommendations|actions)[:\s]*(.*?)(?=next steps|$)', 
                              agent_output, re.IGNORECASE | re.DOTALL)
        if rec_section:
            rec_text = rec_section.group(2)
            recommendations = [r.strip() for r in re.split(r'[•\-\*]|\n', rec_text) if r.strip()]
            data['recommendations'] = recommendations[:3]  # Limit to top 3
        
        return data
    
    def _inject_data_into_template(self, data: Dict[str, Any]) -> str:
        """
        Inject parsed data into HTML template
        """
        # Convert risk scores to appropriate format and levels
        overall_score = data.get('overall_score', 0)
        if isinstance(overall_score, (int, float)):
            data['overall_score_display'] = f"{overall_score:.0f}"
            data['overall_level'] = self._score_to_level(overall_score)
        else:
            data['overall_score_display'] = "N/A"
            data['overall_level'] = "UNKNOWN"
        
        # Format other scores
        for score_type in ['financial', 'performance', 'geopolitical']:
            score = data.get(f'{score_type}_score', 0)
            if isinstance(score, (int, float)):
                data[f'{score_type}_score_display'] = f"{score:.0f}"
                data[f'{score_type}_level'] = self._score_to_level(score)
            else:
                data[f'{score_type}_score_display'] = "N/A"
                data[f'{score_type}_level'] = "UNKNOWN"
        
        # Format findings and recommendations as HTML lists
        data['findings_html'] = self._format_list_items(data.get('findings', []))
        data['recommendations_html'] = self._format_list_items(data.get('recommendations', []))
        
        # Inject all data into template
        try:
            return self.html_template.format(**data)
        except KeyError as e:
            # Handle missing template variables gracefully
            return self._create_fallback_html(f"Template error: {str(e)}", data.get('supplier_name', 'Unknown'))
    
    def _score_to_level(self, score: float) -> str:
        """Convert numeric score to risk level"""
        if score >= 75:
            return "CRITICAL"
        elif score >= 50:
            return "HIGH"
        elif score >= 25:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _format_list_items(self, items: list) -> str:
        """Format list items as HTML"""
        if not items:
            return "<li>No specific items identified</li>"
        
        formatted_items = []
        for item in items[:3]:  # Limit to 3 items
            if item.strip():
                formatted_items.append(f"<li>{item.strip()}</li>")
        
        return "\n".join(formatted_items) if formatted_items else "<li>No specific items identified</li>"
    
    def _get_html_template(self) -> str:
        """
        HTML template based on your uploaded reference design
        """
        return '''
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Supplier Risk Profile</title>
            <style>
                :root {{
                    --bg: #f8f9fa;
                    --panel: #ffffff;
                    --muted: #6c757d;
                    --text: #212529;
                    --brand: #007bff;
                    --ok: #28a745;
                    --warn: #ffc107;
                    --high: #fd7e14;
                    --crit: #dc3545;
                    --border: #dee2e6;
                    --shadow: 0 2px 10px rgba(0,0,0,0.1);
                    --radius: 8px;
                }}
                
                body {{
                    margin: 0;
                    padding: 20px;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: var(--bg);
                    color: var(--text);
                    line-height: 1.5;
                }}
                
                .container {{
                    max-width: 1000px;
                    margin: 0 auto;
                }}
                
                .header {{
                    background: var(--panel);
                    padding: 24px;
                    border-radius: var(--radius);
                    box-shadow: var(--shadow);
                    margin-bottom: 20px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }}
                
                .title {{
                    font-size: 24px;
                    font-weight: bold;
                    margin: 0;
                }}
                
                .subtitle {{
                    color: var(--muted);
                    margin: 5px 0 0 0;
                }}
                
                .badge {{
                    padding: 6px 12px;
                    border-radius: 20px;
                    font-weight: bold;
                    font-size: 14px;
                }}
                
                .badge.critical {{ background: var(--crit); color: white; }}
                .badge.high {{ background: var(--high); color: white; }}
                .badge.medium {{ background: var(--warn); color: black; }}
                .badge.low {{ background: var(--ok); color: white; }}
                
                .grid {{
                    display: grid;
                    gap: 20px;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                }}
                
                .card {{
                    background: var(--panel);
                    padding: 20px;
                    border-radius: var(--radius);
                    box-shadow: var(--shadow);
                }}
                
                .card h3 {{
                    margin: 0 0 15px 0;
                    color: var(--brand);
                    font-size: 18px;
                }}
                
                .metric {{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 10px 0;
                    border-bottom: 1px solid var(--border);
                }}
                
                .metric:last-child {{
                    border-bottom: none;
                }}
                
                .metric-label {{
                    color: var(--muted);
                }}
                
                .metric-value {{
                    font-weight: bold;
                }}
                
                .findings, .recommendations {{
                    background: var(--panel);
                    padding: 20px;
                    border-radius: var(--radius);
                    box-shadow: var(--shadow);
                    margin-top: 20px;
                }}
                
                .findings ul, .recommendations ul {{
                    margin: 0;
                    padding-left: 20px;
                }}
                
                .findings li, .recommendations li {{
                    margin-bottom: 8px;
                }}
                
                @media (max-width: 768px) {{
                    .header {{
                        flex-direction: column;
                        text-align: center;
                    }}
                    
                    .grid {{
                        grid-template-columns: 1fr;
                    }}
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <!-- Header -->
                <div class="header">
                    <div>
                        <h1 class="title">Supplier Risk Profile — {supplier_name}</h1>
                        <p class="subtitle">Updated: {updated_date} • ID: {supplier_id}</p>
                    </div>
                    <div>
                        <span class="badge {overall_level}">{overall_level}</span>
                    </div>
                </div>
                
                <!-- Overview Grid -->
                <div class="grid">
                    <!-- Supplier Overview -->
                    <div class="card">
                        <h3>Supplier Overview</h3>
                        <div class="metric">
                            <span class="metric-label">Contact</span>
                            <span class="metric-value">{contact_person}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Email</span>
                            <span class="metric-value">{contact_email}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Phone</span>
                            <span class="metric-value">{contact_phone}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Location</span>
                            <span class="metric-value">{city}, {country}</span>
                        </div>
                    </div>
                    
                    <!-- Business Exposure -->
                    <div class="card">
                        <h3>Business Exposure</h3>
                        <div class="metric">
                            <span class="metric-label">Total Spend</span>
                            <span class="metric-value">{total_spend}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Volume Share</span>
                            <span class="metric-value">{volume_share}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Dependency Risk</span>
                            <span class="metric-value">{dependency_risk}</span>
                        </div>
                    </div>
                    
                    <!-- Risk Scores -->
                    <div class="card">
                        <h3>Internal Risk Scores</h3>
                        <div class="metric">
                            <span class="metric-label">Overall</span>
                            <span class="metric-value">{overall_level} ({overall_score_display})</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Financial</span>
                            <span class="metric-value">{financial_level} ({financial_score_display})</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Performance</span>
                            <span class="metric-value">{performance_level} ({performance_score_display})</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Geopolitical</span>
                            <span class="metric-value">{geopolitical_level} ({geopolitical_score_display})</span>
                        </div>
                    </div>
                    
                    <!-- External Intelligence -->
                    <div class="card">
                        <h3>External Intelligence</h3>
                        <div class="metric">
                            <span class="metric-label">External Risk Level</span>
                            <span class="metric-value">{external_risk_level}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Weather</span>
                            <span class="metric-value">{weather_summary}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Political</span>
                            <span class="metric-value">{political_summary}</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">News</span>
                            <span class="metric-value">{news_summary}</span>
                        </div>
                    </div>
                </div>
                
                <!-- Findings -->
                <div class="findings">
                    <h3>Key Findings</h3>
                    <ul>
                        {findings_html}
                    </ul>
                </div>
                
                <!-- Recommendations -->
                <div class="recommendations">
                    <h3>Recommendations</h3>
                    <ul>
                        {recommendations_html}
                    </ul>
                </div>
            </div>
        </body>
        </html>
        '''
    
    def _create_fallback_html(self, agent_output: str, supplier_name: str, error: str = None) -> str:
        """
        Create simple fallback HTML when parsing fails
        """
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Risk Profile - {supplier_name}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .error {{ color: red; background: #ffe6e6; padding: 10px; border-radius: 5px; }}
                .content {{ background: #f9f9f9; padding: 20px; border-radius: 5px; white-space: pre-wrap; }}
            </style>
        </head>
        <body>
            <h1>Risk Profile: {supplier_name}</h1>
            {f'<div class="error">Parsing Error: {error}</div>' if error else ''}
            <div class="content">{agent_output}</div>
        </body>
        </html>
        '''

# Global instance for reuse
risk_profile_renderer = RiskProfileRenderer()

def render_supplier_risk_profile(agent_output: str, supplier_name: str, 
                                additional_data: Dict[str, Any] = None) -> str:
    """
    Main function to be called from Flask endpoint
    """
    return risk_profile_renderer.render_risk_profile_html(agent_output, supplier_name, additional_data)
