import pandas as pd
from typing import Dict, Any, List, Set
from backend.data.data_loader import DataLoader

class PatternDiscovery:
    """
    Pattern discovery tool for Risk Intelligence Agent
    Identifies cross-dimensional risk patterns and emerging trends
    """
    
    def __init__(self):
        self.data_loader = DataLoader()
    
    def find_correlated_risk_patterns(self) -> Dict[str, Any]:
        """Find suppliers with correlated risks across multiple dimensions"""
        try:
            # Load all risk dimensions
            financial_df = self.data_loader.load_financial_risk_data()
            performance_df = self.data_loader.load_performance_risk_data()
            geopolitical_df = self.data_loader.load_geopolitical_risk_data()
            
            patterns = {
                'high_financial_and_performance': [],
                'high_financial_and_geopolitical': [],
                'high_performance_and_geopolitical': [],
                'triple_high_risk': [],
                'analysis_summary': {}
            }
            
            if financial_df.empty or performance_df.empty or geopolitical_df.empty:
                return {'error': 'Insufficient data for correlation analysis'}
            
            # Get latest data for each supplier in each dimension
            latest_financial = financial_df.sort_values('update_date').groupby('supplier_name').tail(1)
            latest_performance = performance_df.sort_values('update_date').groupby('supplier_name').tail(1)
            latest_geopolitical = geopolitical_df.sort_values('update_date').groupby('supplier_name').tail(1)
            
            # Define high-risk suppliers for each dimension
            high_financial = set(latest_financial[latest_financial['financial_risk_score'] >= 70]['supplier_name'])
            high_performance = set(latest_performance[latest_performance['performance_risk_score'] >= 70]['supplier_name'])
            high_geopolitical = set(latest_geopolitical[latest_geopolitical['geopolitical_risk_score'] >= 70]['supplier_name'])
            
            # Find intersections
            patterns['high_financial_and_performance'] = list(high_financial.intersection(high_performance))
            patterns['high_financial_and_geopolitical'] = list(high_financial.intersection(high_geopolitical))
            patterns['high_performance_and_geopolitical'] = list(high_performance.intersection(high_geopolitical))
            patterns['triple_high_risk'] = list(high_financial.intersection(high_performance).intersection(high_geopolitical))
            
            patterns['analysis_summary'] = {
                'total_high_financial': len(high_financial),
                'total_high_performance': len(high_performance),
                'total_high_geopolitical': len(high_geopolitical),
                'correlation_strength': self._calculate_correlation_strength(high_financial, high_performance, high_geopolitical)
            }
            
            return patterns
            
        except Exception as e:
            return {'error': f'Pattern correlation error: {str(e)}'}
    
    def detect_emerging_trends(self, months: int = 6) -> Dict[str, Any]:
        """Detect emerging risk trends across all suppliers"""
        try:
            trends = {
                'financial_trends': {},
                'performance_trends': {},
                'geopolitical_trends': {},
                'summary': {}
            }
            
            # Analyze financial trends
            financial_df = self.data_loader.load_financial_risk_data()
            if not financial_df.empty:
                trends['financial_trends'] = self._analyze_dimension_trends(financial_df, 'financial', months)
            
            # Analyze performance trends
            performance_df = self.data_loader.load_performance_risk_data()
            if not performance_df.empty:
                trends['performance_trends'] = self._analyze_dimension_trends(performance_df, 'performance', months)
            
            # Analyze geopolitical trends
            geopolitical_df = self.data_loader.load_geopolitical_risk_data()
            if not geopolitical_df.empty:
                trends['geopolitical_trends'] = self._analyze_dimension_trends(geopolitical_df, 'geopolitical', months)
            
            # Create summary
            trends['summary'] = self._summarize_trends(trends)
            
            return trends
            
        except Exception as e:
            return {'error': f'Trend detection error: {str(e)}'}
    
    def identify_risk_hotspots(self) -> Dict[str, Any]:
        """Identify risk hotspots - suppliers/regions with multiple risk factors"""
        try:
            hotspots = {
                'supplier_hotspots': [],
                'regional_hotspots': [],
                'risk_concentration': {}
            }
            
            # Load overall risk data
            overall_df = self.data_loader.load_overall_risk_data()
            
            if overall_df.empty:
                return {'error': 'No overall risk data available for hotspot analysis'}
            
            # Get latest data
            latest_df = overall_df.sort_values('update_date').groupby('supplier_name').tail(1)
            
            # Identify supplier hotspots (high overall risk)
            supplier_hotspots = latest_df[latest_df['overall_risk_score'] >= 75]
            hotspots['supplier_hotspots'] = supplier_hotspots[['supplier_name', 'overall_risk_score', 'overall_risk_level']].to_dict('records')
            
            # Risk concentration analysis
            risk_levels = latest_df['overall_risk_level'].value_counts().to_dict()
            hotspots['risk_concentration'] = {
                'total_suppliers': len(latest_df),
                'risk_distribution': risk_levels,
                'high_risk_percentage': round((risk_levels.get('HIGH', 0) + risk_levels.get('CRITICAL', 0)) / len(latest_df) * 100, 2)
            }
            
            return hotspots
            
        except Exception as e:
            return {'error': f'Hotspot identification error: {str(e)}'}
    
    def _analyze_dimension_trends(self, df: pd.DataFrame, dimension: str, months: int) -> Dict[str, str]:
        """Analyze trends for a specific risk dimension"""
        trends = {}
        df['update_date'] = pd.to_datetime(df['update_date'])
        
        for supplier in df['supplier_name'].unique():
            supplier_df = df[df['supplier_name'] == supplier].sort_values('update_date').tail(months)
            
            if len(supplier_df) < 2:
                continue
                
            first_score = supplier_df.iloc[0][f'{dimension}_risk_score']
            last_score = supplier_df.iloc[-1][f'{dimension}_risk_score']
            
            if last_score > first_score + 5:  # Threshold for significant change
                trends[supplier] = 'deteriorating'
            elif last_score < first_score - 5:
                trends[supplier] = 'improving'
            else:
                trends[supplier] = 'stable'
        
        return trends
    
    def _calculate_correlation_strength(self, set1: Set, set2: Set, set3: Set) -> str:
        """Calculate correlation strength between risk dimensions"""
        total_suppliers = len(set1.union(set2).union(set3))
        
        if total_suppliers == 0:
            return 'no_data'
        
        overlaps = len(set1.intersection(set2).intersection(set3))
        correlation_ratio = overlaps / total_suppliers
        
        if correlation_ratio > 0.3:
            return 'strong'
        elif correlation_ratio > 0.1:
            return 'moderate'
        else:
            return 'weak'
    
    def _summarize_trends(self, trends: Dict) -> Dict[str, Any]:
        """Summarize trend analysis across all dimensions"""
        summary = {
            'suppliers_with_deteriorating_trends': [],
            'suppliers_with_improving_trends': [],
            'stable_suppliers': [],
            'trend_counts': {}
        }
        
        all_trends = {}
        
        # Collect trends from all dimensions
        for dimension, dimension_trends in trends.items():
            if dimension != 'summary' and isinstance(dimension_trends, dict):
                for supplier, trend in dimension_trends.items():
                    if supplier not in all_trends:
                        all_trends[supplier] = []
                    all_trends[supplier].append(trend)
        
        # Categorize suppliers
        for supplier, supplier_trends in all_trends.items():
            if 'deteriorating' in supplier_trends:
                summary['suppliers_with_deteriorating_trends'].append(supplier)
            elif 'improving' in supplier_trends:
                summary['suppliers_with_improving_trends'].append(supplier)
            else:
                summary['stable_suppliers'].append(supplier)
        
        summary['trend_counts'] = {
            'deteriorating': len(summary['suppliers_with_deteriorating_trends']),
            'improving': len(summary['suppliers_with_improving_trends']),
            'stable': len(summary['stable_suppliers'])
        }
        
        return summary
