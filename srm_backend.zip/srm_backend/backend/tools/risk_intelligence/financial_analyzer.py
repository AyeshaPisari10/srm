import pandas as pd
from typing import Dict, Any, List, Optional
from backend.data.data_loader import DataLoader

class FinancialAnalyzer:
    """
    Financial risk analysis tool for Risk Intelligence Agent
    Provides comprehensive financial risk assessment capabilities
    """
    
    def __init__(self):
        self.data_loader = DataLoader()
    
    def get_latest_financial_risk(self, supplier_name: str) -> Dict[str, Any]:
        """Get latest financial risk data for a specific supplier"""
        try:
            df = self.data_loader.load_financial_risk_data()
            supplier_df = df[df['supplier_name'] == supplier_name]
            
            if supplier_df.empty:
                return {'error': f'No financial data found for {supplier_name}'}
            
            latest_record = supplier_df.sort_values('update_date').iloc[-1]
            return latest_record.to_dict()
            
        except Exception as e:
            return {'error': f'Financial analysis error: {str(e)}'}
    
    def get_high_risk_suppliers(self, threshold: float = 70.0) -> List[Dict[str, Any]]:
        """Get suppliers with financial risk score above threshold"""
        try:
            df = self.data_loader.load_financial_risk_data()
            
            if df.empty:
                return []
            
            # Get latest record for each supplier
            latest_df = df.sort_values('update_date').groupby('supplier_name').tail(1)
            high_risk_df = latest_df[latest_df['financial_risk_score'] >= threshold]
            
            return high_risk_df.to_dict('records') # type: ignore
            
        except Exception as e:
            return [{'error': f'High risk analysis error: {str(e)}'}]
    
    def analyze_financial_trends(self, supplier_name: str, months: int = 6) -> Dict[str, Any]:
        """Analyze financial risk trends over specified months"""
        try:
            df = self.data_loader.load_financial_risk_data()
            supplier_df = df[df['supplier_name'] == supplier_name]
            
            if supplier_df.empty:
                return {'error': f'No trend data found for {supplier_name}'}
            
            # Sort by date and get last N months
            supplier_df = supplier_df.sort_values('update_date').tail(months)
            
            if len(supplier_df) < 2:
                return {'trend': 'insufficient_data', 'data_points': len(supplier_df)}
            
            # Calculate trend
            first_score = supplier_df.iloc[0]['financial_risk_score']
            last_score = supplier_df.iloc[-1]['financial_risk_score']
            trend_direction = 'improving' if last_score < first_score else 'deteriorating' if last_score > first_score else 'stable'
            
            return {
                'supplier_name': supplier_name,
                'trend_direction': trend_direction,
                'first_score': first_score,
                'last_score': last_score,
                'change': last_score - first_score,
                'data_points': len(supplier_df),
                'period_months': months
            }
            
        except Exception as e:
            return {'error': f'Trend analysis error: {str(e)}'}
    
    def get_financial_risk_distribution(self) -> Dict[str, Any]:
        """Get distribution of financial risk levels across all suppliers"""
        try:
            df = self.data_loader.load_financial_risk_data()
            
            if df.empty:
                return {'error': 'No financial risk data available'}
            
            # Get latest record for each supplier
            latest_df = df.sort_values('update_date').groupby('supplier_name').tail(1)
            
            risk_distribution = latest_df['financial_risk_level'].value_counts().to_dict()
            avg_score = latest_df['financial_risk_score'].mean()
            
            return {
                'total_suppliers': len(latest_df),
                'risk_distribution': risk_distribution,
                'average_risk_score': round(avg_score, 2),
                'analysis_date': latest_df['update_date'].max()
            }
            
        except Exception as e:
            return {'error': f'Distribution analysis error: {str(e)}'}
