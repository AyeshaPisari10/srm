import pandas as pd
from typing import Dict, Any, List
from backend.data.data_loader import DataLoader

class GeopoliticalAnalyzer:
    """
    Geopolitical risk analysis tool for Risk Intelligence Agent
    Analyzes country-level political, regulatory, and economic risks
    """
    
    def __init__(self):
        self.data_loader = DataLoader()
    
    def get_supplier_geopolitical_risk(self, supplier_name: str) -> Dict[str, Any]:
        """Get geopolitical risk data for a specific supplier"""
        try:
            df = self.data_loader.load_geopolitical_risk_data()
            supplier_df = df[df['supplier_name'] == supplier_name]
            
            if supplier_df.empty:
                return {'error': f'No geopolitical data found for {supplier_name}'}
            
            latest_record = supplier_df.sort_values('update_date').iloc[-1]
            return latest_record.to_dict()
            
        except Exception as e:
            return {'error': f'Geopolitical analysis error: {str(e)}'}
    
    def get_country_risk_summary(self) -> Dict[str, Any]:
        """Get risk summary by country"""
        try:
            df = self.data_loader.load_geopolitical_risk_data()
            
            if df.empty:
                return {'error': 'No geopolitical data available'}
            
            # Get latest data for each country
            latest_df = df.sort_values('update_date').groupby('country').tail(1)
            
            country_summary = {}
            for _, row in latest_df.iterrows():
                country_summary[row['country']] = {
                    'geopolitical_risk_score': row['geopolitical_risk_score'],
                    'geopolitical_risk_level': row['geopolitical_risk_level'],
                    'political_risk': row['political_risk'],
                    'regulatory_risk': row['regulatory_risk'],
                    'currency_risk': row['currency_risk'],
                    'business_continuity': row['business_continuity']
                }
            
            return {
                'countries_analyzed': len(country_summary),
                'country_details': country_summary,
                'analysis_date': latest_df['update_date'].max()
            }
            
        except Exception as e:
            return {'error': f'Country risk summary error: {str(e)}'}
    
    def get_high_risk_regions(self, threshold: float = 70.0) -> List[Dict[str, Any]]:
        """Get countries/regions with high geopolitical risk"""
        try:
            df = self.data_loader.load_geopolitical_risk_data()
            
            if df.empty:
                return []
            
            # Get latest data for each country
            latest_df = df.sort_values('update_date').groupby('country').tail(1)
            high_risk_df = latest_df[latest_df['geopolitical_risk_score'] >= threshold]
            
            return high_risk_df.to_dict('records')
            
        except Exception as e:
            return [{'error': f'High risk regions analysis error: {str(e)}'}]
    
    def analyze_regional_patterns(self) -> Dict[str, Any]:
        """Analyze geopolitical risk patterns across regions"""
        try:
            df = self.data_loader.load_geopolitical_risk_data()
            
            if df.empty:
                return {'error': 'No geopolitical data available'}
            
            # Get latest data for each country
            latest_df = df.sort_values('update_date').groupby('country').tail(1)
            
            risk_distribution = latest_df['geopolitical_risk_level'].value_counts().to_dict()
            avg_risk_components = {
                'political_risk': round(latest_df['political_risk'].mean(), 3),
                'regulatory_risk': round(latest_df['regulatory_risk'].mean(), 3),
                'currency_risk': round(latest_df['currency_risk'].mean(), 3),
                'business_continuity': round(latest_df['business_continuity'].mean(), 3)
            }
            
            return {
                'total_countries': len(latest_df),
                'risk_distribution': risk_distribution,
                'average_risk_components': avg_risk_components,
                'average_geopolitical_score': round(latest_df['geopolitical_risk_score'].mean(), 2),
                'analysis_date': latest_df['update_date'].max()
            }
            
        except Exception as e:
            return {'error': f'Regional patterns analysis error: {str(e)}'}
