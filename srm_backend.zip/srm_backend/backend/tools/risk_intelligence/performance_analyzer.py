import pandas as pd
from typing import Dict, Any, List
from backend.data.data_loader import DataLoader

class PerformanceAnalyzer:
    """
    Performance risk analysis tool for Risk Intelligence Agent
    Analyzes delivery performance, quality metrics, and operational efficiency
    """
    
    def __init__(self):
        self.data_loader = DataLoader()
    
    def get_latest_performance(self, supplier_name: str) -> Dict[str, Any]:
        """Get latest performance metrics for a specific supplier"""
        try:
            df = self.data_loader.load_performance_risk_data()
            supplier_df = df[df['supplier_name'] == supplier_name]
            
            if supplier_df.empty:
                return {'error': f'No performance data found for {supplier_name}'}
            
            latest_record = supplier_df.sort_values('update_date').iloc[-1]
            return latest_record.to_dict()
            
        except Exception as e:
            return {'error': f'Performance analysis error: {str(e)}'}
    
    def get_deteriorating_suppliers(self, threshold: float = 70.0) -> List[Dict[str, Any]]:
        """Get suppliers with high performance risk scores"""
        try:
            df = self.data_loader.load_performance_risk_data()
            
            if df.empty:
                return []
            
            # Get latest record for each supplier
            latest_df = df.sort_values('update_date').groupby('supplier_name').tail(1)
            deteriorating_df = latest_df[latest_df['performance_risk_score'] >= threshold]
            
            return deteriorating_df.to_dict('records') # type: ignore
            
        except Exception as e:
            return [{'error': f'Deterioration analysis error: {str(e)}'}]
    
    def analyze_performance_trends(self, supplier_name: str, months: int = 6) -> Dict[str, Any]:
        """Analyze performance trends over specified months"""
        try:
            df = self.data_loader.load_performance_risk_data()
            supplier_df = df[df['supplier_name'] == supplier_name]
            
            if supplier_df.empty:
                return {'error': f'No trend data found for {supplier_name}'}
            
            # Sort by date and get last N months
            supplier_df = supplier_df.sort_values('update_date').tail(months)
            
            if len(supplier_df) < 2:
                return {'trend': 'insufficient_data', 'data_points': len(supplier_df)}
            
            # Calculate trends for multiple metrics
            first_record = supplier_df.iloc[0]
            last_record = supplier_df.iloc[-1]
            
            return {
                'supplier_name': supplier_name,
                'performance_score_trend': {
                    'direction': 'improving' if last_record['performance_risk_score'] < first_record['performance_risk_score'] else 'deteriorating' if last_record['performance_risk_score'] > first_record['performance_risk_score'] else 'stable',
                    'change': last_record['performance_risk_score'] - first_record['performance_risk_score']
                },
                'delivery_performance': {
                    'avg_delay_change': last_record['avg_delivery_delay_days'] - first_record['avg_delivery_delay_days'],
                    'current_avg_delay': last_record['avg_delivery_delay_days']
                },
                'quality_performance': {
                    'score_change': last_record['avg_quality_score'] - first_record['avg_quality_score'],
                    'current_quality_score': last_record['avg_quality_score']
                },
                'fill_rate_performance': {
                    'change': last_record['avg_fill_rate'] - first_record['avg_fill_rate'],
                    'current_fill_rate': last_record['avg_fill_rate']
                },
                'data_points': len(supplier_df),
                'period_months': months
            }
            
        except Exception as e:
            return {'error': f'Performance trend analysis error: {str(e)}'}
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get overall performance risk summary across all suppliers"""
        try:
            df = self.data_loader.load_performance_risk_data()
            
            if df.empty:
                return {'error': 'No performance data available'}
            
            # Get latest record for each supplier
            latest_df = df.sort_values('update_date').groupby('supplier_name').tail(1)
            
            return {
                'total_suppliers': len(latest_df),
                'risk_distribution': latest_df['performance_risk_level'].value_counts().to_dict(),
                'average_metrics': {
                    'performance_risk_score': round(latest_df['performance_risk_score'].mean(), 2),
                    'avg_delivery_delay_days': round(latest_df['avg_delivery_delay_days'].mean(), 2),
                    'avg_quality_score': round(latest_df['avg_quality_score'].mean(), 2),
                    'avg_fill_rate': round(latest_df['avg_fill_rate'].mean(), 2)
                },
                'analysis_date': latest_df['update_date'].max()
            }
            
        except Exception as e:
            return {'error': f'Performance summary error: {str(e)}'}
