import json
import re
from typing import Dict, Any, List
from pathlib import Path

class MitigationGenerator:
    """
    Mitigation Strategy Generator for Strategic Advisor Agent
    Generates actionable mitigation strategies for prioritized risks
    Uses config-driven thresholds for proportional response scaling
    """

    def __init__(self):
        self.config = self._load_risk_config()

    def _load_risk_config(self) -> Dict[str, Any]:
        """Load risk configuration from centralized config file"""
        try:
            config_path = Path(__file__).parent.parent.parent / "config" / "risk_config.json"
            with open(config_path, 'r') as f:
                config_data = json.load(f)
            return config_data.get('risk_config', {})
        except Exception as e:
            print(f"⚠️ Failed to load risk config: {e}")
            return {
                "universal_risk_levels": {
                    "LOW": {"min": 0, "max": 25},
                    "MEDIUM": {"min": 25, "max": 50},
                    "HIGH": {"min": 50, "max": 75},
                    "CRITICAL": {"min": 75, "max": 100}
                }
            }

    def generate_strategies(self, prioritized_risks: Dict[str, Any],
                           business_impact: Dict[str, Any],
                           agent_output: str = "") -> Dict[str, Any]:
        """
        Generate comprehensive mitigation strategies scaled to actual risk magnitude
        """
        try:
            # Extract risk magnitude from agent output for proportional scaling
            max_risk_score = self._extract_max_risk_score(agent_output)
            
            # Get config thresholds
            thresholds = self.config.get('universal_risk_levels', {})
            critical_threshold = thresholds.get('CRITICAL', {}).get('min', 75)
            high_threshold = thresholds.get('HIGH', {}).get('min', 50)

            mitigation_plan = {
                'executive_summary': '',
                'immediate_actions': [],
                'short_term_strategies': [],
                'long_term_strategies': [],
                'resource_requirements': {},
                'success_metrics': {},
                'risk_level_detected': self._get_risk_level_from_score(max_risk_score)
            }

            # Scale mitigation strategies based on actual risk magnitude
            if max_risk_score >= critical_threshold:
                mitigation_plan = self._generate_critical_mitigation(mitigation_plan, max_risk_score)
            elif max_risk_score >= high_threshold:
                mitigation_plan = self._generate_high_risk_mitigation(mitigation_plan, max_risk_score)
            else:
                mitigation_plan = self._generate_standard_mitigation(mitigation_plan, max_risk_score)

            # Generate executive summary
            mitigation_plan['executive_summary'] = self._generate_proportional_summary(mitigation_plan, max_risk_score)

            return mitigation_plan

        except Exception as e:
            return {
                'error': f'Mitigation strategy generation failed: {str(e)}',
                'executive_summary': 'Standard risk management protocols recommended'
            }

    def _extract_max_risk_score(self, agent_output: str) -> float:
        """Extract maximum risk score - use structured data if available"""
        
        # This function receives agent_output, but we need to check if structured scores exist
        # For now, keep existing regex logic but make it more reliable
        if not agent_output:
            return 0.0

        # Improved patterns for your specific output format
        all_risk_patterns = [
            r"'financial_risk_score':\s*([0-9]+\.?[0-9]*)",
            r"'performance_risk_score':\s*([0-9]+\.?[0-9]*)",
            r"'geopolitical_risk_score':\s*([0-9]+\.?[0-9]*)"
        ]

        all_scores = []
        for pattern in all_risk_patterns:
            matches = re.findall(pattern, agent_output, re.IGNORECASE)
            all_scores.extend(float(match) for match in matches)

        return max(all_scores) if all_scores else 0.0

    def _get_risk_level_from_score(self, score: float) -> str:
        """Convert numeric score to risk level using config thresholds"""
        
        thresholds = self.config.get('universal_risk_levels', {})
        critical_min = thresholds.get('CRITICAL', {}).get('min', 75)
        high_min = thresholds.get('HIGH', {}).get('min', 50)
        medium_min = thresholds.get('MEDIUM', {}).get('min', 25)

        if score >= critical_min:
            return 'CRITICAL'
        elif score >= high_min:
            return 'HIGH'
        elif score >= medium_min:
            return 'MEDIUM'
        else:
            return 'LOW'

    def _generate_critical_mitigation(self, plan: Dict[str, Any], risk_score: float) -> Dict[str, Any]:
        """Generate immediate critical risk mitigation strategies"""
        
        plan['immediate_actions'] = [
            {
                'action': 'Activate emergency response protocols',
                'timeline': '1-3 days',
                'responsible_team': 'Risk Management & Operations',
                'priority': 'CRITICAL',
                'deliverable': f'Emergency containment plan for risk level {risk_score}'
            },
            {
                'action': 'Implement enhanced supplier monitoring',
                'timeline': '24-48 hours',
                'responsible_team': 'Procurement & Supply Chain',
                'priority': 'CRITICAL',
                'deliverable': 'Real-time risk monitoring dashboard'
            }
        ]

        plan['short_term_strategies'] = [
            {
                'strategy': 'Alternative Sourcing Activation',
                'timeline': '1-2 weeks',
                'description': 'Expedite backup supplier qualification and agreements',
                'expected_outcome': 'Backup sourcing secured within 14 days'
            }
        ]

        plan['resource_requirements'] = {
            'personnel': 'High - requires dedicated crisis response team',
            'budget_estimate': 'Significant - emergency sourcing and monitoring costs',
            'timeline': '1-4 weeks for full implementation'
        }

        return plan

    def _generate_high_risk_mitigation(self, plan: Dict[str, Any], risk_score: float) -> Dict[str, Any]:
        """Generate enhanced monitoring and improvement strategies"""
        
        plan['immediate_actions'] = [
            {
                'action': 'Implement enhanced risk monitoring',
                'timeline': '1 week',
                'responsible_team': 'Risk Management',
                'priority': 'HIGH',
                'deliverable': f'Enhanced monitoring for risk level {risk_score}'
            }
        ]

        plan['short_term_strategies'] = [
            {
                'strategy': 'Supplier Performance Improvement Program',
                'timeline': '2-4 weeks',
                'description': 'Structured improvement program with performance milestones',
                'expected_outcome': 'Measurable risk reduction within 60 days'
            }
        ]

        plan['long_term_strategies'] = [
            {
                'strategy': 'Strategic Supply Chain Diversification',
                'timeline': '2-3 months',
                'description': 'Reduce concentration risk through strategic supplier diversification',
                'expected_outcome': 'Improved supply chain resilience'
            }
        ]

        plan['resource_requirements'] = {
            'personnel': 'Medium - requires cross-functional coordination',
            'budget_estimate': 'Moderate - performance improvement and diversification costs',
            'timeline': '2-8 weeks for implementation'
        }

        return plan

    def _generate_standard_mitigation(self, plan: Dict[str, Any], risk_score: float) -> Dict[str, Any]:
        """Generate standard monitoring and periodic review strategies"""
        
        plan['long_term_strategies'] = [
            {
                'strategy': 'Standard Risk Monitoring',
                'timeline': '3-6 months (ongoing)',
                'description': 'Maintain existing monitoring protocols with periodic review',
                'expected_outcome': f'Continued stable risk management for level {risk_score}'
            }
        ]

        plan['resource_requirements'] = {
            'personnel': 'Low - standard team allocation',
            'budget_estimate': 'Minimal - existing protocol maintenance',
            'timeline': 'Ongoing with quarterly reviews'
        }

        return plan

    def _generate_proportional_summary(self, plan: Dict[str, Any], risk_score: float) -> str:
        """Generate executive summary proportional to risk magnitude"""
        
        risk_level = plan.get('risk_level_detected', 'LOW')
        immediate_count = len(plan.get('immediate_actions', []))
        short_term_count = len(plan.get('short_term_strategies', []))
        long_term_count = len(plan.get('long_term_strategies', []))

        if risk_level == 'CRITICAL':
            return f"CRITICAL risk mitigation plan developed for risk level {risk_score}. {immediate_count} immediate actions require emergency execution within 1-3 days. Supply chain continuity at risk - immediate intervention required."
        
        elif risk_level == 'HIGH':
            return f"HIGH risk mitigation plan developed for risk level {risk_score}. {immediate_count + short_term_count} priority actions recommended within 2-4 weeks to prevent escalation."
        
        else:
            return f"Standard risk monitoring recommended for risk level {risk_score}. Existing protocols appropriate with {long_term_count} ongoing monitoring strategies."

    def get_mitigation_summary(self, mitigation_plan: Dict[str, Any]) -> str:
        """Generate concise mitigation summary for reporting"""
        
        if 'error' in mitigation_plan:
            return mitigation_plan['error']

        return mitigation_plan.get('executive_summary', 'Mitigation strategies developed for identified risks.')
