import json
import re
from typing import Dict, Any
from pathlib import Path
from backend.data.data_loader import DataLoader
from backend.utils.llm_client import get_llm_for_agents
from backend.utils.llm_utils import extract_llm_content

class BusinessImpactAssessor:
    """
    Business Impact Assessment tool for Strategic Advisor Agent
    Evaluates overall business impact from risk intelligence findings
    Uses config-driven thresholds and proportional assessment logic
    """

    def __init__(self):
        self.data_loader = DataLoader()
        self.config = self._load_risk_config()

    def _load_risk_config(self) -> Dict[str, Any]:
        """Load risk configuration from centralized config file - FIXED PATH"""
        try:
            # Correct path construction - go up 3 levels from tools/strategic_advisor to backend
            config_path = Path(__file__).parent.parent.parent / "config" / "risk_config.json"
            print(f"🔍 Looking for config at: {config_path}")
            
            if not config_path.exists():
                print(f"⚠️ Config file not found at: {config_path}")
                
            with open(config_path, 'r') as f:
                config_data = json.load(f)
            return config_data.get('risk_config', {})
        except Exception as e:
            print(f"⚠️ Failed to load risk config: {e}")
            return {
                "universal_risk_levels": {
                    "LOW": {"min": 0, "max": 25},
                    "MEDIUM": {"min": 25, "max": 50},
                    "HIGH": {"min": 50, "max": 75},
                    "CRITICAL": {"min": 75, "max": 100}
                }
            }

    def assess_impact(self, risk_intelligence_results: Dict[str, Any],
                     external_intelligence_results: Dict[str, Any]) -> Dict[str, Any]:
        """Assess comprehensive business impact from all intelligence sources"""
        try:
            impact_assessment = {
                'overall_impact_level': 'LOW',
                'impact_factors': [],
                'affected_areas': [],
                'business_continuity_risk': 'LOW',
                'financial_exposure': 'MINIMAL',
                'operational_disruption': 'MINIMAL',
                'detailed_analysis': {},
                'risk_magnitude_summary': {}
            }

            # Use ROBUST extraction method
            risk_scores = self._extract_risk_scores_robust(
                risk_intelligence_results.get('agent_output', '')
            )
            
            print(f"🔍 Extracted risk scores: {risk_scores}")
            impact_assessment['risk_magnitude_summary'] = risk_scores

            # Assess financial impact
            financial_impact = self._assess_financial_impact(risk_intelligence_results, risk_scores)
            impact_assessment['detailed_analysis']['financial'] = financial_impact

            # Assess operational impact
            operational_impact = self._assess_operational_impact(risk_intelligence_results, risk_scores)
            impact_assessment['detailed_analysis']['operational'] = operational_impact

            # Assess external threat impact
            external_impact = self._assess_external_impact(external_intelligence_results)
            impact_assessment['detailed_analysis']['external'] = external_impact

            # Calculate overall impact level
            impact_assessment = self._calculate_overall_impact_proportional(impact_assessment)

            return impact_assessment

        except Exception as e:
            return {
                'error': f'Business impact assessment failed: {str(e)}',
                'overall_impact_level': 'UNKNOWN'
            }

    def _extract_risk_scores_robust(self, agent_output: str) -> Dict[str, float]:
        """ROBUST risk score extraction with multi-layer fallback"""
        
        if not agent_output:
            return {'financial': 0.0, 'performance': 0.0, 'geopolitical': 0.0}

        print(f"🔍 Attempting extraction from: {agent_output[:200]}...")

        # Method 1: Flexible regex extraction
        scores = self._try_flexible_extraction(agent_output)
        
        # Method 2: LLM extraction (fallback)
        if all(score == 0.0 for score in scores.values()):
            print("🔄 Primary extraction failed, trying LLM fallback...")
            scores = self._try_llm_extraction(agent_output)
        
        # Method 3: Text-based analysis (final fallback)
        if all(score == 0.0 for score in scores.values()):
            print("🔄 LLM extraction failed, using text analysis fallback...")
            scores = self._try_text_analysis_fallback(agent_output)
            
        print(f"🎯 Final extracted scores: {scores}")
        return scores

    def _try_flexible_extraction(self, agent_output: str) -> Dict[str, float]:
        """Flexible numeric extraction - handles various formats"""
        
        scores = {'financial': 0.0, 'performance': 0.0, 'geopolitical': 0.0}
        
        for risk_type in scores.keys():
            patterns = [
                rf'{risk_type}[^0-9]*([0-9]+\.?[0-9]*)',
                rf'{risk_type.title()}[^0-9]*([0-9]+\.?[0-9]*)',
                rf"'{risk_type}_risk_score':\s*([0-9]+\.?[0-9]*)",
                rf'{risk_type}_risk_score.*?([0-9]+\.?[0-9]*)'
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, agent_output, re.IGNORECASE | re.DOTALL)
                if matches:
                    try:
                        scores[risk_type] = max(float(match) for match in matches)
                        print(f"✅ Found {risk_type}: {scores[risk_type]}")
                        break
                    except ValueError:
                        continue
                        
        return scores
    
    from backend.utils.llm_utils import extract_llm_content

    def _try_llm_extraction(self, agent_output: str) -> Dict[str, float]:
        """LLM-based extraction with clear prompt"""
        
        try:
            llm = get_llm_for_agents()
            
            prompt = f"""Extract numeric risk scores from this supplier analysis text.

                Text to analyze:
                {agent_output}

                Output ONLY a JSON object with these exact keys: financial, performance, geopolitical
                Each value should be the numeric risk score (float). If no score found, use 0.0.

                Example: {{"financial": 76.99, "performance": 15.5, "geopolitical": 10.0}}

                JSON:"""

            response = llm.invoke(prompt)
            content = extract_llm_content(response)  # Use your utility function
            
            # Clean response (remove markdown if present)
            if '```' in content:
                content = re.search(r'\{.*\}', content, re.DOTALL)
                content = content.group() if content else '{}'
            
            parsed = json.loads(content)
            
            # Validate and convert
            expected_keys = {'financial', 'performance', 'geopolitical'}
            if isinstance(parsed, dict) and expected_keys.issubset(parsed.keys()):
                result = {k: float(v) for k, v in parsed.items() if k in expected_keys}
                print(f"✅ LLM extraction successful: {result}")
                return result
            else:
                raise ValueError("Invalid LLM response format")
                
        except Exception as e:
            print(f"⚠️ LLM extraction failed: {e}")
            return {'financial': 0.0, 'performance': 0.0, 'geopolitical': 0.0}

    def _try_text_analysis_fallback(self, agent_output: str) -> Dict[str, float]:
        """Final fallback using risk level keywords"""
        
        scores = {'financial': 0.0, 'performance': 0.0, 'geopolitical': 0.0}
        
        risk_level_mapping = {'LOW': 15.0, 'MEDIUM': 40.0, 'HIGH': 65.0, 'CRITICAL': 85.0}
        
        for risk_type in scores.keys():
            for level, score in risk_level_mapping.items():
                if (f'{risk_type}' in agent_output.lower() and 
                    level in agent_output.upper()):
                    scores[risk_type] = score
                    print(f"📝 Text analysis found {risk_type}: {level} -> {score}")
                    break
                    
        return scores

    def _assess_financial_impact(self, risk_results: Dict[str, Any],
                               risk_scores: Dict[str, float]) -> Dict[str, Any]:
        """Assess financial impact using robust extraction and config thresholds"""
        
        financial_impact = {
            'impact_level': 'LOW',
            'financial_exposure_estimate': 'MINIMAL',
            'key_concerns': [],
            'max_score': risk_scores.get('financial', 0.0)
        }

        if not risk_results.get('analysis_completed'):
            return financial_impact

        # Get config thresholds
        thresholds = self.config.get('universal_risk_levels', {})
        high_threshold = thresholds.get('HIGH', {}).get('min', 50)
        critical_threshold = thresholds.get('CRITICAL', {}).get('min', 75)

        max_financial = risk_scores.get('financial', 0.0)

        # Apply proportional assessment
        if max_financial >= critical_threshold:
            financial_impact['impact_level'] = 'HIGH'
            financial_impact['financial_exposure_estimate'] = 'SIGNIFICANT'
            financial_impact['key_concerns'].append(f'Critical financial risk detected (score: {max_financial})')
            
        elif max_financial >= high_threshold:
            financial_impact['impact_level'] = 'MEDIUM'
            financial_impact['financial_exposure_estimate'] = 'MODERATE'
            financial_impact['key_concerns'].append(f'High financial risk identified (score: {max_financial})')
            
        else:
            financial_impact['key_concerns'].append(f'Financial risks within acceptable parameters (score: {max_financial})')

        return financial_impact

    def _assess_operational_impact(self, risk_results: Dict[str, Any],
                                 risk_scores: Dict[str, float]) -> Dict[str, Any]:
        """Assess operational impact using config thresholds"""
        
        operational_impact = {
            'impact_level': 'LOW',
            'delivery_risk': 'LOW',
            'quality_risk': 'LOW',
            'key_concerns': [],
            'max_score': risk_scores.get('performance', 0.0)
        }

        if not risk_results.get('analysis_completed'):
            return operational_impact

        # Get config thresholds
        thresholds = self.config.get('universal_risk_levels', {})
        high_threshold = thresholds.get('HIGH', {}).get('min', 50)
        critical_threshold = thresholds.get('CRITICAL', {}).get('min', 75)

        max_performance = risk_scores.get('performance', 0.0)

        # Apply proportional assessment
        if max_performance >= critical_threshold:
            operational_impact['impact_level'] = 'HIGH'
            operational_impact['delivery_risk'] = 'HIGH'
            operational_impact['quality_risk'] = 'MEDIUM'
            operational_impact['key_concerns'].append(f'Critical performance risk detected (score: {max_performance})')
            
        elif max_performance >= high_threshold:
            operational_impact['impact_level'] = 'MEDIUM'
            operational_impact['delivery_risk'] = 'MEDIUM'
            operational_impact['key_concerns'].append(f'High performance risk identified (score: {max_performance})')
            
        else:
            operational_impact['key_concerns'].append(f'Performance risks within acceptable parameters (score: {max_performance})')

        return operational_impact

    def _assess_external_impact(self, external_results: Dict[str, Any]) -> Dict[str, Any]:
        """Assess impact from external intelligence"""
        
        external_impact = {
            'impact_level': 'LOW',
            'active_threats': [],
            'geographic_risk': 'LOW',
            'key_concerns': []
        }

        if not external_results.get('success'):
            return external_impact

        threats = external_results.get('external_threats_detected', [])
        if threats and not (len(threats) == 1 and 'no immediate threats' in threats.lower()):
            external_impact['active_threats'] = threats
            external_impact['key_concerns'].extend(threats)

            if len(threats) >= 2:
                external_impact['impact_level'] = 'HIGH'
                external_impact['geographic_risk'] = 'HIGH'
            else:
                external_impact['impact_level'] = 'MEDIUM'
                external_impact['geographic_risk'] = 'MEDIUM'

        return external_impact

    def _calculate_overall_impact_proportional(self, assessment: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate overall business impact using config-based proportional logic"""
        
        detailed = assessment['detailed_analysis']
        risk_scores = assessment.get('risk_magnitude_summary', {})

        # Get config thresholds
        thresholds = self.config.get('universal_risk_levels', {})
        critical_threshold = thresholds.get('CRITICAL', {}).get('min', 75)
        high_threshold = thresholds.get('HIGH', {}).get('min', 50)

        # Get maximum risk scores
        max_financial = risk_scores.get('financial', 0.0)
        max_performance = risk_scores.get('performance', 0.0)
        max_geopolitical = risk_scores.get('geopolitical', 0.0)

        # Collect impact levels
        impact_levels = []
        for category in detailed.values():
            if isinstance(category, dict) and 'impact_level' in category:
                impact_levels.append(category['impact_level'])

        # Proportional overall impact calculation
        if (max_financial >= critical_threshold or max_performance >= critical_threshold or 
            max_geopolitical >= critical_threshold or 'HIGH' in impact_levels):
            assessment['overall_impact_level'] = 'HIGH'
            assessment['business_continuity_risk'] = 'HIGH'
            assessment['financial_exposure'] = 'SIGNIFICANT'
            assessment['operational_disruption'] = 'MAJOR'
            
        elif (max_financial >= high_threshold or max_performance >= high_threshold or 
              max_geopolitical >= high_threshold or 'MEDIUM' in impact_levels):
            assessment['overall_impact_level'] = 'MEDIUM'
            assessment['business_continuity_risk'] = 'MEDIUM'
            assessment['financial_exposure'] = 'MODERATE'
            assessment['operational_disruption'] = 'MODERATE'
            
        else:
            assessment['overall_impact_level'] = 'LOW'

        # Collect all impact factors
        for category_name, category_data in detailed.items():
            if isinstance(category_data, dict) and category_data.get('key_concerns'):
                assessment['impact_factors'].extend(category_data['key_concerns'])
                assessment['affected_areas'].append(category_name)

        return assessment

    def get_impact_summary(self, assessment: Dict[str, Any]) -> str:
        """Generate concise impact summary"""
        
        if 'error' in assessment:
            return assessment['error']

        impact_level = assessment.get('overall_impact_level', 'UNKNOWN')
        factors = assessment.get('impact_factors', [])

        if not factors:
            return f"Business impact assessed as {impact_level} with no significant risk factors identified."

        summary = f"Business impact assessed as {impact_level}. "
        summary += "Key factors: " + "; ".join(factors[:2])
        
        if len(factors) > 2:
            summary += f" (and {len(factors) - 2} additional factors)"

        return summary
