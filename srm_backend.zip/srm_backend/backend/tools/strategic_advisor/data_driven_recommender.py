from typing import Dict, Any
from backend.tools.shared.supplier_importance_analyzer import SupplierImportanceAnalyzer

class DataDrivenRecommender:
    """
    Generates recommendations using actual business data instead of generic advice
    Uses supplier importance and contact details for specific actions
    """
    
    def __init__(self):
        self.supplier_analyzer = SupplierImportanceAnalyzer()
    
    def generate_recommendations(self, risk_level: str, supplier_name: str, 
                               risk_intelligence_output: str = "") -> str:
        """
        Generate data-driven recommendations based on actual business relationships
        """
        try:
            # Get supplier importance using actual PO data
            supplier_importance = self.supplier_analyzer.analyze_supplier_importance(supplier_name)
            
            # Generate recommendations based on risk level + business importance
            if risk_level == "CRITICAL":
                return self._generate_critical_recommendations(supplier_name, supplier_importance)
            elif risk_level == "HIGH":
                return self._generate_high_recommendations(supplier_name, supplier_importance)
            elif risk_level == "MEDIUM":
                return self._generate_medium_recommendations(supplier_name, supplier_importance)
            else:  # LOW
                return self._generate_low_recommendations(supplier_name, supplier_importance)
                
        except Exception as e:
            return f"Unable to generate specific recommendations for {supplier_name}. Continue standard monitoring protocols."
    
    def _generate_critical_recommendations(self, supplier_name: str, importance: Dict[str, Any]) -> str:
        """Critical risk recommendations based on actual importance"""
        
        if importance.get('importance_level') == 'HIGH':
            # IMPORTANT SUPPLIER - Contact them
            contact_info = importance.get('contact_info', {})
            is_single_source = importance.get('is_single_source', False)
            single_source_materials = importance.get('single_source_materials', [])
            
            rec = f"🚨 **CRITICAL ACTION REQUIRED FOR {supplier_name}**\n\n"
            
            # Explain WHY supplier is important
            rec += "**SUPPLIER IMPORTANCE REASONS:**\n"
            if is_single_source:
                rec += f"• SINGLE SOURCE for: {', '.join(single_source_materials)}\n"
            if importance.get('volume_share_percent', 0) > 15:
                rec += f"• HIGH SPEND SHARE: {importance.get('volume_share_percent', 0)}% of total spend\n"
            
            # Contact details for working with them
            rec += "\n**CONTACT SUPPLIER IMMEDIATELY:**\n"
            if contact_info:
                rec += f"• Contact: {contact_info.get('contact_person', 'N/A')}\n"
                rec += f"• Email: {contact_info.get('contact_email', 'N/A')}\n"
                rec += f"• Phone: {contact_info.get('contact_phone', 'N/A')}\n\n"
            
            rec += "**RECOMMENDED ACTIONS:**\n"
            rec += "• Schedule emergency meeting within 24-48 hours\n"
            rec += "• Work with supplier to address critical risk factors\n"
            rec += "• Develop joint improvement plan"
            
        else:
            # NOT IMPORTANT - Switch suppliers
            alternatives = importance.get('alternative_suppliers', [])
            
            rec = f"🔄 **SUPPLIER SWITCH RECOMMENDED FOR {supplier_name}**\n\n"
            rec += "**SWITCH RATIONALE:**\n"
            rec += "• No single-source materials identified\n"
            rec += "• Low business dependency\n"
            rec += "• Multiple alternatives available\n\n"
            
            rec += "**RECOMMENDED ACTIONS:**\n"
            if alternatives:
                rec += f"• Switch to alternatives: {', '.join(alternatives[:3])}\n"
            rec += "• Begin transition within 2-4 weeks\n"
            rec += "• Minimize business disruption during switch"
        
        return rec
    
    def _generate_high_recommendations(self, supplier_name: str, importance: Dict[str, Any]) -> str:
        """High risk recommendations with importance logic"""
        
        if importance.get('importance_level') == 'HIGH':
            # Important supplier - work with them
            contact_info = importance.get('contact_info', {})
            rec = f"⚠️ **ENHANCED MONITORING FOR {supplier_name}**\n\n"
            
            # Contact for collaboration
            if contact_info:
                rec += f"• Contact for improvement discussion: {contact_info.get('contact_email', 'N/A')}\n"
            rec += "• Schedule formal review within 1-2 weeks\n"
            rec += "• Work with supplier on improvement plan\n"
            rec += "• Implement weekly risk monitoring\n"
        else:
            # Not important - consider switching
            alternatives = importance.get('alternative_suppliers', [])
            rec = f"🔄 **CONSIDER SUPPLIER SWITCH FOR {supplier_name}**\n\n" 
            rec += "• Evaluate alternative suppliers\n"
            if alternatives:
                rec += f"• Consider switching to: {', '.join(alternatives[:3])}\n"
            rec += "• Plan transition if improvement not seen in 4-6 weeks\n"
        
        return rec
    
    def _generate_medium_recommendations(self, supplier_name: str, importance: Dict[str, Any]) -> str:
        """Medium risk recommendations"""
        business_volume = importance.get('business_volume_6m', 0)
        
        rec = f"📊 **STANDARD MONITORING FOR {supplier_name}**\n\n"
        rec += f"• Business relationship: ${business_volume:,.0f} in last 6 months\n"
        rec += f"• Current risk level manageable with standard protocols\n\n"
        
        rec += "**RECOMMENDED ACTIONS:**\n"
        rec += "• Continue monthly risk assessments\n"
        rec += "• Maintain existing monitoring protocols\n"
        rec += "• Review quarterly for any changes"
        
        return rec
    
    def _generate_low_recommendations(self, supplier_name: str, importance: Dict[str, Any]) -> str:
        """Low risk recommendations"""
        business_volume = importance.get('business_volume_6m', 0)
        
        rec = f"✅ **LOW RISK - STANDARD PROTOCOLS FOR {supplier_name}**\n\n"
        rec += f"• Business relationship: ${business_volume:,.0f} in last 6 months\n"
        rec += f"• Risk levels within acceptable parameters\n\n"
        
        rec += "**RECOMMENDED ACTIONS:**\n"
        rec += "• Continue quarterly monitoring\n"
        rec += "• No immediate actions required\n"
        rec += "• Maintain current business relationship"
        
        return rec
