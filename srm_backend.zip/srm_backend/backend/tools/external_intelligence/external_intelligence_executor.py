import requests
import feedparser
from typing import Dict, Any, List
from backend.utils.llm_client import get_llm_for_agents  
from backend.utils.llm_utils import extract_llm_content     
from backend.data.data_loader import DataLoader            
from urllib.parse import quote_plus

class ExternalIntelligenceExecutor:
    """
    External intelligence gathering using free APIs - City-level intelligence
    """
    
    def __init__(self):
        self.llm = get_llm_for_agents()  # Updated function name
        self.data_loader = DataLoader()  # Initialize DataLoader instance
        print("🌐 ExternalIntelligenceExecutor initialized with free APIs (City-level)")
    
    def execute(self, user_query: str, data_context: Dict) -> Dict:
        """
        Execute external intelligence gathering
        """
        print(f"🔍 Gathering external intelligence: '{user_query}'")
        
        try:
            # Step 1: Extract supplier name using Azure LLM
            supplier_name = self._extract_supplier_name(user_query)
            print(f"🏢 Extracted supplier: '{supplier_name}' from query: '{user_query}'")  # NEW DEBUG LINE
            
            # Step 2: Get supplier CITY using updated DataLoader
            city = self._get_supplier_city_fallback(supplier_name)
            
            # Step 3: Determine topics and gather intelligence
            topics = self._determine_search_topics(user_query)
            intelligence = self._gather_intelligence(city, topics)
            
            return {
                'success': True,
                'supplier_name': supplier_name,
                'city': city,
                'topics_searched': topics,
                'external_intelligence': intelligence,
                'task_type': 'external_intelligence'
            }
            
        except Exception as e:
            print(f"❌ External intelligence failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'user_query': user_query,
                'task_type': 'external_intelligence'
            }

    def _get_supplier_city_fallback(self, supplier_name: str) -> str:
        """Get supplier city with city query handling"""
        # Handle direct city queries
        if supplier_name.startswith("CITY:"):
            city_name = supplier_name[5:]  # Remove "CITY:" prefix
            print(f"🏙️ Using direct city name: {city_name}")
            return city_name
        
        try:
            supplier_master = self.data_loader.load_supplier_master()
            if supplier_master.empty:
                print(f"⚠️ Supplier master data is empty")
                return "New York"
            
            # Try exact match first
            exact_match = supplier_master[supplier_master["supplier_name"] == supplier_name]
            if not exact_match.empty:
                city = exact_match.iloc[0]["city"]
                print(f"🎯 Found supplier {supplier_name} in {city} (exact match)")
                return city
            
            # Try case-insensitive partial match
            partial_matches = supplier_master[
                supplier_master["supplier_name"].str.contains(supplier_name, case=False, na=False)
            ]
            if not partial_matches.empty:
                city = partial_matches.iloc[0]["city"]
                matched_name = partial_matches.iloc[0]["supplier_name"]
                print(f"🎯 Found supplier {supplier_name} → {matched_name} in {city} (partial match)")
                return city
            
            print(f"⚠️ Supplier {supplier_name} not found in supplier master")
            return "New York"
            
        except Exception as e:
            print(f"⚠️ Could not load supplier data: {e}")
            return "New York"

    def _extract_supplier_name(self, query_input: str) -> str:
        """Extract supplier name with city name handling"""
        # Clean the input
        query_clean = query_input.strip().replace('"', '').replace("'", '')
        
        # SIMPLE FIX: Check if query contains known cities from our data
        try:
            supplier_master = self.data_loader.load_supplier_master()
            cities = supplier_master['city'].unique()
            
            for city in cities:
                if city.lower() in query_clean.lower():
                    print(f"🏙️ Found known city '{city}' in query: {query_clean}")
                    return f"CITY:{city}"
        except:
            pass  # Continue with existing logic if city lookup fails
        
        # If it's a short input with company indicators, use directly
        if len(query_clean.split()) <= 3 and any(word in query_clean.lower() for word in ['llc', 'ltd', 'inc', 'corp', 'plc']):
            print(f"🎯 Using direct supplier name: {query_clean}")
            return query_clean
        
        # If it looks like a city name, handle specially
        city_indicators = ['city', 'town', 'san', 'new', 'los', 'las', 'saint', 'st.', 'port', 'bay', 'lake']
        if (len(query_clean.split()) <= 3 and 
            any(indicator in query_clean.lower() for indicator in city_indicators)):
            print(f"🏙️ Detected city name: {query_clean}")
            return f"CITY:{query_clean}"  # Special marker for city queries
        
        # For longer queries, use LLM extraction
        try:
            prompt = f"""Extract the FIRST supplier/company name mentioned in this query:
            "{query_input}"
            
            Return ONLY the supplier name, nothing else.
            If multiple suppliers mentioned, return the first one.
            If no supplier name is found, return "Unknown"."""
            
            response = self.llm.invoke([{"role": "system", "content": prompt}])
            supplier_name = extract_llm_content(response).strip()
            print(f"🎯 LLM extracted supplier name: {supplier_name}")
            return supplier_name if supplier_name else "Unknown"
        except Exception as e:
            print(f"⚠️ Supplier extraction failed: {e}")
            return "Unknown"
    
    def _determine_search_topics(self, user_query: str) -> List[str]:
        """Determine what intelligence topics to search using Azure LLM"""
        prompt = f"""
        Analyze this query to determine what external intelligence topics to search:
        "{user_query}"
        
        Available topics: weather, political, disasters, general_news
        
        Return only the relevant topics as a comma-separated list.
        If the query mentions "alerts" or "risks", include all topics.
        
        Examples:
        "weather conditions" → weather
        "political stability" → political  
        "recent risk alerts" → weather,political,disasters
        """
        
        try:
            response = self.llm.invoke([{"role": "system", "content": prompt}])
            topics_str = extract_llm_content(response).strip()
            topics = [t.strip() for t in topics_str.split(",")]
            return topics if topics else ["general_news"]
        except Exception as e:
            print(f"⚠️ Topic detection failed: {e}")
            # Fallback: search all topics for risk queries
            query_lower = user_query.lower()
            if any(word in query_lower for word in ["alert", "risk", "recent"]):
                return ["weather", "political", "disasters"]
            return ["general_news"]
    
    def _get_city_coordinates(self, city: str) -> Dict:
        """Get city coordinates using free geocoding API"""
        try:
            # Using OpenStreetMap Nominatim API (free, no key required)
            url = f"https://nominatim.openstreetmap.org/search?city={city}&format=json&limit=1"
            headers = {'User-Agent': 'SupplierRiskBot/1.0'}
            
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                if data:
                    return {
                        "lat": float(data[0]["lat"]),
                        "lon": float(data[0]["lon"])
                    }
            
            # Fallback coordinates (New York)
            return {"lat": 40.7128, "lon": -74.0060}
            
        except Exception as e:
            print(f"⚠️ Geocoding failed for {city}: {e}")
            return {"lat": 40.7128, "lon": -74.0060}
    
    def _gather_intelligence(self, city: str, topics: List[str]) -> Dict:
        """Gather intelligence from free APIs"""
        
        intelligence = {}
        
        for topic in topics:
            try:
                if topic == "weather":
                    intelligence["weather"] = self._get_weather_intelligence(city)
                elif topic == "political":
                    intelligence["political"] = self._get_political_intelligence(city)
                elif topic == "disasters":
                    intelligence["disasters"] = self._get_disaster_intelligence(city)
                elif topic in ["general_news", "news"]:
                    intelligence["news"] = self._get_general_news(city)
            except Exception as e:
                print(f"⚠️ Failed to get {topic} intelligence: {e}")
                intelligence[topic] = f"Unable to retrieve {topic} data"
        
        return intelligence
    
    def _get_weather_intelligence(self, city: str) -> dict:
        """Get weather alerts for city using Open-Meteo (FREE, no API key)"""
        
        try:
            coords = self._get_city_coordinates(city)
            
            # Open-Meteo API - completely free, no API key
            url = f"https://api.open-meteo.com/v1/forecast?latitude={coords['lat']}&longitude={coords['lon']}&current_weather=true&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto"
            
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                current = data.get("current_weather", {})
                
                temp = current.get("temperature", "N/A")
                weather_code = current.get("weathercode", 0)
                api_time = current.get("time", "")  # e.g. "2026-04-06T07:00"
                
                # Simple weather condition mapping
                conditions = {0: "Clear", 1: "Partly cloudy", 2: "Overcast", 3: "Fog"}
                condition = conditions.get(weather_code, "Normal")
                
                return {
                    "summary": f"Current conditions in {city}: {condition}, {temp}°C. No severe weather alerts detected.",
                    "api_date": api_time
                }
            else:
                return {"summary": f"Weather monitoring active for {city}. No severe alerts detected.", "api_date": ""}
                
        except Exception as e:
            print(f"⚠️ Weather API error: {e}")
            return {"summary": f"Weather conditions normal for {city}. No alerts detected.", "api_date": ""}
    
    def _get_political_intelligence(self, city: str) -> dict:
        """Get political news for city using Google News RSS (FREE, no API key)"""
        try:
            # Google News RSS - completely free, no API key needed
            search_query = f"{city} political stability government local news"
            
            # Properly encode the search query
            encoded_query = quote_plus(search_query)
            url = f"https://news.google.com/rss/search?q={encoded_query}&hl=en&gl=US&ceid=US:en"
            
            feed = feedparser.parse(url)
            if feed.entries:
                # Analyze first few headlines for sentiment
                headlines = [str(entry.title) for entry in feed.entries[:3] if hasattr(entry, 'title')]
                
                # Get the published date of the most recent entry
                api_date = getattr(feed.entries[0], 'published', '') if feed.entries else ''
                
                # Simple keyword analysis
                negative_keywords = ["crisis", "instability", "protest", "conflict", "tension"]
                positive_keywords = ["stable", "growth", "agreement", "cooperation"]
                
                negative_count = sum(1 for headline in headlines for keyword in negative_keywords if keyword in headline.lower())
                positive_count = sum(1 for headline in headlines for keyword in positive_keywords if keyword in headline.lower())
                
                if negative_count > positive_count:
                    summary = f"Political monitoring shows some tensions in {city}. Recent developments warrant attention."
                else:
                    summary = f"Political conditions stable in {city}. No major adverse developments detected."
                return {"summary": summary, "api_date": api_date}
            else:
                return {"summary": f"Political conditions appear stable in {city}. No major alerts detected.", "api_date": ""}
                
        except Exception as e:
            print(f"⚠️ Political intelligence error: {e}")
            return {"summary": f"Political stability monitoring active for {city}. No major alerts detected.", "api_date": ""}
    
    def _get_disaster_intelligence(self, city: str) -> dict:
        """Get disaster alerts near city from USGS (FREE, no API key)"""
        
        try:
            # USGS Earthquake API - completely free, no API key
            url = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&minmagnitude=4.0&limit=50"
            
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                earthquakes = data.get("features", [])
                
                # Get the latest earthquake time from metadata
                metadata_time = data.get("metadata", {}).get("generated", "")
                if metadata_time:
                    from datetime import datetime as dt
                    try:
                        api_date = dt.utcfromtimestamp(metadata_time / 1000).isoformat()
                    except Exception:
                        api_date = ""
                else:
                    api_date = ""
                
                # Check for recent earthquakes near city
                city_coords = self._get_city_coordinates(city)
                if city_coords and earthquakes:
                    # Check for earthquakes within 50km of city (more precise than country-level)
                    nearby_quakes = []
                    latest_quake_time = ""
                    for eq in earthquakes:
                        coords = eq["geometry"]["coordinates"]
                        eq_lon, eq_lat = coords[0], coords[1]
                        
                        # Simple distance check (within ~50km = ~0.5 degrees)
                        if (abs(eq_lat - city_coords["lat"]) < 0.5 and 
                            abs(eq_lon - city_coords["lon"]) < 0.5):
                            magnitude = eq["properties"]["mag"]
                            nearby_quakes.append(magnitude)
                            eq_time_ms = eq["properties"].get("time", 0)
                            if eq_time_ms:
                                try:
                                    latest_quake_time = dt.utcfromtimestamp(eq_time_ms / 1000).isoformat()
                                except Exception:
                                    pass
                    
                    if nearby_quakes:
                        max_mag = max(nearby_quakes)
                        return {
                            "summary": f"Earthquake monitoring: {len(nearby_quakes)} recent earthquakes detected near {city}. Maximum magnitude: {max_mag}.",
                            "api_date": latest_quake_time or api_date
                        }
                
                return {"summary": f"No significant earthquakes detected near {city}. Geological conditions stable.", "api_date": api_date}
            else:
                return {"summary": f"Disaster monitoring active for {city}. No major alerts detected.", "api_date": ""}
                
        except Exception as e:
            print(f"⚠️ Disaster API error: {e}")
            return {"summary": f"Natural disaster monitoring active for {city}. No major alerts detected.", "api_date": ""}
    
    def _get_general_news(self, city: str) -> dict:
        """Get general news from Google News RSS"""
        try:
            search_query = f"{city} supply chain business economy"
            
            # Properly encode the search query
            encoded_query = quote_plus(search_query)
            url = f"https://news.google.com/rss/search?q={encoded_query}&hl=en&gl=US&ceid=US:en"
            
            feed = feedparser.parse(url)
            if feed.entries:
                api_date = getattr(feed.entries[0], 'published', '') if feed.entries else ''
                return {
                    "summary": f"Recent news monitoring for {city} shows normal business activity. {len(feed.entries)} relevant articles found.",
                    "api_date": api_date
                }
            else:
                return {"summary": f"News monitoring active for {city}. No major business disruptions detected.", "api_date": ""}
                
        except Exception as e:
            print(f"⚠️ News API error: {e}")
            return {"summary": f"General news monitoring active for {city}. No major alerts detected.", "api_date": ""}

# Global instance
external_intelligence_executor = ExternalIntelligenceExecutor()
