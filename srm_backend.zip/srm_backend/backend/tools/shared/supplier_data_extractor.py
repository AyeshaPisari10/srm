import pandas as pd
from typing import Dict, Any, List, Optional, Tuple
from backend.data.data_loader import DataLoader

class SupplierDataExtractor:
    """
    Shared utility to extract, transform, and aggregate supplier data
    Used across all agent tools for consistent data processing
    """
    
    def __init__(self):
        self.data_loader = DataLoader()
    
    def extract_supplier_basic_info(self, supplier_name: str) -> Dict[str, Any]:
        """Extract basic supplier information from supplier master"""
        try:
            supplier_master = self.data_loader.load_supplier_master()
            supplier_data = supplier_master[supplier_master['supplier_name'] == supplier_name]
            
            if supplier_data.empty:
                return {'error': f'Supplier {supplier_name} not found'}
            
            return supplier_data.iloc[0].to_dict()
            
        except Exception as e:
            return {'error': f'Failed to extract supplier info: {str(e)}'}
    
    def extract_financial_metrics(self, supplier_name: Optional[str] = None) -> Dict[str, Any]:
        """Extract financial risk metrics for supplier(s)"""
        try:
            financial_data = self.data_loader.load_financial_risk_data()
            
            if supplier_name:
                # Get specific supplier data
                supplier_data = financial_data[financial_data['supplier_name'] == supplier_name]
                if supplier_data.empty:
                    return {'error': f'No financial data for {supplier_name}'}
                
                # Get latest record
                latest_record = supplier_data.sort_values('update_date').iloc[-1]
                return {
                    'supplier_name': supplier_name,
                    'financial_risk_score': latest_record['financial_risk_score'],
                    'financial_risk_level': latest_record['financial_risk_level'],
                    'update_date': latest_record['update_date']
                }
            else:
                # Get aggregate metrics for all suppliers
                latest_data = financial_data.sort_values('update_date').groupby('supplier_name').tail(1)
                return {
                    'total_suppliers': len(latest_data),
                    'average_risk_score': latest_data['financial_risk_score'].mean(),
                    'high_risk_suppliers': latest_data[latest_data['financial_risk_level'] == 'HIGH']['supplier_name'].tolist(),
                    'risk_distribution': latest_data['financial_risk_level'].value_counts().to_dict()
                }
                
        except Exception as e:
            return {'error': f'Failed to extract financial metrics: {str(e)}'}
    
    def extract_performance_metrics(self, supplier_name: Optional[str] = None) -> Dict[str, Any]:
        """Extract performance risk metrics for supplier(s)"""
        try:
            performance_data = self.data_loader.load_performance_risk_data()
            
            if supplier_name:
                # Get specific supplier data
                supplier_data = performance_data[performance_data['supplier_name'] == supplier_name]
                if supplier_data.empty:
                    return {'error': f'No performance data for {supplier_name}'}
                
                # Get latest record
                latest_record = supplier_data.sort_values('update_date').iloc[-1]
                return {
                    'supplier_name': supplier_name,
                    'performance_risk_score': latest_record['performance_risk_score'],
                    'performance_risk_level': latest_record['performance_risk_level'],
                    'avg_delivery_delay_days': latest_record['avg_delivery_delay_days'],
                    'avg_quality_score': latest_record['avg_quality_score'],
                    'avg_fill_rate': latest_record['avg_fill_rate'],
                    'update_date': latest_record['update_date']
                }
            else:
                # Get aggregate metrics for all suppliers
                latest_data = performance_data.sort_values('update_date').groupby('supplier_name').tail(1)
                return {
                    'total_suppliers': len(latest_data),
                    'average_risk_score': latest_data['performance_risk_score'].mean(),
                    'deteriorating_suppliers': latest_data[latest_data['performance_risk_level'] == 'HIGH']['supplier_name'].tolist(),
                    'average_delivery_delay': latest_data['avg_delivery_delay_days'].mean(),
                    'average_quality_score': latest_data['avg_quality_score'].mean(),
                    'average_fill_rate': latest_data['avg_fill_rate'].mean()
                }
                
        except Exception as e:
            return {'error': f'Failed to extract performance metrics: {str(e)}'}
    
    def extract_geopolitical_metrics(self, supplier_name: Optional[str] = None) -> Dict[str, Any]:
        """Extract geopolitical risk metrics for supplier(s)"""
        try:
            geo_data = self.data_loader.load_geopolitical_risk_data()
            
            if supplier_name:
                # Get specific supplier data
                supplier_data = geo_data[geo_data['supplier_name'] == supplier_name]
                if supplier_data.empty:
                    return {'error': f'No geopolitical data for {supplier_name}'}
                
                # Get latest record
                latest_record = supplier_data.sort_values('update_date').iloc[-1]
                return {
                    'supplier_name': supplier_name,
                    'geopolitical_risk_score': latest_record['geopolitical_risk_score'],
                    'geopolitical_risk_level': latest_record['geopolitical_risk_level'],
                    'country': latest_record['country'],
                    'political_risk': latest_record['political_risk'],
                    'regulatory_risk': latest_record['regulatory_risk'],
                    'currency_risk': latest_record['currency_risk'],
                    'business_continuity': latest_record['business_continuity']
                }
            else:
                # Get aggregate metrics by country
                latest_data = geo_data.sort_values('update_date').groupby('supplier_name').tail(1)
                country_summary = latest_data.groupby('country').agg({
                    'geopolitical_risk_score': 'mean',
                    'supplier_name': 'count'
                }).round(2)
                
                return {
                    'total_suppliers': len(latest_data),
                    'countries_covered': len(country_summary),
                    'high_risk_regions': latest_data[latest_data['geopolitical_risk_level'] == 'HIGH']['country'].unique().tolist(),
                    'country_risk_summary': country_summary.to_dict('index')
                }
                
        except Exception as e:
            return {'error': f'Failed to extract geopolitical metrics: {str(e)}'}
    
    def get_comprehensive_supplier_profile(self, supplier_name: str) -> Dict[str, Any]:
        """Get comprehensive risk profile combining all dimensions"""
        try:
            profile = {
                'supplier_name': supplier_name,
                'profile_complete': True,
                'basic_info': {},
                'financial_risk': {},
                'performance_risk': {},
                'geopolitical_risk': {},
                'overall_assessment': {}
            }
            
            # Get basic info
            basic_info = self.extract_supplier_basic_info(supplier_name)
            if 'error' not in basic_info:
                profile['basic_info'] = basic_info
            
            # Get financial metrics
            financial = self.extract_financial_metrics(supplier_name)
            if 'error' not in financial:
                profile['financial_risk'] = financial
            else:
                profile['profile_complete'] = False
            
            # Get performance metrics
            performance = self.extract_performance_metrics(supplier_name)
            if 'error' not in performance:
                profile['performance_risk'] = performance
            else:
                profile['profile_complete'] = False
            
            # Get geopolitical metrics
            geopolitical = self.extract_geopolitical_metrics(supplier_name)
            if 'error' not in geopolitical:
                profile['geopolitical_risk'] = geopolitical
            else:
                profile['profile_complete'] = False
            
            # Generate overall assessment
            profile['overall_assessment'] = self._generate_overall_assessment(profile)
            
            return profile
            
        except Exception as e:
            return {
                'error': f'Failed to generate comprehensive profile: {str(e)}',
                'supplier_name': supplier_name
            }
    
    def _generate_overall_assessment(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Generate overall risk assessment from all dimensions"""
        
        assessment = {
            'overall_risk_level': 'UNKNOWN',
            'key_concerns': [],
            'strengths': [],
            'recommendation': 'Standard monitoring'
        }
        
        try:
            risk_levels = []
            
            # Collect risk levels
            if 'financial_risk_level' in profile.get('financial_risk', {}):
                financial_level = profile['financial_risk']['financial_risk_level']
                risk_levels.append(financial_level)
                if financial_level == 'HIGH':
                    assessment['key_concerns'].append('High financial risk')
                elif financial_level == 'LOW':
                    assessment['strengths'].append('Strong financial position')
            
            if 'performance_risk_level' in profile.get('performance_risk', {}):
                performance_level = profile['performance_risk']['performance_risk_level']
                risk_levels.append(performance_level)
                if performance_level == 'HIGH':
                    assessment['key_concerns'].append('Performance deterioration')
                elif performance_level == 'LOW':
                    assessment['strengths'].append('Good operational performance')
            
            if 'geopolitical_risk_level' in profile.get('geopolitical_risk', {}):
                geo_level = profile['geopolitical_risk']['geopolitical_risk_level']
                risk_levels.append(geo_level)
                if geo_level == 'HIGH':
                    assessment['key_concerns'].append('Geopolitical instability')
                elif geo_level == 'LOW':
                    assessment['strengths'].append('Stable operating environment')
            
            # Determine overall risk level
            if 'HIGH' in risk_levels:
                assessment['overall_risk_level'] = 'HIGH'
                assessment['recommendation'] = 'Enhanced monitoring and mitigation required'
            elif 'MEDIUM' in risk_levels:
                assessment['overall_risk_level'] = 'MEDIUM'
                assessment['recommendation'] = 'Increased monitoring recommended'
            elif risk_levels and all(level == 'LOW' for level in risk_levels):
                assessment['overall_risk_level'] = 'LOW'
                assessment['recommendation'] = 'Standard monitoring sufficient'
            
        except Exception as e:
            assessment['error'] = f'Assessment generation failed: {str(e)}'
        
        return assessment
    
    def normalize_risk_scores(self, scores: Dict[str, float], scale: Tuple[float, float] = (0, 100)) -> Dict[str, float]:
        """Normalize risk scores to specified scale"""
        if not scores:
            return {}
        
        min_score, max_score = min(scores.values()), max(scores.values())
        if min_score == max_score:
            return {k: scale[1] for k in scores.keys()}
        
        scale_min, scale_max = scale
        normalized = {}
        
        for supplier, score in scores.items():
            normalized_score = scale_min + (score - min_score) * (scale_max - scale_min) / (max_score - min_score)
            normalized[supplier] = round(normalized_score, 2)
        
        return normalized
    
    def get_risk_trends(self, supplier_name: str, months: int = 6) -> Dict[str, Any]:
        """Get risk trends for a supplier over specified months"""
        try:
            trends = {
                'supplier_name': supplier_name,
                'period_months': months,
                'financial_trend': 'stable',
                'performance_trend': 'stable',
                'geopolitical_trend': 'stable',
                'overall_trend': 'stable',
                'trend_data': {}
            }
            
            # Get financial trends
            financial_data = self.data_loader.load_financial_risk_data()
            financial_supplier = financial_data[financial_data['supplier_name'] == supplier_name]
            if not financial_supplier.empty:
                recent_financial = financial_supplier.sort_values('update_date').tail(months)
                if len(recent_financial) >= 2:
                    first_score = recent_financial.iloc[0]['financial_risk_score']
                    last_score = recent_financial.iloc[-1]['financial_risk_score']
                    if last_score > first_score + 5:
                        trends['financial_trend'] = 'deteriorating'
                    elif last_score < first_score - 5:
                        trends['financial_trend'] = 'improving'
                    
                    trends['trend_data']['financial'] = {
                        'first_score': first_score,
                        'last_score': last_score,
                        'change': last_score - first_score
                    }
            
            # Similar logic for performance and geopolitical trends...
            
            return trends
            
        except Exception as e:
            return {'error': f'Failed to get risk trends: {str(e)}'}
