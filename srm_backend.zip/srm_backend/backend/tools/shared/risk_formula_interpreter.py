import ast
import operator
from typing import Dict, Union

class RiskFormulaInterpreter:
    """
    Safe mathematical expression evaluator for dynamic risk scoring formulas
    """
    
    OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
    }
    
    def __init__(self):
        pass
    
    def evaluate(self, formula: str, variables: Dict[str, Union[int, float]]) -> float:
        """
        Safely evaluate a mathematical formula with variable substitution
        """
        try:
            tree = ast.parse(formula, mode='eval')
            result = self._eval_node(tree.body, variables)
            
            # Ensure result is a valid number
            if result is None:
                raise ValueError("Evaluation returned None")
            if not isinstance(result, (int, float)):
                raise ValueError(f"Evaluation returned non-numeric result: {type(result)}")
            
            return float(result)
            
        except Exception as e:
            raise ValueError(f"Formula evaluation failed: {str(e)}")
    
    def _eval_node(self, node, variables):
        """Recursively evaluate AST nodes"""
        
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Num):
            return node.n
        elif isinstance(node, ast.Name):
            if node.id in variables:
                return variables[node.id]
            else:
                raise ValueError(f"Unknown variable: {node.id}")
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left, variables)
            right = self._eval_node(node.right, variables)
            if type(node.op) not in self.OPERATORS:
                raise ValueError(f"Unsupported operator: {type(node.op).__name__}")
            return self.OPERATORS[type(node.op)](left, right)
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand, variables)
            if type(node.op) not in self.OPERATORS:
                raise ValueError(f"Unsupported unary operator: {type(node.op).__name__}")
            return self.OPERATORS[type(node.op)](operand)
        else:
            raise ValueError(f"Unsupported node type: {type(node).__name__}")
