from backend.utils.llm_client import get_llm_for_agents
from backend.utils.llm_utils import extract_llm_content

def extract_risk_level_from_text(risk_intelligence_output: str) -> str:
    """
    Extract highest risk level from risk intelligence text using LLM
    Simple and reliable alternative to complex regex parsing
    """
    if not risk_intelligence_output or len(risk_intelligence_output.strip()) < 10:
        return 'LOW'
    
    try:
        llm = get_llm_for_agents()
        
        prompt = f"""Extract the highest risk level mentioned in this supplier risk analysis.

Text to analyze:
{risk_intelligence_output}

Return ONLY one of these exact words: CRITICAL, HIGH, MEDIUM, LOW

If multiple risk levels are mentioned, return the highest one.
If no clear risk level is found, return LOW."""

        response = llm.invoke(prompt)
        risk_level = extract_llm_content(response).strip().upper()
        
        # Validate response
        valid_levels = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
        if risk_level in valid_levels:
            return risk_level
        else:
            # Fallback parsing
            text_upper = risk_intelligence_output.upper()
            if 'CRITICAL' in text_upper:
                return 'CRITICAL'
            elif 'HIGH' in text_upper:
                return 'HIGH'
            elif 'MEDIUM' in text_upper:
                return 'MEDIUM'
            else:
                return 'LOW'
                
    except Exception as e:
        print(f"⚠️ Risk level extraction failed: {e}")
        # Simple fallback
        text_upper = risk_intelligence_output.upper()
        if 'CRITICAL' in text_upper:
            return 'CRITICAL'
        elif 'HIGH' in text_upper:
            return 'HIGH'
        elif 'MEDIUM' in text_upper:
            return 'MEDIUM'
        else:
            return 'LOW'

def extract_risk_scores_from_text(risk_intelligence_output: str) -> dict:
    """
    Extract numeric risk scores from text as backup to structured scores
    """
    import re
    
    scores = {'financial': 0.0, 'performance': 0.0, 'geopolitical': 0.0}
    
    if not risk_intelligence_output:
        return scores
    
    # Simple patterns for score extraction
    patterns = {
        'financial': r'financial.*?risk.*?score[:\s]*([0-9]+\.?[0-9]*)',
        'performance': r'performance.*?risk.*?score[:\s]*([0-9]+\.?[0-9]*)', 
        'geopolitical': r'geopolitical.*?risk.*?score[:\s]*([0-9]+\.?[0-9]*)'
    }
    
    for risk_type, pattern in patterns.items():
        matches = re.findall(pattern, risk_intelligence_output, re.IGNORECASE)
        if matches:
            scores[risk_type] = max(float(match) for match in matches)
    
    return scores
