import pandas as pd
from typing import Dict, Any, List
from backend.data.data_loader import DataLoader

class SupplierImportanceAnalyzer:
    """
    Analyzes supplier business importance using actual PO data and supplier master
    Provides data-driven supplier dependency assessment
    """

    def __init__(self):
        self.data_loader = DataLoader()

    def analyze_supplier_importance(self, supplier_name: str) -> Dict[str, Any]:
        """
        Analyze supplier importance using actual business data
        Returns business dependency level with specific context
        """
        try:
            # Load actual business data
            po_data = self.data_loader.load_po_data()
            supplier_master = self.data_loader.load_supplier_master()

            if po_data.empty or supplier_master.empty:
                return self._fallback_response(supplier_name, "No data available")

            # Calculate business volume for last 6 months
            supplier_orders = po_data[po_data['supplier_name'] == supplier_name]

            if supplier_orders.empty:
                return self._fallback_response(supplier_name, "No order history found")

            # Business volume analysis
            total_volume = supplier_orders['po_value'].sum()
            total_business = po_data['po_value'].sum()
            volume_share = (total_volume / total_business * 100) if total_business > 0 else 0

            # Material dependency analysis
            supplier_materials = supplier_orders['material'].unique()

            # Find alternative suppliers for same materials
            alternative_suppliers = []
            for material in supplier_materials:
                alt_suppliers = po_data[
                    (po_data['material'] == material) &
                    (po_data['supplier_name'] != supplier_name)
                ]['supplier_name'].unique()
                alternative_suppliers.extend(alt_suppliers)

            alternative_suppliers = list(set(alternative_suppliers))

            # Get supplier contact info
            contact_info = supplier_master[supplier_master['supplier_name'] == supplier_name]
            contact_dict = contact_info.to_dict('records')[0] if not contact_info.empty else {}

            # Single source analysis
            single_source_materials = self.get_single_source_materials(po_data, supplier_name)
            is_single_source = len(single_source_materials) > 0

            # Enhanced importance calculation including single-source check
            importance_level = self._calculate_importance_level(
                volume_share, len(alternative_suppliers), len(supplier_materials), is_single_source
            )

            return {
                'importance_level': importance_level,
                'business_volume_6m': total_volume,
                'volume_share_percent': round(volume_share, 2),
                'critical_materials': list(supplier_materials),
                'alternative_suppliers': alternative_suppliers,
                'dependency_risk': 'HIGH' if len(alternative_suppliers) < 2 else 'MEDIUM' if len(alternative_suppliers) < 4 else 'LOW',
                'contact_info': contact_dict,
                'is_single_source': is_single_source,
                'single_source_materials': single_source_materials
            }

        except Exception as e:
            return self._fallback_response(supplier_name, f"Analysis error: {str(e)}")

    def get_single_source_materials(self, po_data: pd.DataFrame, supplier_name: str) -> List[str]:
        """Check which materials are exclusively supplied by this supplier"""
        supplier_materials = po_data[po_data['supplier_name'] == supplier_name]['material'].unique()

        single_source_materials = []
        for material in supplier_materials:
            # Count unique suppliers for this material
            suppliers_for_material = po_data[po_data['material'] == material]['supplier_name'].unique()

            if len(suppliers_for_material) == 1:
                # Only this supplier supplies this material
                single_source_materials.append(material)

        return single_source_materials

    def is_single_source_supplier(self, po_data: pd.DataFrame, supplier_name: str) -> bool:
        """Check if supplier is single source for ANY material"""
        return len(self.get_single_source_materials(po_data, supplier_name)) > 0

    def _calculate_importance_level(self, volume_share: float, alt_count: int, material_count: int, is_single_source: bool) -> str:
        """Calculate supplier importance using business rules"""
        # KEY: If single source for ANY material, automatically HIGH importance
        if is_single_source:
            return 'HIGH'

        if volume_share > 20 or (material_count > 3 and alt_count < 2):
            return 'HIGH'
        elif volume_share > 10 or (material_count > 1 and alt_count < 3):
            return 'MEDIUM'
        else:
            return 'LOW'

    def _fallback_response(self, supplier_name: str, reason: str) -> Dict[str, Any]:
        """Fallback response when analysis fails"""
        return {
            'importance_level': 'MEDIUM',
            'business_volume_6m': 0,
            'volume_share_percent': 0,
            'critical_materials': [],
            'alternative_suppliers': [],
            'dependency_risk': 'UNKNOWN',
            'contact_info': {},
            'is_single_source': False,
            'single_source_materials': [],
            'error': reason
        }
