from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class ChatMessage(BaseModel):
    role: str = Field(..., description="Message role: 'user' or 'assistant'")
    content: str = Field(..., description="Message content")
    timestamp: Optional[datetime] = Field(default_factory=datetime.now)

class ChatRequest(BaseModel):
    user_id: str = Field(..., description="Unique user identifier")
    query: str = Field(..., description="User's question or query")
    conversation_id: Optional[str] = Field(default=None, description="Conversation session ID")
    conversation_history: Optional[List[ChatMessage]] = Field(default=[], description="Previous conversation messages")
    context: Optional[Dict[str, Any]] = Field(default={}, description="Additional context information")

class ChatResponse(BaseModel):
    response: str = Field(..., description="Agent's response to the query")
    sources: Optional[List[str]] = Field(default=[], description="Information sources used")
    reasoning_chain: Optional[List[str]] = Field(default=[], description="Agent reasoning steps")
    confidence: Optional[str] = Field(default="medium", description="Response confidence level")
    conversation_id: str = Field(..., description="Conversation session ID")
    message_count: int = Field(default=0, description="Total messages in conversation")
    timestamp: datetime = Field(default_factory=datetime.now)

class HealthResponse(BaseModel):
    status: str
    timestamp: datetime = Field(default_factory=datetime.now)
    version: str = "1.0.0"

class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
