from flask import Blueprint, request, jsonify
from typing import Dict, Any
import logging
from backend.agents.graph_orchestrator import process_supplier_query
from backend.agents.memory_store import conversation_memory
import asyncio

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

chat_bp = Blueprint('chat', __name__)

@chat_bp.route("/chat", methods=["POST"])
def chat_endpoint():
    """
    Main chat endpoint with conversation memory
    """
    try:
        data = request.get_json()
        
        # Extract request data
        user_id = data.get('user_id')
        query = data.get('query')
        conversation_id = data.get('conversation_id')
        context = data.get('context', {})
        
        if not user_id or not query:
            return jsonify({"error": "user_id and query are required"}), 400
        
        # Generate conversation ID if not provided
        if not conversation_id:
            conversation_id = f"conv_{user_id}_{hash(query) % 10000}"
        
        logger.info(f"Processing query from user {user_id}: {query[:100]}...")
        
        # Add user message to memory
        conversation_memory.add_message(conversation_id, "user", query)
        
        # Get conversation history for context
        conversation_history = conversation_memory.get_recent_messages(conversation_id, limit=10)
        
        # Process query through LangGraph agent orchestrator
        context_data = {
            **context,
            'conversation_history': conversation_history,
            'conversation_id': conversation_id
        }
        
        # Run async function in event loop
        agent_result = asyncio.run(process_supplier_query(
            user_query=query,
            context=context_data
        ))
        
        # Extract response components
        response_text = agent_result.get('final_response', 'I apologize, but I was unable to process your query.')
        reasoning_chain = agent_result.get('reasoning_chain', [])
        sources = []
        
        # Extract sources from various analysis results
        if 'risk_intelligence_results' in agent_result:
            sources.append('Risk Intelligence Analysis')
        if 'external_intelligence_results' in agent_result:
            sources.append('External Intelligence Monitoring')
        if 'strategic_analysis_results' in agent_result:
            sources.append('Strategic Business Analysis')
        
        # Add assistant response to memory
        conversation_memory.add_message(conversation_id, "assistant", response_text)
        
        # Get message count
        message_count = conversation_memory.get_conversation_count(conversation_id)
        
        # Determine confidence
        confidence = "high" if len(sources) >= 2 else "medium" if sources else "low"
        
        response = {
            "response": response_text,
            "sources": sources,
            "reasoning_chain": reasoning_chain,
            "confidence": confidence,
            "conversation_id": conversation_id,
            "message_count": message_count
        }
        
        logger.info(f"Successfully processed query for user {user_id}")
        return jsonify(response)
        
    except Exception as e:
        logger.error(f"Error processing chat request: {str(e)}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500
