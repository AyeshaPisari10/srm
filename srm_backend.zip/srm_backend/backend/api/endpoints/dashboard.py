from flask import Blueprint, request, jsonify
from typing import Dict, Any, Optional
import logging
import asyncio
from datetime import datetime
from backend.data.data_loader import data_loader
from backend.dashboard.news_alerts_orchestrator import news_alerts_orchestrator
from backend.dashboard.alert_executor import alert_executor
from backend.agents.graph_orchestrator import process_supplier_query
# from backend.dashboard.risk_profile_renderer import render_supplier_risk_profile

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route("/filter-options", methods=["GET"])
def get_filter_options():
    """Get all available filter options for dashboard"""
    try:
        filter_options = data_loader.get_dashboard_filter_options()
        return jsonify(filter_options)
    except Exception as e:
        logger.error(f"Error getting filter options: {e}")
        return jsonify({"error": f"Error getting filter options: {str(e)}"}), 500

@dashboard_bp.route("/overview-stats", methods=["GET"])
def get_overview_stats():
    """Get risk level counts for dashboard overview cards with filtering"""
    try:
        # Get query parameters
        risk_type = request.args.get('risk_type', 'overall')
        material = request.args.get('material')
        country = request.args.get('country')
        month = request.args.get('month')
        
        # Get stats with filters applied
        stats = data_loader.get_dashboard_overview_stats(
            risk_type=risk_type,
            material=material,
            country=country,
            month=month
        )
        
        # Add filter status
        stats["filtered"] = any([material, country, month])
        
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"Error getting overview stats: {e}")
        return jsonify({"error": f"Error getting overview stats: {str(e)}"}), 500

@dashboard_bp.route("/suppliers", methods=["GET"])
def get_all_suppliers():
    """Get all suppliers with current risk levels and filtering"""
    try:
        # Get query parameters
        risk_type = request.args.get('risk_type', 'overall')
        material = request.args.get('material')
        country = request.args.get('country')
        month = request.args.get('month')
        
        # Get suppliers list with filters applied
        suppliers = data_loader.get_dashboard_suppliers_list(
            risk_type=risk_type,
            material=material,
            country=country,
            month=month
        )
        
        return jsonify(suppliers)
        
    except Exception as e:
        logger.error(f"Error getting suppliers: {e}")
        return jsonify({"error": f"Error getting suppliers: {str(e)}"}), 500

@dashboard_bp.route("/supplier/<supplier_name>", methods=["GET"])
def get_supplier_details(supplier_name: str):
    """Get detailed information for specific supplier"""
    try:
        supplier_details = data_loader.get_dashboard_supplier_details(supplier_name)
        
        if supplier_details is None:
            return jsonify({"error": f"Supplier '{supplier_name}' not found"}), 404
        
        return jsonify(supplier_details)
        
    except Exception as e:
        logger.error(f"Error getting supplier details: {e}")
        return jsonify({"error": f"Error getting supplier details: {str(e)}"}), 500

@dashboard_bp.route("/risk-data/<risk_type>/<supplier_name>", methods=["GET"])
def get_specific_risk_data(risk_type: str, supplier_name: str):
    """Get specific risk dataset data for supplier"""
    try:
        risk_data = data_loader.get_dashboard_risk_data(risk_type, supplier_name)
        
        if not risk_data:
            return jsonify({"error": f"No {risk_type} data found for supplier '{supplier_name}'"}), 404
        
        return jsonify(risk_data)
        
    except Exception as e:
        logger.error(f"Error getting {risk_type} risk data: {e}")
        return jsonify({"error": f"Error getting {risk_type} risk data: {str(e)}"}), 500

@dashboard_bp.route("/recent-dashboard-alerts", methods=["GET"])
def get_recent_dashboard_alerts():
    """Get recent alerts using external intelligence"""
    try:
        data = news_alerts_orchestrator.get_cached_alerts_data(limit=5)
        return jsonify(data)
        
    except Exception as e:
        logger.error(f"Error getting dashboard alerts: {e}")
        return jsonify({"error": f"Error getting dashboard alerts: {str(e)}"}), 500

@dashboard_bp.route("/refresh-dashboard-alerts", methods=["POST"])
def refresh_dashboard_alerts():
    """Refresh dashboard alerts using external intelligence"""
    try:
        alerts = news_alerts_orchestrator.fetch_and_cache_alerts()
        
        return jsonify({
            "success": True,
            "alerts_count": len(alerts),
            "message": "Dashboard alerts refreshed successfully",
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error refreshing alerts: {e}")
        return jsonify({"error": f"Error refreshing alerts: {str(e)}"}), 500

@dashboard_bp.route("/alert", methods=["POST"])
def create_alert():
    """Create alert using existing alert executor"""
    try:
        data = request.get_json()
        supplier_name = data.get('supplier_name')
        risk_type = data.get('risk_type', 'overall')
        severity = data.get('severity', 'HIGH')
        
        if not supplier_name:
            return jsonify({"error": "supplier_name is required"}), 400
        
        # Create alert query for the alert executor
        alert_query = f"Create alert for {supplier_name} with {severity} {risk_type} risk level"
        
        # Use the alert executor to create the alert
        result = alert_executor.execute(alert_query, {
            'supplier_name': supplier_name,
            'risk_type': risk_type,
            'severity': severity
        })
        
        if result.get('success'):
            return jsonify({
                "success": True,
                "alert_id": result.get('alert_id'),
                "message": f"Alert created for {supplier_name}"
            })
        else:
            return jsonify({
                "success": False,
                "error": result.get('error', 'Unknown error')
            }), 500
        
    except Exception as e:
        logger.error(f"Error creating alert: {e}")
        return jsonify({"error": f"Error creating alert: {str(e)}"}), 500

# Health check endpoint for dashboard
@dashboard_bp.route("/health", methods=["GET"])
def dashboard_health():
    """Dashboard health check"""
    return jsonify({
        "status": "healthy",
        "service": "supplier_risk_dashboard",
        "version": "1.0.0"
    })

@dashboard_bp.route("/risk-profile", methods=["POST"])
def get_supplier_risk_profile():
    """
    Generate comprehensive risk profile for a specific supplier
    Triggers the same agent pipeline as chatbot with 'show risk profile' query
    """
    try:
        data = request.get_json()
        
        # Validate input
        supplier_name = data.get('supplier_name')
        user_id = data.get('user_id', 'dashboard_user')
        
        if not supplier_name:
            return jsonify({"error": "supplier_name is required"}), 400

        logger.info(f"Generating risk profile for supplier: {supplier_name}")

        # Construct the risk profile query (same as chatbot)
        risk_profile_query = f"show me the risk profile for {supplier_name}"
        
        # Context for the agent
        context_data = {
            'source': 'dashboard_risk_profile',
            'supplier_focus': supplier_name,
            'conversation_history': []  # Empty for one-shot analysis
        }

        # Call the same agent orchestrator used by chatbot
        agent_result = asyncio.run(process_supplier_query(
            user_query=risk_profile_query,
            context=context_data
        ))

        # Extract response components
        response_text = agent_result.get('final_response', 'Unable to generate risk profile')
        reasoning_chain = agent_result.get('reasoning_chain', [])
        
        # Extract analysis sources
        sources = []
        if 'risk_intelligence_results' in agent_result:
            sources.append('Risk Intelligence Analysis')
        if 'external_intelligence_results' in agent_result:
            sources.append('External Intelligence Monitoring')
        if 'strategic_analysis_results' in agent_result:
            sources.append('Strategic Business Analysis')

        # Determine confidence based on agent results
        confidence = "high" if len(sources) >= 2 else "medium" if sources else "low"

        # Structured response for frontend
        response = {
            "success": True,
            "supplier_name": supplier_name,
            "risk_profile": response_text,
            "sources": sources,
            "reasoning_chain": reasoning_chain,
            "confidence": confidence,
            "generated_at": datetime.now().isoformat(),
            "query_type": "risk_profile"
        }

        logger.info(f"Risk profile generated successfully for {supplier_name}")
        return jsonify(response)

    except Exception as e:
        logger.error(f"Error generating risk profile: {str(e)}")
        return jsonify({
            "success": False,
            "error": f"Failed to generate risk profile: {str(e)}"
        }), 500
    
# @dashboard_bp.route("/risk-profile", methods=["POST"])
# def get_supplier_risk_profile():
#     """Generate comprehensive risk profile with HTML formatting"""
#     try:
#         data = request.get_json()
#         supplier_name = data.get('supplier_name')
        
#         if not supplier_name:
#             return jsonify({"error": "supplier_name is required"}), 400

#         # Call agents (same as before)
#         risk_profile_query = f"show me the risk profile for {supplier_name}"
#         agent_result = asyncio.run(process_supplier_query(
#             user_query=risk_profile_query,
#             context={'source': 'dashboard_risk_profile'}
#         ))

#         # Extract agent response
#         agent_output = agent_result.get('final_response', '')
        
#         # NEW: Render as structured HTML
#         formatted_html = render_supplier_risk_profile(
#             agent_output=agent_output,
#             supplier_name=supplier_name,
#             additional_data={
#                 'sources': len([k for k in agent_result.keys() if k.endswith('_results')]),
#                 'generated_at': datetime.now().isoformat()
#             }
#         )

#         return jsonify({
#             "success": True,
#             "supplier_name": supplier_name,
#             "risk_profile_html": formatted_html,  # NEW: Formatted HTML
#             "raw_response": agent_output,  # Keep raw for debugging
#             "confidence": "high",
#             "generated_at": datetime.now().isoformat()
#         })

#     except Exception as e:
#         logger.error(f"Error generating risk profile: {str(e)}")
#         return jsonify({"success": False, "error": str(e)}), 500