import os
import sys

# Add project root to Python path
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '..', '..'))
sys.path.insert(0, project_root)

from flask import Flask
from flask_cors import CORS
from backend.api.endpoints.chat import chat_bp
from backend.api.endpoints.dashboard import dashboard_bp

app = Flask(__name__)
if CORS is not None:
    CORS(app)  # enable CORS for dev convenience

# Register blueprints
app.register_blueprint(chat_bp, url_prefix="/api")
app.register_blueprint(dashboard_bp, url_prefix="/api/dashboard")

@app.route("/")
def root():
    return {"message": "Supplier Risk Management API", "status": "running"}

@app.route("/health")
def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5001)