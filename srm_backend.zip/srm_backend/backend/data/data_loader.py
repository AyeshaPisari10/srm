import pandas as pd
from pathlib import Path
from typing import Optional, Dict, Any, List, cast
import logging

class DataLoader:
    """
    DataLoader for supplier risk management system
    Handles loading raw and processed CSV datasets with caching and error handling
    """
    
    def __init__(self, base_data_dir: str = "backend/data"):
        self.base_dir = Path(base_data_dir)
        self.raw_dir = self.base_dir / "raw"
        self.processed_dir = self.base_dir / "processed"
        self._cache: Dict[str, pd.DataFrame] = {}
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Validate data directories exist
        self._validate_directories()
    
    def _validate_directories(self):
        """Validate that required directories exist"""
        if not self.raw_dir.exists():
            self.logger.warning(f"Raw data directory not found: {self.raw_dir}")
        if not self.processed_dir.exists():
            self.logger.warning(f"Processed data directory not found: {self.processed_dir}")
    
    def _load_csv_with_cache(self, filepath: Path, cache_key: str) -> pd.DataFrame:
        """Load CSV with caching and error handling"""
        if cache_key in self._cache:
            return self._cache[cache_key].copy()
        
        try:
            if not filepath.exists():
                self.logger.error(f"File not found: {filepath}")
                return pd.DataFrame()
            
            df = pd.read_csv(filepath)
            self._cache[cache_key] = df
            self.logger.info(f"Loaded {filepath.name}: {len(df)} rows, {len(df.columns)} columns")
            return df.copy()
            
        except Exception as e:
            self.logger.error(f"Error loading {filepath}: {e}")
            return pd.DataFrame()
    
    # Raw Data Loaders
    def load_supplier_master(self) -> pd.DataFrame:
        """Load supplier master data"""
        filepath = self.raw_dir / "supplier_master.csv"
        return self._load_csv_with_cache(filepath, "supplier_master")
    
    def load_po_data(self) -> pd.DataFrame:
        """Load purchase order data"""
        filepath = self.raw_dir / "po_data.csv"
        return self._load_csv_with_cache(filepath, "po_data")
    
    def load_dun_bradstreet_finance(self) -> pd.DataFrame:
        """Load D&B financial data"""
        filepath = self.raw_dir / "dun_bradstreet_finance_data.csv"
        return self._load_csv_with_cache(filepath, "db_finance")
    
    def load_dun_bradstreet_geo(self) -> pd.DataFrame:
        """Load D&B geopolitical data"""
        filepath = self.raw_dir / "dun_bradstreet_geo_data.csv"
        return self._load_csv_with_cache(filepath, "db_geo")
    
    # Processed Risk Data Loaders
    def load_financial_risk_data(self) -> pd.DataFrame:
        """Load processed financial risk scores"""
        filepath = self.processed_dir / "financial_risk_data.csv"
        return self._load_csv_with_cache(filepath, "financial_risk")
    
    def load_performance_risk_data(self) -> pd.DataFrame:
        """Load processed performance risk scores"""
        filepath = self.processed_dir / "performance_risk_data.csv"
        return self._load_csv_with_cache(filepath, "performance_risk")
    
    def load_geopolitical_risk_data(self) -> pd.DataFrame:
        """Load processed geopolitical risk scores"""
        filepath = self.processed_dir / "geopolitical_risk_data.csv"
        return self._load_csv_with_cache(filepath, "geopolitical_risk")
    
    def load_overall_risk_data(self) -> pd.DataFrame:
        """Load processed overall risk scores"""
        filepath = self.processed_dir / "overall_risk_data.csv"
        return self._load_csv_with_cache(filepath, "overall_risk")
    
    # Specialized Data Access Methods for Agents
    def get_supplier_risk_profile(self, supplier_name: str) -> Dict[str, Any]:
        """Get comprehensive risk profile for a specific supplier"""
        profile = {
            'supplier_name': supplier_name,
            'financial_risk': {},
            'performance_risk': {},
            'geopolitical_risk': {},
            'overall_risk': {},
            'supplier_info': {}
        }
        
        # Get supplier basic info
        supplier_master = self.load_supplier_master()
        supplier_info = supplier_master[supplier_master['supplier_name'] == supplier_name]
        if not supplier_info.empty:
            profile['supplier_info'] = supplier_info.iloc[0].to_dict()
        
        # Get financial risk
        financial_risk = self.load_financial_risk_data()
        financial_data = financial_risk[financial_risk['supplier_name'] == supplier_name]
        if not financial_data.empty:
            latest_financial = financial_data.sort_values('update_date').iloc[-1]
            profile['financial_risk'] = latest_financial.to_dict()
        
        # Get performance risk
        performance_risk = self.load_performance_risk_data()
        performance_data = performance_risk[performance_risk['supplier_name'] == supplier_name]
        if not performance_data.empty:
            latest_performance = performance_data.sort_values('update_date').iloc[-1]
            profile['performance_risk'] = latest_performance.to_dict()
        
        # Get geopolitical risk
        geopolitical_risk = self.load_geopolitical_risk_data()
        geo_data = geopolitical_risk[geopolitical_risk['supplier_name'] == supplier_name]
        if not geo_data.empty:
            latest_geo = geo_data.sort_values('update_date').iloc[-1]
            profile['geopolitical_risk'] = latest_geo.to_dict()
        
        # Get overall risk
        overall_risk = self.load_overall_risk_data()
        overall_data = overall_risk[overall_risk['supplier_name'] == supplier_name]
        if not overall_data.empty:
            latest_overall = overall_data.sort_values('update_date').iloc[-1]
            profile['overall_risk'] = latest_overall.to_dict()
        
        return profile
    
    def get_suppliers_by_risk_level(self, risk_type: str = 'overall', risk_level: str = 'HIGH') -> pd.DataFrame:
        """Get suppliers by risk level and type"""
        risk_data_map = {
            'financial': self.load_financial_risk_data(),
            'performance': self.load_performance_risk_data(),
            'geopolitical': self.load_geopolitical_risk_data(),
            'overall': self.load_overall_risk_data()
        }
        
        if risk_type not in risk_data_map:
            self.logger.error(f"Invalid risk type: {risk_type}")
            return pd.DataFrame()
        
        risk_data = risk_data_map[risk_type]
        risk_level_col = f"{risk_type}_risk_level"
        
        if risk_level_col not in risk_data.columns:
            self.logger.error(f"Risk level column not found: {risk_level_col}")
            return pd.DataFrame()
        
        filtered_data = risk_data[risk_data[risk_level_col] == risk_level]
        return filtered_data
    
    def get_supplier_performance_trends(self, supplier_name: str, months: int = 6) -> pd.DataFrame:
        """Get performance trends for a supplier over specified months"""
        performance_data = self.load_performance_risk_data()
        supplier_data = performance_data[performance_data['supplier_name'] == supplier_name]
        
        if supplier_data.empty:
            return pd.DataFrame()
        
        # Convert update_date to datetime for sorting
        supplier_data = supplier_data.copy()
        supplier_data['update_date'] = pd.to_datetime(supplier_data['update_date'])
        
        # Get latest N months
        latest_data = supplier_data.sort_values('update_date').tail(months)
        return latest_data
    
    def get_country_risk_summary(self) -> pd.DataFrame:
        """Get risk summary by country"""
        geopolitical_data = self.load_geopolitical_risk_data()
        
        if geopolitical_data.empty:
            return pd.DataFrame()
        
        # Get latest data for each country
        latest_geo = geopolitical_data.sort_values('update_date').groupby('country').tail(1)
        return latest_geo
    
    # === NEW DASHBOARD-SPECIFIC METHODS ===
    
    def get_dashboard_filter_options(self) -> Dict[str, List[str]]:
        """Get all available filter options for dashboard"""
        try:
            po_data = self.load_po_data()
            supplier_master = self.load_supplier_master()
            
            # Process PO data for date filtering
            po_data['arrival_date'] = pd.to_datetime(po_data['arrival_date'], errors='coerce')
            po_data_with_dates = po_data.dropna(subset=['arrival_date'])
            po_data_with_dates['year_month'] = po_data_with_dates['arrival_date'].dt.to_period('M')
            
            return {
                "risk_types": ["overall", "financial", "performance", "geopolitical"],
                "materials": sorted(po_data['material'].dropna().unique().tolist()),
                "countries": sorted(supplier_master['country'].dropna().unique().tolist()),
                "months": sorted(po_data_with_dates['year_month'].unique().astype(str).tolist(), reverse=True)
            }
        except Exception as e:
            self.logger.error(f"Error getting filter options: {e}")
            return {"risk_types": ["overall"], "materials": [], "countries": [], "months": []}
    
    def get_filtered_suppliers(self, material: Optional[str] = None, 
                             country: Optional[str] = None, 
                             month: Optional[str] = None) -> Optional[List[str]]:
        """Get list of supplier names that match the filters"""
        try:
            filtered_suppliers = None
            
            # Filter by material
            if material:
                po_data = self.load_po_data()
                material_suppliers = po_data[po_data['material'] == material]['supplier_name'].unique()
                filtered_suppliers = set(material_suppliers)
            
            # Filter by country
            if country:
                supplier_master = self.load_supplier_master()
                country_suppliers = supplier_master[supplier_master['country'] == country]['supplier_name'].unique()
                if filtered_suppliers is not None:
                    filtered_suppliers = filtered_suppliers.intersection(set(country_suppliers))
                else:
                    filtered_suppliers = set(country_suppliers)
            
            # Filter by month
            if month:
                po_data = self.load_po_data()
                po_data['arrival_date'] = pd.to_datetime(po_data['arrival_date'], errors='coerce')
                po_data_month = po_data.dropna(subset=['arrival_date'])
                po_data_month['year_month'] = po_data_month['arrival_date'].dt.to_period('M').astype(str)
                month_suppliers = po_data_month[po_data_month['year_month'] == month]['supplier_name'].unique()
                
                if filtered_suppliers is not None:
                    filtered_suppliers = filtered_suppliers.intersection(set(month_suppliers))
                else:
                    filtered_suppliers = set(month_suppliers)
            
            return list(filtered_suppliers) if filtered_suppliers is not None else None
            
        except Exception as e:
            self.logger.error(f"Error applying filters: {e}")
            return None
    
    def get_dashboard_overview_stats(self, risk_type: str = 'overall',
                                   material: Optional[str] = None,
                                   country: Optional[str] = None,
                                   month: Optional[str] = None) -> Dict[str, int]:
        """Get risk level distribution stats for dashboard overview cards"""
        try:
            # Get appropriate risk dataset
            risk_data_map = {
                'overall': self.load_overall_risk_data(),
                'financial': self.load_financial_risk_data(),
                'performance': self.load_performance_risk_data(),
                'geopolitical': self.load_geopolitical_risk_data()
            }
            
            risk_level_col_map = {
                'overall': 'overall_risk_level',
                'financial': 'financial_risk_level',
                'performance': 'performance_risk_level',
                'geopolitical': 'geopolitical_risk_level'
            }
            
            if risk_type not in risk_data_map:
                return {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "total_suppliers": 0}
            
            risk_df = risk_data_map[risk_type]
            risk_level_column = risk_level_col_map[risk_type]
            
            # Get latest data for each supplier
            latest_date = risk_df["update_date"].max()
            current_df = risk_df[risk_df["update_date"] == latest_date].copy()
            
            # Apply filters
            filtered_suppliers = self.get_filtered_suppliers(material, country, month)
            if filtered_suppliers is not None:
                current_df = current_df[current_df["supplier_name"].isin(filtered_suppliers)]
            
            # Count risk levels
            stats = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
            if not current_df.empty and risk_level_column in current_df.columns:
                risk_counts = current_df[risk_level_column].value_counts()
                for level in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
                    stats[level] = int(risk_counts.get(level, 0))
            
            stats["total_suppliers"] = len(current_df)
            return stats
            
        except Exception as e:
            self.logger.error(f"Error getting overview stats: {e}")
            return {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "total_suppliers": 0}
    
    def get_dashboard_suppliers_list(self, risk_type: str = 'overall',
                                   material: Optional[str] = None,
                                   country: Optional[str] = None,
                                   month: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get suppliers list with risk scores for dashboard table"""
        try:
            # Get appropriate risk dataset
            risk_data_map = {
                'overall': self.load_overall_risk_data(),
                'financial': self.load_financial_risk_data(),
                'performance': self.load_performance_risk_data(),
                'geopolitical': self.load_geopolitical_risk_data()
            }
            
            risk_col_map = {
                'overall': ('overall_risk_level', 'overall_risk_score'),
                'financial': ('financial_risk_level', 'financial_risk_score'),
                'performance': ('performance_risk_level', 'performance_risk_score'),
                'geopolitical': ('geopolitical_risk_level', 'geopolitical_risk_score')
            }
            
            if risk_type not in risk_data_map:
                return []
            
            df = risk_data_map[risk_type]
            level_col, score_col = risk_col_map[risk_type]
            
            # Get latest data for each supplier
            latest_date = df["update_date"].max()
            current_df = df[df["update_date"] == latest_date].copy()
            
            # Apply filters
            filtered_suppliers = self.get_filtered_suppliers(material, country, month)
            if filtered_suppliers is not None:
                current_df = current_df[current_df["supplier_name"].isin(filtered_suppliers)]
            
            # Prepare result
            current_df["risk_level"] = current_df[level_col]
            current_df["risk_score"] = current_df[score_col]
            current_df = current_df.sort_values("risk_score", ascending=False)
            
            return current_df.to_dict("records")
            
        except Exception as e:
            self.logger.error(f"Error getting suppliers list: {e}")
            return []
    
    def get_dashboard_supplier_details(self, supplier_name: str) -> Optional[Dict[str, Any]]:
        """Get comprehensive supplier details for dashboard"""
        try:
            # Get latest data from all risk dimensions
            overall_df = self.load_overall_risk_data()
            financial_df = self.load_financial_risk_data()
            performance_df = self.load_performance_risk_data()
            geo_df = self.load_geopolitical_risk_data()
            
            latest_date = overall_df["update_date"].max()
            
            # Get supplier data from each dimension
            supplier_overall = overall_df[
                (overall_df["supplier_name"] == supplier_name) & 
                (overall_df["update_date"] == latest_date)
            ]
            
            if supplier_overall.empty:
                return None
            
            supplier_financial = financial_df[
                (financial_df["supplier_name"] == supplier_name) & 
                (financial_df["update_date"] == latest_date)
            ].to_dict("records")
            
            supplier_performance = performance_df[
                (performance_df["supplier_name"] == supplier_name) & 
                (performance_df["update_date"] == latest_date)
            ].to_dict("records")
            
            supplier_geo = geo_df[
                (geo_df["supplier_name"] == supplier_name) & 
                (geo_df["update_date"] == latest_date)
            ].to_dict("records")
            
            # Build comprehensive result
            result = supplier_overall.iloc[0].to_dict()
            result["risk_level"] = result["overall_risk_level"]
            result["financial_details"] = supplier_financial[0] if supplier_financial else {}
            result["performance_details"] = supplier_performance[0] if supplier_performance else {}
            result["geopolitical_details"] = supplier_geo[0] if supplier_geo else {}
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error getting supplier details: {e}")
            return None

    def get_dashboard_risk_data(self, risk_type: str, supplier_name: str) -> List[Dict[str, Any]]:
        """Get historical risk data for specific risk type and supplier"""
        try:
            risk_data_map = {
                'financial': self.load_financial_risk_data(),
                'performance': self.load_performance_risk_data(),
                'geopolitical': self.load_geopolitical_risk_data(),
                'overall': self.load_overall_risk_data()
            }
            
            if risk_type not in risk_data_map:
                return []
            
            df = risk_data_map[risk_type]
            supplier_data = df[df["supplier_name"] == supplier_name].copy()
            
            if supplier_data.empty:
                return []
            
            # Sort by date (newest first)
            supplier_data = supplier_data.sort_values("update_date", ascending=False)
            
            # Fix type error by using cast to tell type checker the keys are strings
            result = supplier_data.to_dict(orient="records")
            return cast(List[Dict[str, Any]], result)
            
        except Exception as e:
            self.logger.error(f"Error getting {risk_type} risk data: {e}")
            return []
    
    # Utility Methods
    def clear_cache(self):
        """Clear all cached DataFrames"""
        self._cache.clear()
        self.logger.info("Cache cleared")
    
    def get_data_summary(self) -> Dict[str, Any]:
        """Get summary of all available datasets"""
        summary = {
            'raw_data': {},
            'processed_data': {},
            'cache_status': len(self._cache)
        }
        
        # Check raw data files
        raw_files = ['supplier_master.csv', 'po_data.csv', 'dun_bradstreet_finance_data.csv', 'dun_bradstreet_geo_data.csv']
        for filename in raw_files:
            filepath = self.raw_dir / filename
            if filepath.exists():
                try:
                    df = pd.read_csv(filepath)
                    summary['raw_data'][filename] = {'rows': len(df), 'columns': len(df.columns)}
                except:
                    summary['raw_data'][filename] = 'error'
            else:
                summary['raw_data'][filename] = 'missing'
        
        # Check processed data files
        processed_files = ['financial_risk_data.csv', 'performance_risk_data.csv', 'geopolitical_risk_data.csv', 'overall_risk_data.csv']
        for filename in processed_files:
            filepath = self.processed_dir / filename
            if filepath.exists():
                try:
                    df = pd.read_csv(filepath)
                    summary['processed_data'][filename] = {'rows': len(df), 'columns': len(df.columns)}
                except:
                    summary['processed_data'][filename] = 'error'
            else:
                summary['processed_data'][filename] = 'missing'
        
        return summary

# Global instance for easy import
data_loader = DataLoader()

# Convenience functions for agents
def get_supplier_profile(supplier_name: str) -> Dict[str, Any]:
    """Convenience function to get supplier risk profile"""
    return data_loader.get_supplier_risk_profile(supplier_name)

def get_high_risk_suppliers(risk_type: str = 'overall') -> pd.DataFrame:
    """Convenience function to get high-risk suppliers"""
    return data_loader.get_suppliers_by_risk_level(risk_type, 'HIGH')

def get_performance_trends(supplier_name: str, months: int = 6) -> pd.DataFrame:
    """Convenience function to get performance trends"""
    return data_loader.get_supplier_performance_trends(supplier_name, months)

# Test function for POC validation
def test_data_availability():
    """Test function to validate data availability for POC"""
    loader = DataLoader()
    summary = loader.get_data_summary()
    
    print("=== Data Availability Summary ===")
    print(f"Cache status: {summary['cache_status']} datasets cached")
    
    print("\nRaw Data:")
    for filename, status in summary['raw_data'].items():
        if isinstance(status, dict):
            print(f"✅ {filename}: {status['rows']} rows, {status['columns']} columns")
        else:
            print(f"❌ {filename}: {status}")
    
    print("\nProcessed Data:")
    for filename, status in summary['processed_data'].items():
        if isinstance(status, dict):
            print(f"✅ {filename}: {status['rows']} rows, {status['columns']} columns")
        else:
            print(f"❌ {filename}: {status}")
    
    return summary

if __name__ == "__main__":
    test_data_availability()
