def extract_llm_content(response) -> str:
    """
    Universal helper to extract clean content from Azure LLM response
    Handles langchain_core.messages.ai.AIMessage objects properly
    """
    # Handle AIMessage objects (your actual response type)
    if hasattr(response, 'content'):
        content = response.content
        if isinstance(content, str):
            return content.strip()
        elif isinstance(content, list):
            # Handle list of content parts
            text = ''
            for item in content:
                if isinstance(item, str):
                    text += item + '\n'
                elif isinstance(item, dict):
                    if 'content' in item:
                        text += item['content'] + '\n'
                    elif 'text' in item:
                        text += item['text'] + '\n'
            return text.strip()
        else:
            return str(content).strip()
    
    # Fallback for other response types
    return str(response).strip()
