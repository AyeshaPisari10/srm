import logging
import sys
from datetime import datetime
from typing import Optional, Dict, Any

class AgentLogger:
    """
    Centralized logging for agent reasoning and debugging
    Provides transparency into agent decision-making process
    """
    
    def __init__(self, name: str = "supplier_risk_agent"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Avoid duplicate handlers
        if not self.logger.handlers:
            self._setup_handlers()
    
    def _setup_handlers(self):
        """Setup console and file handlers"""
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        
        # File handler for debugging
        file_handler = logging.FileHandler('agent_reasoning.log')
        file_handler.setLevel(logging.DEBUG)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s | %(name)s | %(levelname)s | %(message)s'
        )
        
        console_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)
        
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)
    
    def log_agent_start(self, agent_name: str, query: str):
        """Log agent processing start"""
        self.logger.info(f"🚀 {agent_name} started processing: '{query[:100]}...'")
    
    def log_agent_complete(self, agent_name: str, success: bool = True):
        """Log agent processing completion"""
        status = "✅ completed" if success else "❌ failed"
        self.logger.info(f"{agent_name} {status}")
    
    def log_tool_usage(self, tool_name: str, input_data: str = ""):
        """Log tool invocation"""
        self.logger.info(f"🔧 Tool invoked: {tool_name} | Input: {input_data[:50]}...")
    
    def log_reasoning_step(self, step: str, details: Optional[str] = None):
        """Log reasoning step for transparency"""
        message = f"💭 Reasoning: {step}"
        if details:
            message += f" | Details: {details}"
        self.logger.info(message)
    
    def log_data_access(self, data_source: str, query_type: str):
        """Log data access for audit trail"""
        self.logger.info(f"📊 Data access: {data_source} | Query type: {query_type}")
    
    def log_risk_analysis(self, risk_type: str, result: Dict[str, Any]):
        """Log risk analysis results"""
        risk_level = result.get('risk_level', 'unknown')
        self.logger.info(f"⚠️ Risk analysis - {risk_type}: {risk_level} risk detected")
    
    def log_error(self, component: str, error: str, details: Optional[str] = None):
        """Log errors with context"""
        message = f"❌ Error in {component}: {error}"
        if details:
            message += f" | Details: {details}"
        self.logger.error(message)
    
    def log_workflow_transition(self, from_node: str, to_node: str, reason: str = ""):
        """Log workflow transitions for debugging"""
        message = f"🔀 Workflow: {from_node} → {to_node}"
        if reason:
            message += f" | Reason: {reason}"
        self.logger.info(message)
    
    def log_final_response(self, response_length: int, sources_count: int):
        """Log final response generation"""
        self.logger.info(f"📝 Final response generated: {response_length} chars, {sources_count} sources")

# Global logger instance
agent_logger = AgentLogger()

# Convenience functions
def log_agent_start(agent_name: str, query: str):
    """Log agent processing start"""
    agent_logger.log_agent_start(agent_name, query)

def log_agent_complete(agent_name: str, success: bool = True):
    """Log agent processing completion"""
    agent_logger.log_agent_complete(agent_name, success)

def log_reasoning_step(step: str, details: Optional[str] = None):
    """Log reasoning step"""
    agent_logger.log_reasoning_step(step, details)

def log_tool_usage(tool_name: str, input_data: str = ""):
    """Log tool usage"""
    agent_logger.log_tool_usage(tool_name, input_data)

def log_error(component: str, error: str, details: Optional[str] = None):
    """Log errors"""
    agent_logger.log_error(component, error, details)

def log_workflow_transition(from_node: str, to_node: str, reason: str = ""):
    """Log workflow transitions"""
    agent_logger.log_workflow_transition(from_node, to_node, reason)

# Usage example in agent nodes:
# from backend.utils.logger import log_agent_start, log_reasoning_step, log_agent_complete
#
# def risk_intelligence_node(state: AgentState) -> AgentState:
#     log_agent_start("Risk Intelligence", state['user_query'])
#     log_reasoning_step("Analyzing financial risk data")
#     # ... agent logic ...
#     log_agent_complete("Risk Intelligence", success=True)
#     return state
