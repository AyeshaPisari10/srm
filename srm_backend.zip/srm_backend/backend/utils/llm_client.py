from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
import os
from pydantic import SecretStr
from functools import lru_cache

# Load environment variables
load_dotenv()

@lru_cache()
def get_azure_llm():
    """
    Get configured Azure OpenAI LLM client for agentic AI
    Cached for performance across agents and tools
    """
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    if not api_key:
        raise ValueError("AZURE_OPENAI_API_KEY not found in environment")
    
    api_key_secret = SecretStr(api_key)
    
    # FIXED: Removed temperature=0.1 as gpt-5 only supports default (temperature=1)
    # Your model deployment 'gpt-5' does not support custom temperature values
    return AzureChatOpenAI(
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=api_key_secret,
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-12-01-preview"),
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        # temperature=0.1,
        # timeout=30,
        timeout=90, 
        request_timeout=90
    )


def get_llm_for_agents():
    """Dedicated LLM instance for agent reasoning and coordination"""
    return get_azure_llm()


def get_llm_for_tools():
    """Dedicated LLM instance for tool operations"""
    return get_azure_llm()


# Test connection function for POC validation
def test_llm_connection():
    """Test Azure OpenAI connection for POC setup validation"""
    try:
        llm = get_azure_llm()
        response = llm.invoke([{"role": "user", "content": "Test connection"}])
        print("✅ Azure OpenAI connection successful")
        return True
    except Exception as e:
        print(f"❌ Azure OpenAI connection failed: {e}")
        return False


if __name__ == "__main__":
    test_llm_connection()
