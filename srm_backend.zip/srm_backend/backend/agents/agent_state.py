from typing_extensions import TypedDict
from typing import List, Dict, Any

class AgentState(TypedDict):
    # Existing fields
    user_query: str
    conversation_context: Dict[str, Any]
    query_analysis: Dict[str, Any]
    risk_intelligence_results: Dict[str, Any]
    external_intelligence_results: Dict[str, Any]
    strategic_analysis_results: Dict[str, Any]
    final_response: str
    reasoning_chain: List[str]
    
    # NEW FIELDS for enhanced routing and data-driven recommendations
    supplier_importance_results: Dict[str, Any]  # Supplier importance analysis results
    query_intent_category: str                   # 'data_query' | 'comparison' | 'assessment'
    routing_tier: str                           # 'Tier_1' | 'Tier_2' | 'Tier_3'
    skip_strategic_advisor: bool                 # Flag for direct routing optimization
