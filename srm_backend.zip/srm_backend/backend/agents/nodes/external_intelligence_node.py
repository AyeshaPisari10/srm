from typing import Dict, Any, List, Optional, Tuple
from langchain_core.prompts import PromptTemplate, ChatPromptTemplate
from langchain_core.tools import Tool
from langgraph.prebuilt import create_react_agent
from backend.utils.llm_client import get_llm_for_agents
from backend.utils.llm_utils import extract_llm_content
from backend.data.data_loader import DataLoader
from backend.tools.external_intelligence.external_intelligence_executor import external_intelligence_executor
from ..agent_state import AgentState

def external_intelligence_node(state: AgentState) -> AgentState:
    """
    External Intelligence Node - MODIFIED with risk level categorization
    Gathers external signals and categorizes overall external risk level
    """
    print(f"🌐 External Intelligence Node processing: {state['user_query']}")
    
    llm = get_llm_for_agents()
    _ = DataLoader()
    
    # Define tools
    tools = [
    Tool(
        name="gather_external_intelligence",
        description=(
            "Gather city-level weather, political, and operational intelligence "
            "for supplier risk assessment. Input should be the supplier query."
        ),
        func=lambda query: external_intelligence_executor.execute(query, {})  # ✅ Call .execute() method
    )
    ]
    
    # System prompt for the agent
    system_prompt = """You are an external intelligence agent for supplier risk management.
Use the provided tool to gather external intelligence and categorize the overall external risk level.

Analyze the intelligence and provide a brief summary with risk level categorization.
Focus on weather alerts, political stability, and operational disruptions."""
    
    # Create ReAct agent - WITHOUT system_prompt parameter
    agent_executor = create_react_agent(
        llm, 
        tools
    )
    
    try:
        # Invoke agent with system prompt in messages - CORRECTED for LangGraph 1.0.x
        result = agent_executor.invoke(
            {
                "messages": [
                    ("system", system_prompt),  # ✅ Add system message here
                    ("user", f"Gather and categorize external intelligence for query: {state['user_query']}")
                ]
            },
            config={"recursion_limit": 6}
        )
        
        # Extract output
        messages = result.get("messages", [])
        if messages:
            summary = messages[-1].content if hasattr(messages[-1], 'content') else str(messages[-1])
        else:
            summary = ""
        
        # Extract structured payload from messages
        payload = _extract_payload_from_result(result)
        
        # If no payload, call executor directly
        if not payload:
            payload = external_intelligence_executor.execute(
                state['user_query'], state.get('conversation_context', {})
            )
        
        # Categorize external risk level
        threats = _derive_threats(payload, summary)
        external_risk_level = _categorize_external_risk_level(threats)
        external_risk_summary = _generate_external_risk_summary(threats, external_risk_level)
        
        state['external_intelligence_results'] = {
            "success": bool(payload.get("success", True)),
            "agent_output": summary,
            "external_intelligence": payload.get("external_intelligence", {}),
            "supplier_name": payload.get("supplier_name"),
            "city": payload.get("city"),
            "topics_searched": payload.get("topics_searched", []),
            "external_threats_detected": threats,
            "external_risk_level": external_risk_level,
            "external_risk_summary": external_risk_summary,
            "task_type": "external_intelligence",
            "status": "success",
        }
        
        state['reasoning_chain'].append(f"EXTERNAL INTELLIGENCE: {external_risk_level} risk level detected")
        return state
        
    except Exception as e:
        print(f"❌ External Intelligence error: {e}")
        state['external_intelligence_results'] = {
            'error': str(e),
            'status': 'failed',
            'external_risk_level': 'LOW',
            'external_risk_summary': 'External intelligence monitoring encountered an error'
        }
        return state


def _extract_payload_from_result(result: Dict[str, Any]) -> Dict[str, Any]:
    """Extract structured payload from LangGraph result"""
    try:
        messages = result.get("messages", [])
        for msg in reversed(messages):
            if hasattr(msg, 'additional_kwargs'):
                tool_calls = msg.additional_kwargs.get('tool_calls', [])
                for call in tool_calls:
                    if isinstance(call, dict) and 'function' in call:
                        pass
        return {}
    except Exception:
        return {}


def _categorize_external_risk_level(threats: List[str]) -> str:
    """Categorize external threats into risk levels"""
    if not threats or (len(threats) == 1 and 'no immediate threats' in threats[0].lower()):
        return 'LOW'
    
    threat_text = ' '.join(threats).lower()
    
    # Critical keywords
    critical_keywords = ['severe', 'emergency', 'critical', 'major disruption', 'crisis']
    if any(keyword in threat_text for keyword in critical_keywords):
        return 'CRITICAL'
    
    # High risk keywords
    high_keywords = ['alert', 'warning', 'instability', 'disruption', 'significant']
    if any(keyword in threat_text for keyword in high_keywords):
        return 'HIGH'
    
    # Medium risk - multiple threats
    if len(threats) >= 2:
        return 'MEDIUM'
    
    return 'LOW'


def _generate_external_risk_summary(threats: List[str], risk_level: str) -> str:
    """Generate structured external risk summary"""
    if risk_level == 'CRITICAL':
        return f"Critical external threats detected requiring immediate attention: {', '.join(threats[:2])}"
    elif risk_level == 'HIGH':
        return f"High external risk signals identified: {', '.join(threats[:2])}"
    elif risk_level == 'MEDIUM':
        return f"Moderate external threats detected: {len(threats)} threat signals"
    else:
        return "External monitoring active - no significant threats detected"


def _derive_threats(payload: Dict[str, Any], summary: str) -> List[str]:
    """Derive threat flags from payload and summary"""
    intel = (payload or {}).get("external_intelligence", {}) or {}
    blobs = " ".join(str(v) for v in intel.values())
    text = f"{summary} {blobs}".lower()
    
    flags: List[str] = []
    
    if any(w in text for w in ["severe", "alert", "warning", "storm", "flood", "cyclone", "hurricane", "earthquake"]):
        flags.append("Weather/disaster alerts present")
    
    if any(w in text for w in ["instability", "tension", "protest", "conflict", "unrest"]):
        flags.append("Political instability signals present")
    
    if any(w in text for w in ["disruption", "crisis", "shutdown", "strike"]):
        flags.append("Operational disruption risk signaled")
    
    return flags or ["No immediate threats detected"]
