from typing import Dict, Any
from backend.tools.shared.risk_level_extractor import extract_risk_level_from_text
from backend.tools.strategic_advisor.data_driven_recommender import DataDrivenRecommender
from ..agent_state import AgentState

def strategic_advisor_node(state: AgentState) -> AgentState:
    """
    SIMPLIFIED Strategic Advisor - Data-driven recommendations only
    Replaces complex 4-tool approach with focused business-specific guidance
    """
    print(f"🎯 Strategic Advisor processing: {state['user_query']}")
    
    try:
        # Get risk intelligence output
        risk_results = state.get('risk_intelligence_results', {})
        risk_output = risk_results.get('agent_output', '')
        
        if not risk_output:
            state['strategic_analysis_results'] = {
                'strategic_summary': 'Unable to generate recommendations - no risk analysis available',
                'status': 'failed'
            }
            return state
        
        # Extract risk level using simple LLM approach
        risk_level = extract_risk_level_from_text(risk_output)
        print(f"📊 Extracted risk level: {risk_level}") 
        
        # Get supplier names from query analysis
        suppliers = state.get('query_analysis', {}).get('suppliers_mentioned', [])       
        
        if suppliers:
            supplier_name = suppliers[0] 
            print(f"🔍 Generating data-driven recommendations for {supplier_name}...") 
            
            # Generate data-driven recommendations
            recommender = DataDrivenRecommender()
            recommendations = recommender.generate_recommendations(
                risk_level, supplier_name, risk_output
            )
            print(f"📋 Recommendations generated: {len(recommendations)} characters")
        else:
            # Generic recommendation if no specific supplier
            recommendations = f"Risk level: {risk_level}. Standard monitoring protocols recommended based on analysis."
        
        # Store simplified results
        state['strategic_analysis_results'] = {
            'strategic_summary': recommendations,
            'risk_level_detected': risk_level,
            'supplier_analyzed': suppliers[0] if suppliers else 'Unknown',
            'status': 'success'
        }
        
        state['reasoning_chain'].append(f"STRATEGIC ADVISOR: Generated {risk_level} risk recommendations")
        
        print(f"✅ Strategic Advisor completed: {risk_level} risk level")
        return state
        
    except Exception as e:
        print(f"❌ Strategic Advisor error: {e}")
        state['strategic_analysis_results'] = {
            'strategic_summary': 'Strategic analysis encountered an error. Continue standard monitoring protocols.',
            'status': 'failed',
            'error': str(e)
        }
        return state
