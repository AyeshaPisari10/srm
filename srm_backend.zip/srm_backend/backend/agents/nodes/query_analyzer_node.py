import json
import re
from typing import Dict, Any, Optional, List
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from backend.utils.llm_client import get_llm_for_agents
from backend.utils.llm_utils import extract_llm_content
from backend.data.data_loader import DataLoader
from ..agent_state import AgentState

def query_analyzer_node(state: AgentState) -> AgentState:
    """
    Enhanced Query Analyzer - MODIFIED for 3-tier routing support
    Added specific intent patterns for data queries vs assessments
    """
    print(f"🎯 Analyzing query: '{state['user_query']}'")
    
    user_query = state['user_query']
    
    # Layer 1: Try LLM-based analysis
    llm_analysis = _try_llm_analysis(user_query, state.get('conversation_context', {}))
    
    # Layer 2: Enhanced heuristic analysis with 3-tier patterns
    heuristic_analysis = _enhanced_heuristic_analysis(user_query)
    
    # Layer 3: Pattern-based analysis
    pattern_analysis = _pattern_based_analysis(user_query)
    
    # Layer 4: Supplier name extraction
    supplier_analysis = _robust_supplier_extraction(user_query)
    
    # Merge with priority: LLM > Enhanced Heuristic > Pattern > Defaults
    final_analysis = _merge_analyses(llm_analysis, heuristic_analysis, pattern_analysis, supplier_analysis)
    
    # Final validation and classification
    final_analysis = _validate_and_classify_for_routing(final_analysis, user_query)
    
    # Update state
    state['query_analysis'] = final_analysis
    state['reasoning_chain'].append(f"QUERY ANALYSIS: {final_analysis['primary_intent']} | Routing Tier: {final_analysis.get('routing_tier', 'Unknown')}")
    
    print(f"✅ Analysis complete: {final_analysis['primary_intent']} | Tier: {final_analysis.get('routing_tier', 'Unknown')}")
    return state

def _enhanced_heuristic_analysis(user_query: str) -> Dict[str, Any]:
    """
    ENHANCED heuristic analysis with 3-tier routing patterns
    """
    query_lower = user_query.lower()
    
    # Enhanced intent patterns for 3-tier routing
    intent_patterns = {
        # Tier 1: Simple data queries - Risk Intelligence only
        'trend_analysis': [
            'trend', 'over time', 'past months', 'historical', 'pattern', 
            'show me.*trend', 'financial trend', 'performance trend'
        ],
        # Tier 2: Comparison queries - Risk Intelligence + External Intelligence
        'comparison': [
            'compare', 'vs', 'versus', 'against', 'between', 'difference', 
            'better', 'worse', 'which is', 'alternatively'
        ],        
        # Tier 3: Assessment queries - Full pipeline
        'risk_profile': [
            'risk profile', 'profile of', 'show me.*profile'
        ],
        'assessment': [
            'recommend', 'should we', 'what action', 'assess', 'evaluate',
            'advice', 'strategy', 'decision', 'continue with', 'terminate'
        ],
        'mitigation': [
            'mitigate', 'reduce risk', 'manage', 'handle', 'address', 
            'solve', 'fix', 'improve', 'action plan'
        ]
    }
    
    # Detect intent with enhanced matching
    detected_intent = 'risk_profile'  # Default to Tier 1
    max_matches = 0
    
    for intent, patterns in intent_patterns.items():
        matches = sum(1 for pattern in patterns if pattern in query_lower)
        if matches > max_matches:
            max_matches = matches
            detected_intent = intent
    
    # Determine routing tier
    routing_tier = _determine_routing_tier(detected_intent)
    
    # Risk dimensions (keep existing logic)
    risk_dimensions = ['financial', 'performance', 'geopolitical']
    risk_keywords = {
        'external': ['weather', 'climate', 'political', 'news', 'external', 'disruption']
    }
    
    for dimension, keywords in risk_keywords.items():
        if any(keyword in query_lower for keyword in keywords):
            risk_dimensions.append(dimension)
    
    # External intelligence needs
    need_external = 'yes' if any(keyword in query_lower for keyword in 
                                ['weather', 'political', 'news', 'external', 'compare']) else 'no'
    
    return {
        'source': 'enhanced_heuristic',
        'primary_intent': detected_intent,
        'routing_tier': routing_tier,
        'risk_dimensions': risk_dimensions,
        'need_external_intelligence': need_external,
        'confidence_level': 'high' if max_matches > 0 else 'medium'
    }

def _determine_routing_tier(intent: str) -> str:
    """Determine routing tier based on intent"""
    tier_mapping = {
        'risk_profile': 'Tier_3',    # ← Full pipeline
        'trend_analysis': 'Tier_1',  # ← Risk Intelligence only
        'comparison': 'Tier_2',      # ← Risk Intelligence + External Intelligence  
        'assessment': 'Tier_3',      # ← Full pipeline
        'mitigation': 'Tier_3'       # ← Full pipeline
    }
    return tier_mapping.get(intent, 'Tier_1')

def _validate_and_classify_for_routing(analysis: Dict[str, Any], user_query: str) -> Dict[str, Any]:
    """Final validation and routing classification"""
    
    # Ensure routing tier is set
    if 'routing_tier' not in analysis:
        analysis['routing_tier'] = _determine_routing_tier(analysis.get('primary_intent', 'risk_profile'))
    
    # Override for specific patterns
    query_lower = user_query.lower()
    
    # Force Tier 3 for clear assessment queries
    if any(phrase in query_lower for phrase in ['should we', 'recommend', 'what action', 'decision']):
        analysis['primary_intent'] = 'assessment'
        analysis['routing_tier'] = 'Tier_3'
    
    # Force Tier 2 for comparison queries
    elif any(phrase in query_lower for phrase in ['compare', ' vs ', 'versus', 'between']):
        analysis['primary_intent'] = 'comparison'  
        analysis['routing_tier'] = 'Tier_2'
        analysis['need_external_intelligence'] = 'yes'  # Comparisons benefit from external context
    
    return analysis

# Keep existing helper functions with minimal changes
def _try_llm_analysis(user_query: str, context: Dict) -> Dict[str, Any]:
    """Enhanced LLM analysis with 3-tier awareness"""
    try:
        llm = get_llm_for_agents()
        
        prompt = PromptTemplate(
            input_variables=["user_query", "context"],
            template="""You are an expert supplier risk management analyst. Analyze this query for 3-tier routing.

Query: "{user_query}"

Classify into one of these intents:
- risk_profile: Comprehensive profile queries (Tier 3: Full pipeline)    # ← FIXED!
- trend_analysis: Historical pattern queries (Tier 1: Risk Intelligence only)
- comparison: Comparative analysis (Tier 2: Risk Intelligence + External Intelligence)
- assessment: Strategic assessment (Tier 3: Full pipeline)
- mitigation: Risk mitigation planning (Tier 3: Full pipeline)

Respond in this EXACT JSON format:
{{
"primary_intent": "intent_name",
"suppliers_mentioned": ["exact supplier names"],
"risk_dimensions": ["financial", "performance", "geopolitical", "external"],
"need_external_intelligence": "yes|no",
"confidence": "high|medium|low"
}}"""
        )
        
        chain = prompt | llm | StrOutputParser()
        response = chain.invoke({"user_query": user_query, "context": json.dumps(context)})
        
        parsed = _safe_json_parse(response)
        if parsed and _validate_llm_response(parsed):
            parsed['source'] = 'llm'
            parsed['routing_tier'] = _determine_routing_tier(parsed.get('primary_intent', 'risk_profile'))
            return parsed
    except Exception as e:
        print(f"⚠️ LLM analysis failed: {e}")
    
    return {'source': 'llm_failed'}

# Keep other existing helper functions unchanged for brevity
def _pattern_based_analysis(user_query: str) -> Dict[str, Any]:
    """Existing pattern analysis - keep as is"""
    word_count = len(user_query.split())
    complexity = 'complex' if word_count > 20 else 'moderate' if word_count > 10 else 'simple'
    
    return {
        'source': 'pattern',
        'query_complexity': complexity,
        'analysis_depth': 'comprehensive' if complexity == 'complex' else 'detailed' if complexity == 'moderate' else 'basic'
    }

def _robust_supplier_extraction(user_query: str) -> Dict[str, Any]:
    """Existing supplier extraction - keep as is"""
    try:
        data_loader = DataLoader()
        supplier_master = data_loader.load_supplier_master()
        all_suppliers = supplier_master['supplier_name'].tolist()
        
        mentioned_suppliers = []
        for supplier in all_suppliers:
            if supplier.lower() in user_query.lower():
                mentioned_suppliers.append(supplier)
        
        return {
            'source': 'supplier_extraction',
            'suppliers_mentioned': mentioned_suppliers
        }
    except Exception:
        return {'source': 'supplier_extraction_failed', 'suppliers_mentioned': []}

def _merge_analyses(llm_analysis: Dict, heuristic_analysis: Dict, pattern_analysis: Dict, supplier_analysis: Dict) -> Dict[str, Any]:
    """Enhanced merge with routing tier support"""
    final_analysis = {
        'primary_intent': 'risk_profile',
        'routing_tier': 'Tier_1',
        'suppliers_mentioned': [],
        'risk_dimensions': ['financial', 'performance', 'geopolitical'],
        'need_external_intelligence': 'no',
        'confidence_level': 'low'
    }
    
    # Priority: LLM > Enhanced Heuristic > Pattern
    sources = [llm_analysis, heuristic_analysis, pattern_analysis]
    for source in sources:
        for key, value in source.items():
            if key != 'source' and value and key in final_analysis:
                final_analysis[key] = value
    
    # Always use supplier extraction
    final_analysis['suppliers_mentioned'] = supplier_analysis.get('suppliers_mentioned', [])
    
    return final_analysis

def _safe_json_parse(response_text: str) -> Optional[Dict[str, Any]]:
    """Keep existing JSON parsing logic"""
    try:
        return json.loads(response_text.strip())
    except:
        try:
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            if start_idx >= 0 and end_idx > start_idx:
                return json.loads(response_text[start_idx:end_idx])
        except:
            pass
    return {}

def _validate_llm_response(response: Dict) -> bool:
    """Keep existing validation"""
    required_fields = ['primary_intent', 'suppliers_mentioned', 'risk_dimensions']
    return all(field in response for field in required_fields)
