import json
from typing import Dict, Any
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from backend.utils.llm_client import get_llm_for_agents
from ..agent_state import AgentState

def response_synthesizer_node(state: AgentState) -> AgentState:
    """
    Response Synthesizer Node - Final node that creates user-ready response
    Synthesizes all agent analyses into coherent, actionable business response
    """
    print(f"🗣️ Response Synthesizer processing: '{state['user_query']}'")

    llm = get_llm_for_agents()

    # Build comprehensive synthesis prompt
    synthesis_prompt = _build_synthesis_prompt(state)

    # Create synthesis chain
    prompt_template = PromptTemplate(
        input_variables=["synthesis_content"],
        template="{synthesis_content}"
    )
    
    synthesis_chain = prompt_template | llm | StrOutputParser()

    try:
        # Generate final response
        response = synthesis_chain.invoke({"synthesis_content": synthesis_prompt})

        # FIXED: StrOutputParser returns string directly, NOT an object with .content
        content = response
        
        if isinstance(content, list):
            # Handle list case - join elements into string
            content = "\n".join(
                x if isinstance(x, str) else x.get('text', '') for x in content
            )

        final_response = _clean_and_format_response(content)

        state['final_response'] = final_response
        state['reasoning_chain'].append("RESPONSE SYNTHESIS: Final response generated successfully")

        print(f"✅ Response synthesized: {len(final_response)} characters")

    except Exception as e:
        print(f"❌ Response synthesis error: {e}")
        state['final_response'] = _create_fallback_response(state)
        state['reasoning_chain'].append(f"RESPONSE SYNTHESIS: Used fallback due to error - {str(e)}")

    return state

def _build_synthesis_prompt(state: AgentState) -> str:
    """Build synthesis prompt with conditional sections based on routing"""
    user_query = state['user_query']
    query_analysis = state.get('query_analysis', {})
    risk_results = state.get('risk_intelligence_results', {})
    external_results = state.get('external_intelligence_results', {})
    strategic_results = state.get('strategic_analysis_results', {})
    reasoning_chain = state.get('reasoning_chain', [])
    
    # Determine which agents actually ran based on routing
    intent = query_analysis.get('primary_intent', 'risk_profile')
    
    prompt = f"""You are an expert supplier risk management advisor.

USER QUERY: "{user_query}"

ANALYSIS SUMMARY:
Query Intent: {intent}
Analysis Confidence: {query_analysis.get('confidence_level', 'medium')}

RISK INTELLIGENCE FINDINGS:
{_format_risk_intelligence(risk_results)}"""

    # CONDITIONAL: Only add external intelligence for Tier 2+ queries
    if intent not in ['trend_analysis'] and external_results.get('status') == 'success':
        prompt += f"""

EXTERNAL INTELLIGENCE FINDINGS:
{_format_external_intelligence(external_results)}"""

    # CONDITIONAL: Only add strategic recommendations for Tier 3 queries  
    if intent in ['risk_profile', 'assessment', 'mitigation'] and strategic_results.get('status') == 'success':
        prompt += f"""

STRATEGIC RECOMMENDATIONS:
{_format_strategic_analysis(strategic_results)}"""

    prompt += f"""

ANALYSIS REASONING:
{' → '.join(reasoning_chain)}

INSTRUCTIONS:
1. Provide a clear, professional response that directly answers the user's question, do not response in email format
2. Focus on the specific type of analysis requested ({intent})"""

    # CONDITIONAL: Different instructions based on query type
    if intent == 'trend_analysis':
        prompt += """
3. Present historical data trends and patterns with specific data points
4. Focus on quantitative changes over time periods
5. Avoid strategic recommendations - stick to data analysis"""

    elif intent == 'comparison':
        prompt += """

    RESPONSE FORMAT FOR COMPARISON:
    - Clean title: "Risk Score Comparison: [Supplier A] vs [Supplier B]"
    - Side-by-side risk data comparison 
    - Key differences in scores/metrics
    - External intelligence context (if available)
    - NO business recommendations or impact assessments
    - Focus on data presentation, not strategic advice

    Generate a clean data comparison (no email format, no strategic recommendations):"""
        
    else:
        prompt += """
3. Present key findings with specific data points and insights
4. Include actionable recommendations with clear next steps
5. Explain potential business impact if risks are identified"""

    prompt += """

Generate a focused, professional response, do not response in email format:"""

    return prompt

def _format_risk_intelligence(risk_results: Dict) -> str:
    """FIXED: Format risk intelligence results using agent_output"""
    
    if not risk_results or risk_results.get('status') == 'failed':
        return "Risk intelligence analysis was not available for this query."

    # FIXED: Use agent_output directly instead of looking for structured data
    agent_output = risk_results.get('agent_output', '')
    
    if agent_output:
        # Return the agent's analysis directly since it contains the detailed comparative data
        return f"Risk Intelligence Analysis:\n{agent_output}"
    
    # Fallback to existing structured approach if agent_output not available
    formatted_sections = []

    # Financial analysis
    if 'financial_analysis' in risk_results:
        financial = risk_results['financial_analysis']
        if financial.get('high_risk_suppliers'):
            suppliers = ', '.join(financial['high_risk_suppliers'])
            formatted_sections.append(f"Financial Risk: {len(financial['high_risk_suppliers'])} suppliers flagged as high risk ({suppliers})")
        if 'average_risk_score' in financial:
            formatted_sections.append(f"Average Financial Risk Score: {financial['average_risk_score']}/100")

    # Performance analysis
    if 'performance_analysis' in risk_results:
        performance = risk_results['performance_analysis']
        if performance.get('deteriorating_suppliers'):
            suppliers = ', '.join(performance['deteriorating_suppliers'])
            formatted_sections.append(f"Performance Risk: {len(performance['deteriorating_suppliers'])} suppliers showing deterioration ({suppliers})")
        if 'average_performance_score' in performance:
            formatted_sections.append(f"Average Performance Risk Score: {performance['average_performance_score']}/100")

    # Geopolitical analysis
    if 'geopolitical_analysis' in risk_results:
        geo = risk_results['geopolitical_analysis']
        if geo.get('high_risk_regions'):
            regions = ', '.join(geo['high_risk_regions'])
            formatted_sections.append(f"Geopolitical Risk: High-risk regions identified - {regions}")

    return '\n'.join(formatted_sections) if formatted_sections else "Risk analysis completed with no significant concerns identified."

def _format_external_intelligence(external_results: Dict) -> str:
    """Format external intelligence results for synthesis"""
    if not external_results or external_results.get('status') == 'failed':
        return "External intelligence monitoring was not available for this query."

    threats = external_results.get('external_threats_detected', [])
    if threats and not (len(threats) == 1 and 'no immediate threats' in threats[0].lower()):
        threat_summary = '\n'.join(f"• {threat}" for threat in threats)
        return f"External Intelligence Alerts:\n{threat_summary}"

    return "External intelligence monitoring: No immediate threats detected affecting supplier operations."

def _format_strategic_analysis(strategic_results: Dict) -> str:
    """Format strategic recommendations for synthesis"""
    if not strategic_results or strategic_results.get('status') == 'failed':
        return "Strategic business recommendations were not available for this analysis."

    formatted_sections = []

    # Business impact
    if 'business_impact_level' in strategic_results:
        impact = strategic_results['business_impact_level']
        formatted_sections.append(f"Business Impact Assessment: {impact} impact level identified")

    # Priority actions
    if 'priority_actions' in strategic_results:
        actions = strategic_results['priority_actions']
        if actions:
            action_list = '\n'.join(f"• {action}" for action in actions)
            formatted_sections.append(f"Priority Actions:\n{action_list}")

    # Strategic summary
    if 'strategic_summary' in strategic_results:
        summary = strategic_results['strategic_summary']
        if summary and len(summary) > 20:  # Avoid very short summaries
            formatted_sections.append(f"Strategic Guidance: {summary}")

    return '\n'.join(formatted_sections) if formatted_sections else "Strategic analysis indicates standard risk management protocols are appropriate."

def _clean_and_format_response(response: str) -> str:
    """Clean and format response with proper Streamlit markdown line breaks"""
    # Split into lines and add two spaces at end for markdown line breaks
    lines = response.split('\n')
    formatted_lines = []

    for line in lines:
        line = line.strip()
        if line:
            # Add two spaces at end of each line for markdown line breaks
            formatted_lines.append(line + '  ')
        else:
            # Preserve empty lines as paragraph breaks
            formatted_lines.append('')

    cleaned = '\n'.join(formatted_lines)

    # Ensure we have content
    if not cleaned.strip():
        return "I apologize, but I was unable to generate a proper response to your query."

    # Add professional closing if missing
    if not any(phrase in cleaned.lower() for phrase in ['recommend', 'suggest', 'next steps', 'contact']):
        cleaned += "\n\nPlease let me know if you need additional analysis or have specific questions about these findings."

    return cleaned

def _create_fallback_response(state: AgentState) -> str:
    """Create fallback response when synthesis fails"""
    user_query = state['user_query']
    query_analysis = state.get('query_analysis', {})

    # Extract basic information for fallback
    intent = query_analysis.get('primary_intent', 'analysis')
    suppliers_mentioned = query_analysis.get('suppliers_mentioned', [])
    confidence = query_analysis.get('confidence_level', 'medium')

    fallback_response = f"""Thank you for your supplier risk management query regarding {intent}.

I have analyzed your request with {confidence} confidence"""

    if suppliers_mentioned:
        supplier_list = ', '.join(suppliers_mentioned)
        fallback_response += f" focusing on: {supplier_list}"

    fallback_response += """.

Based on the available data analysis:

• Risk assessment has been completed across multiple dimensions

• No critical immediate actions have been identified

• Standard monitoring protocols appear appropriate

I recommend continuing with regular supplier risk monitoring and reviewing key performance indicators on a monthly basis.

Please contact your procurement team if you need more detailed analysis or have specific concerns about supplier performance.

Note: This response was generated using backup analysis due to a technical issue. For complete insights, please try your query again."""

    return fallback_response
