import pandas as pd
from typing import Dict, Any
from langchain_core.prompts import PromptTemplate
from langchain_core.tools import Tool
from langgraph.prebuilt import create_react_agent
from backend.data.data_loader import DataLoader
from backend.utils.llm_client import get_llm_for_agents

# Import ALL your sophisticated tools
from backend.tools.risk_intelligence.financial_analyzer import FinancialAnalyzer
from backend.tools.risk_intelligence.performance_analyzer import PerformanceAnalyzer
from backend.tools.risk_intelligence.geopolitical_analyzer import GeopoliticalAnalyzer
from backend.tools.risk_intelligence.pattern_discovery import PatternDiscovery
from ..agent_state import AgentState

def risk_intelligence_node(state: AgentState) -> AgentState:
    """Risk Intelligence Node - Using ALL sophisticated analytical tools"""
    print(f"🧠 Risk Intelligence Node processing: {state['user_query']}")
    
    # Initialize ALL your sophisticated analyzers
    financial_analyzer = FinancialAnalyzer()
    performance_analyzer = PerformanceAnalyzer()
    geopolitical_analyzer = GeopoliticalAnalyzer()
    pattern_discovery = PatternDiscovery()
    llm = get_llm_for_agents()
    
    # Create comprehensive tools using ALL your analyzers
    all_tools = [
        # Financial Analysis Tools
        Tool(
            name="get_supplier_financial_risk",
            description="Get latest financial risk data for specific supplier",
            func=lambda supplier: financial_analyzer.get_latest_financial_risk(
                supplier.strip().strip('"').strip("'")
            )
        ),
        Tool(
            name="find_high_financial_risk_suppliers",
            description="Find all suppliers with high financial risk scores",
            func=lambda x: financial_analyzer.get_high_risk_suppliers()
        ),
        Tool(
            name="analyze_financial_trends",
            description="Analyze financial risk trends for supplier over 6 months",
            func=lambda supplier: financial_analyzer.analyze_financial_trends(
                supplier.strip().strip('"').strip("'"), 6
            )
        ),
        Tool(
            name="get_financial_distribution",
            description="Get financial risk distribution across all suppliers",
            func=lambda x: financial_analyzer.get_financial_risk_distribution()
        ),
        
        # Performance Analysis Tools
        Tool(
            name="get_supplier_performance",
            description="Get latest performance metrics for specific supplier",
            func=lambda supplier: performance_analyzer.get_latest_performance(
                supplier.strip().strip('"').strip("'")
            )
        ),
        Tool(
            name="find_deteriorating_suppliers",
            description="Find suppliers with declining performance",
            func=lambda x: performance_analyzer.get_deteriorating_suppliers()
        ),
        Tool(
            name="analyze_performance_trends",
            description="Analyze performance trends for supplier over 6 months",
            func=lambda supplier: performance_analyzer.analyze_performance_trends(
                supplier.strip().strip('"').strip("'"), 6
            )
        ),
        
        # Geopolitical Analysis Tools
        Tool(
            name="get_supplier_geopolitical_risk",
            description="Get geopolitical risk data for specific supplier",
            func=lambda supplier: geopolitical_analyzer.get_supplier_geopolitical_risk(
                supplier.strip().strip('"').strip("'")
            )
        ),
        Tool(
            name="get_country_risk_summary",
            description="Get risk summary by country for all suppliers",
            func=lambda x: geopolitical_analyzer.get_country_risk_summary()
        ),
        Tool(
            name="get_high_risk_regions",
            description="Get countries/regions with high geopolitical risk",
            func=lambda x: geopolitical_analyzer.get_high_risk_regions()
        ),
        
        # Pattern Discovery Tools
        Tool(
            name="find_risk_correlations",
            description="Find suppliers with correlated risks across dimensions",
            func=lambda x: pattern_discovery.find_correlated_risk_patterns()
        ),
        Tool(
            name="detect_emerging_trends",
            description="Detect emerging risk trends across all suppliers",
            func=lambda x: pattern_discovery.detect_emerging_trends(6)
        ),
        Tool(
            name="identify_risk_hotspots",
            description="Identify suppliers with multiple risk factors",
            func=lambda x: pattern_discovery.identify_risk_hotspots()
        )
    ]
    
    # Select relevant tools based on query
    tools = select_tools_for_query(state, all_tools)
    
    # System prompt for the agent
    system_prompt = """You are a comprehensive supplier risk analyst. When analyzing suppliers, always consider ALL relevant risk dimensions:

- Financial health and stability
- Operational performance and service quality
- Geopolitical and regulatory environment
- Cross-dimensional risk patterns and correlations

For supplier analysis and comparisons, gather data across all applicable risk dimensions before drawing conclusions. A thorough risk assessment requires understanding the complete risk profile.

Provide comprehensive analysis with specific data points."""
    
    # Create ReAct agent - WITHOUT system_prompt parameter
    agent_executor = create_react_agent(
        llm, 
        tools
    )
    
    try:
        print(f"🔍 Starting agent with {len(tools)} tools...")
        
        # Execute with system prompt in messages - CORRECTED for LangGraph 1.0.x
        result = agent_executor.invoke(
            {
                "messages": [
                    ("system", system_prompt),  # ✅ Add system message here
                    ("user", state['user_query'])
                ]
            },
            config={"recursion_limit": 10}
        )
        
        print(f"✅ Agent execution completed!")
        
        # Extract output
        messages = result.get("messages", [])
        if messages:
            output = messages[-1].content if hasattr(messages[-1], 'content') else str(messages[-1])
            print(f"🔍 Output: {output[:200]}...")
        else:
            output = ""
        
        # Store results
        if output:
            state['risk_intelligence_results'] = {
                'analysis_completed': True,
                'agent_output': output,
                'status': 'success',
                'tools_available': len(tools)
            }
        else:
            state['risk_intelligence_results'] = {
                'analysis_completed': False,
                'agent_output': str(result),
                'status': 'partial',
                'tools_available': len(tools)
            }
        
        state['reasoning_chain'].append(f"RISK INTELLIGENCE: Agent used {len(tools)} tools")
        
    except Exception as e:
        print(f"❌ Agent error: {e}")
        import traceback
        traceback.print_exc()
        state['risk_intelligence_results'] = {
            'error': str(e),
            'status': 'failed',
            'tools_available': len(tools)
        }
    
    return state


def select_tools_for_query(state: AgentState, all_tools: list) -> list:
    """Let the LLM reason about tool selection"""
    from backend.utils.llm_utils import extract_llm_content
    
    query_analysis = state.get('query_analysis', {})
    user_query = state['user_query']
    
    # Get tool descriptions
    tool_descriptions = [f"- {tool.name}: {tool.description}" for tool in all_tools]
    
    prompt = f"""
User query: "{user_query}"

Available analysis tools:
{chr(10).join(tool_descriptions)}

Based on these examples, select the most relevant tools:

Example 1:
Query: "show me financial trend for Gates Ltd"
Selected tools: analyze_financial_trends, find_risk_correlations

Example 2:
Query: "compare Logan LLC vs Gates Ltd risk levels"
Selected tools: get_supplier_financial_risk, get_supplier_performance, get_supplier_geopolitical_risk, find_risk_correlations

Example 3:
Query: "what is Wright-Reyes performance score"
Selected tools: get_supplier_performance

Example 4:
Query: "show me risk profile for Blake PLC"
Selected tools: get_supplier_financial_risk, get_supplier_performance, get_supplier_geopolitical_risk, analyze_financial_trends

Example 5:
Query: "which suppliers have high geopolitical risk"
Selected tools: get_supplier_geopolitical_risk, detect_emerging_trends

For the current query, respond with only the relevant tool names, comma-separated:
"""
    
    llm = get_llm_for_agents()
    response = llm.invoke(prompt)
    content = extract_llm_content(response)
    selected_tool_names = [name.strip() for name in content.split(',')]
    
    # Filter actual tools based on LLM selection
    selected_tools = [tool for tool in all_tools if tool.name in selected_tool_names]
    
    # Fallback if LLM selection fails
    if not selected_tools:
        selected_tools = all_tools
    
    return selected_tools
