from typing import Dict, Any, Literal
from .agent_state import AgentState

def route_to_agents(state: AgentState) -> Literal["risk_intelligence", "strategic_advisor", "external_intelligence"]:
    """
    Updated 3-tier routing based on query intent:
    1. Trend Analysis → Risk Intelligence only
    2. Comparison → Risk Intelligence + External Intelligence  
    3. Risk Profile & Assessment & Mitigation → Full pipeline (all 3 agents)
    """
    analysis = state.get('query_analysis', {})
    primary_intent = analysis.get('primary_intent', 'risk_profile')
    
    print(f"🔀 Routing decision: Intent={primary_intent}")
    
    # All queries start with risk intelligence
    if primary_intent == 'trend_analysis':
        print("→ Routing to risk_intelligence (Tier 1: Trend Analysis)")
        return "risk_intelligence"
        
    elif primary_intent == 'comparison':
        print("→ Routing to risk_intelligence (Tier 2: Comparison)")
        return "risk_intelligence"
        
    elif primary_intent in ['risk_profile', 'assessment', 'mitigation']:
        print("→ Routing to risk_intelligence (Tier 3: Full pipeline)")
        return "risk_intelligence"
    
    # Fallback
    print("→ Routing to risk_intelligence (Fallback)")
    return "risk_intelligence"

def route_after_risk_intelligence(state: AgentState) -> Literal["external_intelligence", "strategic_advisor", "response_synthesizer"]:
    """Route after risk intelligence - updated for full pipeline"""
    analysis = state.get('query_analysis', {})
    primary_intent = analysis.get('primary_intent', 'risk_profile')
    
    # Tier 1: Trend analysis ends here
    if primary_intent == 'trend_analysis':
        print("→ Routing to response_synthesizer (Tier 1: Trend Analysis complete)")
        return "response_synthesizer"
    
    # Tier 2: Comparison needs external intelligence
    elif primary_intent == 'comparison':
        print("→ Routing to external_intelligence (Tier 2: Comparison)")
        return "external_intelligence"
    
    # Tier 3: Risk profile, assessment, mitigation need external intelligence (full pipeline)
    elif primary_intent in ['risk_profile', 'assessment', 'mitigation']:
        print(f"→ Routing to external_intelligence (Tier 3: {primary_intent} - full pipeline)")
        return "external_intelligence"
    
    # Fallback
    print("→ Routing to response_synthesizer (Fallback)")
    return "response_synthesizer"

def route_after_external_intelligence(state: AgentState) -> Literal["strategic_advisor", "response_synthesizer"]:
    """Route after external intelligence - full pipeline for risk profile"""
    analysis = state.get('query_analysis', {})
    primary_intent = analysis.get('primary_intent', 'comparison')
    
    # Tier 2: Comparison ends here (no strategic advisor)
    if primary_intent == 'comparison':
        print("→ Routing to response_synthesizer (Tier 2: Comparison complete)")
        return "response_synthesizer"
    
    # Tier 3: Risk profile, assessment, mitigation continue to strategic advisor (full pipeline)
    elif primary_intent in ['risk_profile', 'assessment', 'mitigation']:
        print(f"→ Routing to strategic_advisor (Tier 3: {primary_intent} - full pipeline)")
        return "strategic_advisor"
    
    # Fallback - no strategic advisor
    print("→ Routing to response_synthesizer (Fallback)")
    return "response_synthesizer"

# Debug helpers
def log_routing_decision(from_node: str, to_node: str, state: AgentState, reason: str = ""):
    """Log routing decisions for debugging"""
    routing_info = {
        'from': from_node,
        'to': to_node,
        'reason': reason,
        'query': state.get('user_query', '')[:100] + '...' if len(state.get('user_query', '')) > 100 else state.get('user_query', '')
    }
    
    if 'reasoning_chain' not in state:
        state['reasoning_chain'] = []
    state['reasoning_chain'].append(f"ROUTING: {from_node} → {to_node} ({reason})")
    
    print(f"🔀 ROUTING LOG: {from_node} → {to_node} | {reason}")
    return routing_info
