from langgraph.graph import StateGraph, END
from typing import Dict, Any, Optional
from .agent_state import AgentState
from .nodes.query_analyzer_node import query_analyzer_node
from .nodes.risk_intelligence_node import risk_intelligence_node
from .nodes.external_intelligence_node import external_intelligence_node
from .nodes.strategic_advisor_node import strategic_advisor_node
from .nodes.response_synthesizer_node import response_synthesizer_node
from .routing import route_to_agents, route_after_risk_intelligence, route_after_external_intelligence

def create_supplier_risk_graph():
    """
    CORRECTED for LangGraph 1.0.x: Create LangGraph with 3-tier routing support
    Implements selective routing based on query intent
    """
    workflow = StateGraph(AgentState)
    
    # Add all agent nodes
    workflow.add_node("query_analyzer", query_analyzer_node)
    workflow.add_node("risk_intelligence", risk_intelligence_node)
    workflow.add_node("external_intelligence", external_intelligence_node)
    workflow.add_node("strategic_advisor", strategic_advisor_node)
    workflow.add_node("response_synthesizer", response_synthesizer_node)
    
    # Set entry point
    workflow.set_entry_point("query_analyzer")
    
    # CORRECTED: 3-tier conditional routing with complete mapping dictionaries
    # Route from query_analyzer to risk_intelligence (all queries start here)
    workflow.add_conditional_edges(
        "query_analyzer",
        route_to_agents,
        {
            "risk_intelligence": "risk_intelligence"
            # All queries route to risk intelligence
        }
    )
    
    # CORRECTED: Route after risk intelligence - can end here for Tier 1 or continue
    workflow.add_conditional_edges(
        "risk_intelligence",
        route_after_risk_intelligence,
        {
            "external_intelligence": "external_intelligence",
            "response_synthesizer": "response_synthesizer"  # Tier 1: Direct to response
        }
    )
    
    # CORRECTED: Route after external intelligence - can end here for Tier 2 or continue
    workflow.add_conditional_edges(
        "external_intelligence",
        route_after_external_intelligence,
        {
            "strategic_advisor": "strategic_advisor",
            "response_synthesizer": "response_synthesizer"  # Tier 2: Direct to response
        }
    )
    
    # Tier 3: Strategic advisor always goes to response synthesizer
    workflow.add_edge("strategic_advisor", "response_synthesizer")
    
    # Final response goes to END
    workflow.add_edge("response_synthesizer", END)
    
    # CORRECTED: Compile and RETURN the compiled graph
    # LangGraph 1.0.x returns a compiled graph object
    compiled_graph = workflow.compile()
    
    return compiled_graph


# Create and store the global graph instance
supplier_risk_graph = create_supplier_risk_graph()


async def process_supplier_query(user_query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    ENHANCED: Process supplier risk queries with detailed routing path logging
    """
    # Initialize state with ALL required fields from AgentState
    initial_state: AgentState = {
        'user_query': user_query,
        'conversation_context': context or {},
        'query_analysis': {},
        'risk_intelligence_results': {},
        'external_intelligence_results': {},
        'strategic_analysis_results': {},
        'final_response': "",
        'reasoning_chain': [],
        # NEW REQUIRED FIELDS
        'supplier_importance_results': {},
        'query_intent_category': '',
        'routing_tier': '',
        'skip_strategic_advisor': False
    }
    
    print(f"🚀 Processing query: '{user_query}'")
    
    # CORRECTED: Use the compiled graph from create_supplier_risk_graph()
    try:
        # Use ainvoke for async execution
        result = await supplier_risk_graph.ainvoke(initial_state)
        
        # Extract and log routing path
        reasoning_chain = result.get('reasoning_chain', [])
        routing_steps = [step for step in reasoning_chain if step.startswith('ROUTING:')]
        
        print("\n📍 ROUTING PATH:")
        for i, step in enumerate(routing_steps, 1):
            print(f"  {i}. {step}")
        
        # Query analysis summary
        query_analysis = result.get('query_analysis', {})
        routing_tier = query_analysis.get('routing_tier', 'Unknown')
        intent = query_analysis.get('primary_intent', 'Unknown')
        
        print(f"\n✅ Query completed: {intent} via {routing_tier}")
        
        return result
        
    except Exception as e:
        print(f"❌ Error processing query: {e}")
        import traceback
        traceback.print_exc()
        
        # Return error state
        return {
            **initial_state,
            'final_response': f"Error processing query: {str(e)}",
            'reasoning_chain': [f"ERROR: {str(e)}"]
        }


def get_graph():
    """
    Utility function to get the compiled graph instance
    Useful for debugging and testing
    """
    return supplier_risk_graph
