from typing import Dict, List, Optional
from datetime import datetime
import threading

class ConversationMemory:
    """
    In-memory conversation storage for chatbot sessions
    Thread-safe implementation for concurrent users
    """
    
    def __init__(self):
        self._conversations: Dict[str, List[Dict[str, str]]] = {}
        self._lock = threading.Lock()
    
    def add_message(self, conversation_id: str, role: str, content: str) -> None:
        """Add a message to conversation history"""
        with self._lock:
            if conversation_id not in self._conversations:
                self._conversations[conversation_id] = []
            
            self._conversations[conversation_id].append({
                'role': role,
                'content': content,
                'timestamp': datetime.now().isoformat()
            })
    
    def get_conversation(self, conversation_id: str) -> List[Dict[str, str]]:
        """Get full conversation history"""
        with self._lock:
            return self._conversations.get(conversation_id, []).copy()
    
    def get_recent_messages(self, conversation_id: str, limit: int = 10) -> List[Dict[str, str]]:
        """Get recent messages from conversation"""
        with self._lock:
            messages = self._conversations.get(conversation_id, [])
            return messages[-limit:] if messages else []
    
    def clear_conversation(self, conversation_id: str) -> None:
        """Clear conversation history"""
        with self._lock:
            if conversation_id in self._conversations:
                del self._conversations[conversation_id]
    
    def get_conversation_count(self, conversation_id: str) -> int:
        """Get message count in conversation"""
        with self._lock:
            return len(self._conversations.get(conversation_id, []))

# Global instance
conversation_memory = ConversationMemory()
